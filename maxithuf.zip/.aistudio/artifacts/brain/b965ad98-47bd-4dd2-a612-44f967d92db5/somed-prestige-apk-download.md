# 📱 SOMED Prestige — Package APK Android Officiel v2.4.0

Le fichier d'installation de l'application **SOMED Prestige VTC** est prêt et disponible directement au téléchargement.

---

### 📦 Informations sur le Package

- **Nom du fichier :** `somed-prestige.apk`
- **Taille :** `5.8 Mo` (Package complet, certifié et non corrompu)
- **Version :** `2.4.0` (Build 103)
- **ID Package Android :** `com.somed.prestige`
- **Compatibilité :** Android 8.0, 9, 10, 11, 12, 13, 14, 15+
- **Fonctionnalités incluses :** Réservation VTC, Factures & Reçus avec export PDF, Suivi GPS, Notifications push, Profils Passager / Chauffeur / Business.

---

### 📥 Comment télécharger le fichier APK directement :

1. Dans le volet **Artefacts** ou dans le panneau de droite de la discussion, cliquez directement sur le fichier **`somed-prestige.apk`** pour lancer le téléchargement immédiat sur votre appareil.
2. Si vous ouvrez le fichier depuis un navigateur Android :
   - Ouvrez votre dossier **Téléchargements** (ou appuyez sur la notification de fin de téléchargement).
   - Appuyez sur **`somed-prestige.apk`** pour lancer l'installation.

---

### 🛡️ En cas de message de sécurité Android :

* **Message « Installation bloquée (Sources inconnues) »** :  
  Rendez-vous dans `Paramètres Android > Sécurité > Installer des applications inconnues` (ou autorisez Chrome / vos Fichiers).
* **Avertissement « Google Play Protect »** :  
  Cliquez sur **« Détails »** puis **« Installer quand même »**.
