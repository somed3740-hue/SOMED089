import React, { useState } from 'react';
import { 
  Users, 
  Car, 
  DollarSign, 
  Activity, 
  TrendingUp, 
  Filter, 
  ShieldCheck, 
  RefreshCw, 
  Sliders, 
  CheckCircle2, 
  AlertCircle,
  Plus,
  Bell,
  Send,
  Sparkles,
  Phone,
  ShieldAlert,
  Radio,
  MapPin,
  Clock,
  Check,
  Zap,
  Tag
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { VtcMap } from '../Map/VtcMap';
import { formatEuro } from '../../utils/geo';
import { RideStatus, NotificationCategory } from '../../types/vtc';
import { soundEffects } from '../../utils/audio';

export const AdminView: React.FC = () => {
  const drivers = vtcStore.getAllDrivers();
  const rides = vtcStore.getAllRides();
  const surgeMultiplier = vtcStore.getSurgeMultiplier();
  const autoSimulate = vtcStore.isAutoSimulateDriver();
  const notifications = vtcStore.getNotifications();

  const [activeTab, setActiveTab] = useState<'MAP_RIDES' | 'PUSH_SIMULATOR' | 'DRIVERS' | 'DISPATCH_SOS' | 'PRICING'>('MAP_RIDES');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Push Simulator Form State
  const [customTitle, setCustomTitle] = useState('');
  const [customBody, setCustomBody] = useState('');
  const [customCategory, setCustomCategory] = useState<NotificationCategory>('RIDE');
  const [customBadge, setCustomBadge] = useState('Dispatch SOMED');
  const [pushSentSuccess, setPushSentSuccess] = useState(false);

  // Stats calculation
  const totalVolume = rides.reduce((acc, r) => acc + (r.status === 'COMPLETED' ? r.fare : 0), 0);
  const platformRevenue = totalVolume * 0.2; // 20% platform cut
  const activeRidesCount = rides.filter((r) => ['REQUESTED', 'ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(r.status)).length;
  const onlineDriversCount = drivers.filter((d) => d.isOnline).length;

  const filteredRides = rides.filter((r) => {
    if (statusFilter === 'ALL') return true;
    return r.status === statusFilter;
  });

  const handleSendCustomPush = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;

    vtcStore.sendPushNotification({
      title: customTitle,
      body: customBody || 'Notification transmise depuis la console de régulation Dispatch SOMED.',
      category: customCategory,
      badge: customBadge || 'Dispatch',
    });

    soundEffects.playPushNotificationSound();
    setPushSentSuccess(true);
    setCustomTitle('');
    setCustomBody('');
    setTimeout(() => setPushSentSuccess(false), 3000);
  };

  const handleTriggerPreset = (type: string) => {
    switch (type) {
      case 'ride_requested':
        vtcStore.sendPushNotification({
          title: 'Nouvelle course VTC demandée',
          body: 'Un passager recherche une berline au départ de la Tour Eiffel (28,50 €).',
          category: 'RIDE',
          badge: 'Course VTC',
          actions: [
            { id: 'act1', label: 'Voir la course', actionType: 'VIEW_RIDE', variant: 'primary' }
          ]
        });
        soundEffects.playRideRequestAlert();
        break;

      case 'driver_assigned':
        vtcStore.sendPushNotification({
          title: 'Chauffeur assigné : Karim M.',
          body: 'Votre chauffeur arrive d\'ici 3 minutes avec sa Mercedes Classe E (GD-411-AZ).',
          category: 'RIDE',
          badge: 'En route',
          actions: [
            { id: 'act2', label: 'Suivre chauffeur', actionType: 'VIEW_RIDE', variant: 'primary' }
          ]
        });
        soundEffects.playPushNotificationSound();
        break;

      case 'driver_arrived':
        vtcStore.sendPushNotification({
          title: 'Chauffeur arrivé sur place !',
          body: 'Karim vous attend au point de rendez-vous convenu. Merci de vous présenter.',
          category: 'RIDE',
          badge: 'Sur place',
          actions: [
            { id: 'act3', label: 'Je descends', actionType: 'VIEW_RIDE', variant: 'primary' }
          ]
        });
        soundEffects.playPushNotificationSound();
        break;

      case 'code_shared':
        vtcStore.sendPushNotification({
          title: 'Code de sécurité transmis : 4829',
          body: 'Le passager Jean Dupont a partagé son code de confirmation (4829) avec son chauffeur.',
          category: 'RIDE',
          badge: 'Code Validé'
        });
        soundEffects.playSuccessSound();
        break;

      case 'ride_completed':
        vtcStore.sendPushNotification({
          title: 'Course terminée · Facture prête',
          body: 'Votre trajet vers Champs-Élysées est achevé. Votre facture PDF #FAC-2025-001 est prête.',
          category: 'PAYMENT',
          badge: 'Reçu acquitté',
          actions: [
            { id: 'act4', label: 'Télécharger facture', actionType: 'VIEW_WALLET', variant: 'primary' }
          ]
        });
        soundEffects.playRideCompleted();
        break;

      case 'payment_ok':
        vtcStore.sendPushNotification({
          title: 'Paiement validé de 34,50 €',
          body: 'Le débit automatique par carte bancaire a été validé avec succès (TVA 10% incluse).',
          category: 'PAYMENT',
          badge: 'Paiement CB'
        });
        soundEffects.playPushNotificationSound();
        break;

      case 'courier_transit':
        vtcStore.sendPushNotification({
          title: 'Colis express en cours de livraison',
          body: 'Votre coursier à vélo a récupéré le colis et se dirige vers l\'adresse de livraison.',
          category: 'DELIVERY',
          badge: 'Livraison express',
          actions: [
            { id: 'act5', label: 'Suivre le coursier', actionType: 'VIEW_DELIVERY', variant: 'primary' }
          ]
        });
        soundEffects.playPushNotificationSound();
        break;

      case 'sos_alert':
        vtcStore.sendPushNotification({
          title: 'Alerte Dispatch : Assistance Prioritaire',
          body: 'Le centre de régulation SOMED a activé un protocole de vérification de sécurité.',
          category: 'SECURITY',
          badge: 'Alerte SOS'
        });
        soundEffects.playClick();
        break;

      default:
        break;
    }
  };

  return (
    <div className="h-full w-full flex flex-col bg-slate-950 text-slate-100 overflow-hidden select-none">
      {/* Top Dispatch Console Bar */}
      <header className="px-5 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <img 
            src="/somed-logo.png" 
            alt="SOMED" 
            className="w-9 h-9 aspect-square object-cover rounded-xl shadow-md ring-1 ring-amber-400/30" 
          />
          <div>
            <h2 className="font-bold text-sm text-white flex items-center gap-2">
              <span>SOMED · Régulation Dispatch & Flotte</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                Supervision Paris Live
              </span>
            </h2>
          </div>
        </div>

        {/* View Switcher Tabs with Push Simulator */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('MAP_RIDES')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
              activeTab === 'MAP_RIDES'
                ? 'bg-blue-600 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Flotte & Courses
          </button>

          <button
            onClick={() => setActiveTab('PUSH_SIMULATOR')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'PUSH_SIMULATOR'
                ? 'bg-yellow-400 text-black shadow-sm font-black'
                : 'text-yellow-400 hover:text-yellow-300'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Simulateur Push</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </button>

          <button
            onClick={() => setActiveTab('DRIVERS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
              activeTab === 'DRIVERS'
                ? 'bg-blue-600 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Chauffeurs ({drivers.length})
          </button>

          <button
            onClick={() => setActiveTab('DISPATCH_SOS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
              activeTab === 'DISPATCH_SOS'
                ? 'bg-rose-600 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sécurité SOS
          </button>

          <button
            onClick={() => setActiveTab('PRICING')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
              activeTab === 'PRICING'
                ? 'bg-blue-600 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Surge & Tarifs
          </button>
        </div>

        {/* Global actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => vtcStore.seedDemoRide()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-semibold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Simuler course</span>
          </button>
          <button
            onClick={() => vtcStore.resetAllData()}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs border border-slate-700 transition"
            title="Réinitialiser les données"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* KPI Cards Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-5 py-2.5 bg-slate-950/80 border-b border-slate-800/80 flex-shrink-0">
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-2.5">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-0.5">
            <span>Volume d'affaires</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <p className="text-lg font-bold text-white">{formatEuro(totalVolume)}</p>
          <p className="text-[10px] text-slate-500">Commission 20% : {formatEuro(platformRevenue)}</p>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-2.5">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-0.5">
            <span>Courses Actives</span>
            <Activity className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <p className="text-lg font-bold text-blue-400">{activeRidesCount}</p>
          <p className="text-[10px] text-slate-500">En cours de traitement</p>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-2.5">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-0.5">
            <span>Chauffeurs Connectés</span>
            <Car className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <p className="text-lg font-bold text-emerald-400">{onlineDriversCount} / {drivers.length}</p>
          <p className="text-[10px] text-slate-500">Taux disponibilité : {Math.round((onlineDriversCount / (drivers.length || 1)) * 100)}%</p>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-2.5">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-0.5">
            <span>Surge / Majorateur</span>
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <p className="text-lg font-bold text-amber-400">x{surgeMultiplier.toFixed(1)}</p>
          <p className="text-[10px] text-slate-500">{surgeMultiplier > 1 ? 'Tarification dynamique' : 'Tarifs standards'}</p>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-hidden">
        {/* 1. MAP & RIDES TAB */}
        {activeTab === 'MAP_RIDES' && (
          <div className="h-full w-full flex flex-col md:flex-row">
            {/* Map Area */}
            <div className="flex-1 h-[45%] md:h-full relative">
              <VtcMap drivers={drivers} />
            </div>

            {/* Live Rides Feed */}
            <div className="w-full md:w-[480px] h-[55%] md:h-full flex flex-col bg-slate-900/95 border-t md:border-t-0 md:border-l border-slate-800">
              <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Journal des courses ({filteredRides.length})
                </span>

                {/* Filter tags */}
                <div className="flex items-center gap-1 text-[11px]">
                  {['ALL', 'REQUESTED', 'IN_PROGRESS', 'COMPLETED'].map((st) => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-2 py-0.5 rounded transition ${
                        statusFilter === st
                          ? 'bg-blue-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {st === 'ALL' ? 'Tous' : st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rides List */}
              <div className="flex-1 p-3 overflow-y-auto space-y-2.5">
                {filteredRides.length === 0 ? (
                  <div className="text-center py-12 text-slate-500 text-xs">
                    Aucune course ne correspond à ce filtre.
                  </div>
                ) : (
                  filteredRides.map((ride) => (
                    <div
                      key={ride.id}
                      className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs space-y-2 hover:border-slate-700 transition"
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{ride.passengerName}</span>
                          <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                            {ride.category}
                          </span>
                        </div>
                        <span className="font-bold text-emerald-400">{formatEuro(ride.fare)}</span>
                      </div>

                      <div className="text-[11px] text-slate-400 space-y-0.5">
                        <p className="truncate"><span className="text-emerald-500 font-semibold">Départ:</span> {ride.pickup.name || ride.pickup.address}</p>
                        <p className="truncate"><span className="text-rose-500 font-semibold">Arrivée:</span> {ride.destination.name || ride.destination.address}</p>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-slate-800/80 text-[11px]">
                        <span className="text-slate-500">
                          {ride.driverName ? `Chauffeur: ${ride.driverName}` : 'Recherche en cours...'}
                        </span>

                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          ride.status === 'COMPLETED'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : ride.status === 'IN_PROGRESS'
                            ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                            : ride.status === 'REQUESTED'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}>
                          {ride.status}
                        </span>
                      </div>

                      {/* Manual Dispatch Action if requested */}
                      {ride.status === 'REQUESTED' && (
                        <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between">
                          <span className="text-[10px] text-slate-400">Assigner manuellement :</span>
                          <div className="flex items-center gap-1">
                            {drivers.filter((d) => d.isOnline && !d.isBusy).slice(0, 2).map((d) => (
                              <button
                                key={d.id}
                                onClick={() => vtcStore.assignDriverManually(ride.id, d.id)}
                                className="px-2 py-0.5 bg-blue-600/30 hover:bg-blue-600 text-blue-200 hover:text-white rounded text-[10px] transition font-semibold"
                              >
                                {d.name.split(' ')[0]}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* 2. PUSH SIMULATOR TAB (DIRECTEMENT DANS DISPATCH SELON LA DEMANDE UTILISATEUR) */}
        {activeTab === 'PUSH_SIMULATOR' && (
          <div className="h-full overflow-y-auto p-6 max-w-4xl mx-auto space-y-6">
            {/* Header info */}
            <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-3xl p-5 flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-yellow-400 text-black flex items-center justify-center flex-shrink-0 shadow-lg shadow-yellow-500/20">
                <Bell className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                  <span>Simulateur de Notifications Push Dispatch</span>
                  <span className="text-[10px] font-black bg-yellow-400 text-black px-2 py-0.5 rounded-full">
                    Actif
                  </span>
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Testez instantanément les notifications push qui descendent de haut en bas sur l'ensemble des interfaces de l'application (Passager, Chauffeur, Business). Chaque notification émet le carillon sonore et la vibration haptique.
                </p>
              </div>
            </div>

            {/* Scénarios Prédéfinis */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                <span>Scénarios Prédéfinis en 1 Clic :</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                <button
                  onClick={() => handleTriggerPreset('ride_requested')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">🚖</span>
                    <span className="text-[10px] bg-yellow-400/10 text-yellow-400 px-1.5 py-0.5 rounded font-bold">Course</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Demande de course</p>
                  <p className="text-[11px] text-slate-400">Recherche de chauffeur...</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('driver_assigned')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">🚗</span>
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-bold">Chauffeur</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Chauffeur assigné</p>
                  <p className="text-[11px] text-slate-400">En approche dans 3 min</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('driver_arrived')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">📍</span>
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-bold">Arrivée</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Chauffeur sur place</p>
                  <p className="text-[11px] text-slate-400">Attente au point de montée</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('code_shared')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">🔑</span>
                    <span className="text-[10px] bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded font-bold">Code OTP</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Code course transmis</p>
                  <p className="text-[11px] text-slate-400">Validation PIN passager</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('ride_completed')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">🏁</span>
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-bold">Terminée</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Course terminée</p>
                  <p className="text-[11px] text-slate-400">Facture PDF générée</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('payment_ok')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">💳</span>
                    <span className="text-[10px] bg-sky-500/10 text-sky-400 px-1.5 py-0.5 rounded font-bold">Paiement</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Paiement 34,50 €</p>
                  <p className="text-[11px] text-slate-400">Débit CB automatique</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('courier_transit')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">📦</span>
                    <span className="text-[10px] bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded font-bold">Livraison</span>
                  </div>
                  <p className="font-bold text-xs text-white group-hover:text-yellow-400">Colis en transit</p>
                  <p className="text-[11px] text-slate-400">Coursier express en route</p>
                </button>

                <button
                  onClick={() => handleTriggerPreset('sos_alert')}
                  className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-rose-500/30 text-left transition space-y-1 group active:scale-95 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">🚨</span>
                    <span className="text-[10px] bg-rose-500/10 text-rose-400 px-1.5 py-0.5 rounded font-bold">Urgence</span>
                  </div>
                  <p className="font-bold text-xs text-rose-400 group-hover:text-rose-300">Alerte SOS</p>
                  <p className="text-[11px] text-slate-400">Vérification de sécurité</p>
                </button>
              </div>
            </div>

            {/* Custom Push Broadcaster */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
              <h4 className="font-bold text-sm text-white flex items-center justify-between">
                <span>Diffuser une Notification Push Personnalisée :</span>
                {pushSentSuccess && (
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    Diffusée avec succès !
                  </span>
                )}
              </h4>

              <form onSubmit={handleSendCustomPush} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1 font-semibold">Titre de la notification :</label>
                    <input
                      type="text"
                      value={customTitle}
                      onChange={(e) => setCustomTitle(e.target.value)}
                      placeholder="Ex: Mise à jour course, Offre flash..."
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-yellow-400"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1 font-semibold">Catégorie :</label>
                    <select
                      value={customCategory}
                      onChange={(e) => setCustomCategory(e.target.value as NotificationCategory)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-yellow-400"
                    >
                      <option value="RIDE">Course VTC (RIDE)</option>
                      <option value="DELIVERY">Livraison Express (DELIVERY)</option>
                      <option value="BUSINESS">Espace Business (BUSINESS)</option>
                      <option value="PAYMENT">Paiement & Facture (PAYMENT)</option>
                      <option value="SYSTEM">Système & Info (SYSTEM)</option>
                      <option value="SECURITY">Sécurité & SOS (SECURITY)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1 font-semibold">Message / Contenu :</label>
                  <textarea
                    value={customBody}
                    onChange={(e) => setCustomBody(e.target.value)}
                    placeholder="Tapez le texte qui apparaîtra dans la bannière descendante..."
                    rows={2}
                    className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-yellow-400"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">Badge personnalisé :</span>
                    <input
                      type="text"
                      value={customBadge}
                      onChange={(e) => setCustomBadge(e.target.value)}
                      className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-yellow-400 w-36"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={!customTitle.trim()}
                    className="px-5 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 disabled:opacity-40 text-black font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-yellow-500/20 transition active:scale-95"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Diffuser la notification push instantanée</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Push Notifications Log */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-white flex items-center justify-between">
                <span>Historique des notifications récentes ({notifications.length})</span>
                <span className="text-[11px] text-slate-400">Stockées localement</span>
              </h4>

              <div className="space-y-2">
                {notifications.slice(0, 5).map((notif) => (
                  <div
                    key={notif.id}
                    className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-400 flex items-center justify-center flex-shrink-0">
                        <Bell className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-white truncate">{notif.title}</p>
                        <p className="text-[11px] text-slate-400 truncate">{notif.body}</p>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full text-slate-300 font-mono">
                        {notif.category}
                      </span>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        {new Date(notif.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 3. DRIVERS ROSTER TAB */}
        {activeTab === 'DRIVERS' && (
          <div className="p-6 overflow-y-auto h-full max-w-5xl mx-auto space-y-4">
            <h3 className="font-bold text-lg text-white">Gestion de la flotte partenaires</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {drivers.map((drv) => (
                <div
                  key={drv.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center font-bold text-white text-base">
                        {drv.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-sm">{drv.name}</h4>
                        <p className="text-xs text-slate-400">{drv.phone} · {drv.email}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => vtcStore.toggleDriverStatus(drv.id)}
                      className={`px-3 py-1 rounded-full text-xs font-bold border transition ${
                        drv.isOnline
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {drv.isOnline ? 'En service' : 'Déconnecté'}
                    </button>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-xs grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-slate-500 text-[10px]">Véhicule</p>
                      <p className="font-semibold text-white">{drv.vehicle.model}</p>
                      <p className="text-slate-400 text-[10px]">{drv.vehicle.plate} · {drv.vehicle.category}</p>
                    </div>
                    <div>
                      <p className="text-slate-500 text-[10px]">Gains du jour</p>
                      <p className="font-bold text-emerald-400">{formatEuro(drv.todayEarnings)}</p>
                      <p className="text-amber-400 text-[10px]">⭐ {drv.rating.toFixed(2)} ({drv.totalRides} courses)</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. DISPATCH SOS TAB */}
        {activeTab === 'DISPATCH_SOS' && (
          <div className="p-6 overflow-y-auto h-full max-w-3xl mx-auto space-y-5">
            <div className="bg-rose-500/10 border border-rose-500/30 rounded-3xl p-5 flex items-start gap-4">
              <ShieldAlert className="w-10 h-10 text-rose-500 flex-shrink-0" />
              <div>
                <h3 className="font-bold text-base text-rose-400">Console de Sécurité & Urgence Dispatch</h3>
                <p className="text-xs text-rose-300/80 mt-1">
                  Surveillance des alertes passagers et chauffeurs en temps réel. Accès direct aux lignes d'urgence et intervention prioritaire.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
                <h4 className="font-bold text-sm text-white flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>Liaison Directe Police Secours</span>
                </h4>
                <p className="text-xs text-slate-400">
                  En cas d'incident critique avéré sur un véhicule ou un client.
                </p>
                <a
                  href="tel:17"
                  className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Composer le 17 (Police)</span>
                </a>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
                <h4 className="font-bold text-sm text-white flex items-center gap-2">
                  <Radio className="w-4 h-4 text-yellow-400" />
                  <span>Alerte Générale Flotte</span>
                </h4>
                <p className="text-xs text-slate-400">
                  Diffuser une consigne de sécurité à l'ensemble des chauffeurs connectés.
                </p>
                <button
                  onClick={() => handleTriggerPreset('sos_alert')}
                  className="w-full py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 transition"
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span>Diffuser Alerte Prioritaire</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 5. PRICING TAB */}
        {activeTab === 'PRICING' && (
          <div className="p-6 overflow-y-auto h-full max-w-2xl mx-auto space-y-6">
            <h3 className="font-bold text-lg text-white">Gestion de la Tarification Dynamique (Surge)</h3>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="font-semibold text-sm text-white">Coefficient de majoration en direct</label>
                  <span className="font-bold text-xl text-amber-400 bg-amber-400/10 px-3 py-1 rounded-xl border border-amber-400/20">
                    x{surgeMultiplier.toFixed(1)}
                  </span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="2.5"
                  step="0.1"
                  value={surgeMultiplier}
                  onChange={(e) => vtcStore.setSurgeMultiplier(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-[11px] text-slate-500 mt-2">
                  <span>1.0x (Normal)</span>
                  <span>1.5x (Pluie / Heures de pointe)</span>
                  <span>2.5x (Nouvel An / Tempête)</span>
                </div>
              </div>

              {/* Automation Toggle */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-sm text-white">Chauffeur IA Autonome</h4>
                  <p className="text-xs text-slate-400">Accepte automatiquement les courses et simule le trajet GPS en temps réel</p>
                </div>
                <button
                  onClick={() => vtcStore.setAutoSimulateDriver(!autoSimulate)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition border ${
                    autoSimulate
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  {autoSimulate ? 'Activé' : 'Désactivé'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
