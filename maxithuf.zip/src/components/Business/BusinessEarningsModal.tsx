import React, { useState } from 'react';
import { 
  ArrowLeft, 
  TrendingUp, 
  ShoppingBag, 
  Receipt, 
  Percent, 
  LineChart 
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';

interface BusinessEarningsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessEarningsModal: React.FC<BusinessEarningsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const [period, setPeriod] = useState<'Today' | 'Week' | 'Month' | 'Custom'>('Today');

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col select-none animate-in fade-in duration-200">
      <div className={`h-full w-full flex flex-col overflow-hidden transition-colors ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
      }`}>
        {/* Top Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">My earnings</h2>
          <div className="w-9" />
        </header>

        {/* Period Tabs (Screenshot 7: Today, Week, Month, Custom) */}
        <div className={`px-5 py-2.5 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          {(['Today', 'Week', 'Month', 'Custom'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setPeriod(tab)}
              className={`py-2 px-3 text-xs font-bold transition relative ${
                period === tab 
                  ? 'text-yellow-400' 
                  : isLight ? 'text-slate-500 hover:text-black' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {tab}
              {period === tab && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-yellow-400 rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 max-w-lg mx-auto w-full">
          {/* Main Net Earnings Card (Screenshot 7) */}
          <div className={`p-6 rounded-3xl border text-center space-y-1 shadow-sm ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
          }`}>
            <p className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Net earnings
            </p>
            <h1 className="text-3xl font-extrabold text-emerald-500">
              {formatEuro(business.todaySales)}
            </h1>
            <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Balance: {formatEuro(business.balance)}
            </p>
          </div>

          {/* 4 Metrics Cards (Screenshot 7) */}
          <div className="grid grid-cols-2 gap-3">
            {/* Total sales */}
            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <ShoppingBag className="w-4 h-4 text-yellow-500 mb-1.5" />
              <p className="text-lg font-bold">{formatEuro(business.todaySales)}</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Total sales</p>
            </div>

            {/* Commissions */}
            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <Percent className="w-4 h-4 text-rose-500 mb-1.5" />
              <p className="text-lg font-bold text-rose-500">-{formatEuro(business.commissions || 0)}</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Commissions</p>
            </div>

            {/* Orders */}
            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <Receipt className="w-4 h-4 text-sky-400 mb-1.5" />
              <p className="text-lg font-bold">{business.todayOrders}</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Orders</p>
            </div>

            {/* Average per order */}
            <div className={`p-4 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <TrendingUp className="w-4 h-4 text-amber-500 mb-1.5" />
              <p className="text-lg font-bold">€0.00</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>Average per order</p>
            </div>
          </div>

          {/* Order history */}
          <div className="pt-2 space-y-3">
            <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Order history
            </h3>

            <div className={`p-10 rounded-3xl border text-center space-y-2 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
            }`}>
              <Receipt className="w-10 h-10 mx-auto text-neutral-500" />
              <p className="font-bold text-sm">No orders</p>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                Completed sales in this period will be shown here.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
