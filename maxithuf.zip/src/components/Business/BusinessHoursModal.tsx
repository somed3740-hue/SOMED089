import React, { useState } from 'react';
import { ArrowLeft, Clock, Check } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { BusinessDaySchedule } from '../../types/vtc';

interface BusinessHoursModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BusinessHoursModal: React.FC<BusinessHoursModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const business = vtcStore.getBusiness();
  const [schedule, setSchedule] = useState<BusinessDaySchedule[]>(
    business.schedule || [
      { day: 'Monday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
      { day: 'Tuesday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
      { day: 'Wednesday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
      { day: 'Thursday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
      { day: 'Friday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
      { day: 'Saturday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
      { day: 'Sunday', isOpen: false, openTime: '09:00', closeTime: '22:00' },
    ]
  );
  const [isSaved, setIsSaved] = useState(false);

  const toggleDay = (index: number) => {
    setSchedule(prev => {
      const next = [...prev];
      next[index] = { ...next[index], isOpen: !next[index].isOpen };
      return next;
    });
  };

  const updateHours = (index: number, openTime: string, closeTime: string) => {
    setSchedule(prev => {
      const next = [...prev];
      next[index] = { ...next[index], openTime, closeTime };
      return next;
    });
  };

  const handleSave = () => {
    vtcStore.updateBusinessSchedule(schedule);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col select-none animate-in fade-in duration-200">
      <div className={`h-full w-full flex flex-col overflow-hidden transition-colors ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
      }`}>
        {/* Top Header (Screenshot 10) */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Business hours</h2>
          <button
            onClick={handleSave}
            className="text-xs font-bold text-yellow-400 hover:text-yellow-300 px-3 py-1.5 rounded-lg active:scale-95 transition"
          >
            {isSaved ? 'Saved!' : 'Save'}
          </button>
        </header>

        {/* Content Body (Screenshot 10: Monday to Sunday switches) */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 max-w-lg mx-auto w-full">
          {schedule.map((item, index) => (
            <div
              key={item.day}
              className={`p-4 rounded-2xl border transition shadow-sm ${
                isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm">{item.day}</span>

                <div className="flex items-center gap-3">
                  <span className={`text-xs font-medium ${
                    item.isOpen ? 'text-emerald-500' : 'text-rose-400'
                  }`}>
                    {item.isOpen ? `${item.openTime} - ${item.closeTime}` : 'Cerrado'}
                  </span>

                  <button
                    type="button"
                    onClick={() => toggleDay(index)}
                    className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                      item.isOpen ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full shadow transform transition duration-200 ${
                      item.isOpen 
                        ? 'translate-x-5 bg-black' 
                        : 'translate-x-0 bg-white'
                    }`} />
                  </button>
                </div>
              </div>

              {item.isOpen && (
                <div className="mt-3 pt-3 border-t border-neutral-800/60 flex items-center justify-between text-xs">
                  <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Opening times:</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={item.openTime}
                      onChange={(e) => updateHours(index, e.target.value, item.closeTime)}
                      className={`px-2 py-1 rounded-lg border text-xs font-mono ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    />
                    <span>to</span>
                    <input
                      type="time"
                      value={item.closeTime}
                      onChange={(e) => updateHours(index, item.openTime, e.target.value)}
                      className={`px-2 py-1 rounded-lg border text-xs font-mono ${
                        isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                      }`}
                    />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
