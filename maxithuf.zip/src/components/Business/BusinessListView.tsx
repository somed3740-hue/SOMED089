import React, { useState } from 'react';
import { 
  Store, 
  Plus, 
  Check, 
  ChevronRight, 
  Trash2, 
  ShoppingBag, 
  MapPin, 
  Phone, 
  Mail, 
  Star,
  ExternalLink,
  Edit3
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';
import { BusinessProfile } from '../../types/vtc';
import { useTranslation } from '../../utils/i18n';

interface BusinessListViewProps {
  onSelectBusiness: (businessId: string) => void;
  onOpenVitrine: (businessId: string) => void;
  onOpenNewBusinessModal: () => void;
  onOpenEditProfile: (businessId: string) => void;
}

export const BusinessListView: React.FC<BusinessListViewProps> = ({
  onSelectBusiness,
  onOpenVitrine,
  onOpenNewBusinessModal,
  onOpenEditProfile,
}) => {
  const isLight = vtcStore.isLightMode();
  const businesses = vtcStore.getAllBusinesses();
  const activeBusinessId = vtcStore.getActiveBusinessId();
  const { lang, t } = useTranslation();
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (businesses.length <= 1) {
      alert('Vous devez conserver au moins un commerce actif.');
      return;
    }
    vtcStore.deleteBusiness(id);
    setDeleteConfirmId(null);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto select-none">
      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-yellow-400/20 border border-yellow-400/40 flex items-center justify-center text-yellow-500">
            <Store className="w-4 h-4" />
          </div>
          <div>
            <h1 className="font-extrabold text-base tracking-tight">{t('bizBusinessesTitle')}</h1>
            <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              {businesses.length} {t('bizBusinesses').toLowerCase()}
            </p>
          </div>
        </div>

        {/* Primary + Button to add business */}
        <button
          onClick={onOpenNewBusinessModal}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs transition active:scale-95 shadow-md shadow-yellow-400/20"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>{t('bizAddBusiness')}</span>
        </button>
      </header>

      {/* Main Container */}
      <div className="p-5 space-y-4 max-w-lg mx-auto w-full pb-28">
        {/* Banner Explainer */}
        <div className={`p-4 rounded-2xl border flex items-center justify-between ${
          isLight ? 'bg-amber-50/70 border-amber-200 text-amber-900' : 'bg-yellow-950/20 border-yellow-800/40 text-yellow-200'
        }`}>
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-yellow-500 flex-shrink-0" />
            <p className="text-xs leading-relaxed font-medium">
              Gérez autant de commerces et de vitrines produits que vous le souhaitez. Basculez d’un simple clic.
            </p>
          </div>
        </div>

        {/* List of Businesses */}
        <div className="space-y-3.5">
          {businesses.map((biz: BusinessProfile) => {
            const isActive = biz.id === activeBusinessId;
            const productCount = biz.products?.length || 0;

            return (
              <div
                key={biz.id}
                onClick={() => onSelectBusiness(biz.id)}
                className={`relative rounded-3xl border transition overflow-hidden cursor-pointer group shadow-sm ${
                  isActive
                    ? isLight
                      ? 'border-yellow-400 bg-white ring-2 ring-yellow-400/30 shadow-md'
                      : 'border-yellow-400/80 bg-neutral-950 ring-2 ring-yellow-400/20 shadow-md'
                    : isLight
                      ? 'border-slate-200 bg-white hover:border-slate-300'
                      : 'border-neutral-900 bg-neutral-950 hover:border-neutral-800'
                }`}
              >
                {/* Banner / Header Image */}
                <div className="h-24 w-full relative overflow-hidden bg-neutral-900">
                  <img
                    src={biz.bannerUrl || 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&auto=format&fit=crop&q=80'}
                    alt={biz.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                  {/* Active Indicator Badge */}
                  {isActive && (
                    <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-emerald-500 text-white text-[10px] font-black tracking-wide flex items-center gap-1 shadow-lg">
                      <Check className="w-3 h-3 stroke-[3]" />
                      <span>ACTIF</span>
                    </div>
                  )}

                  {/* Rating Badge */}
                  <div className="absolute bottom-2.5 right-3 px-2 py-0.5 rounded-lg bg-black/60 backdrop-blur-md text-yellow-400 text-[11px] font-bold flex items-center gap-1">
                    <Star className="w-3 h-3 fill-yellow-400" />
                    <span>{biz.rating ? biz.rating.toFixed(1) : '5.0'}</span>
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <h3 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                        <span>{biz.name}</span>
                        {biz.isOpen ? (
                          <span className="w-2 h-2 rounded-full bg-emerald-500" title="Ouvert" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-rose-500" title="Fermé" />
                        )}
                      </h3>

                      {biz.address && (
                        <p className={`text-xs flex items-center gap-1.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                          <MapPin className="w-3 h-3 flex-shrink-0 text-neutral-500" />
                          <span className="truncate max-w-[240px]">{biz.address}</span>
                        </p>
                      )}

                      {biz.phone && (
                        <p className={`text-xs flex items-center gap-1.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                          <Phone className="w-3 h-3 flex-shrink-0 text-neutral-500" />
                          <span>{biz.phone}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Stats Pill Row */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div className={`p-2.5 rounded-xl border flex items-center gap-2.5 ${
                      isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
                    }`}>
                      <ShoppingBag className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                      <div>
                        <p className="text-[10px] font-medium text-neutral-400">Vitrine</p>
                        <p className="text-xs font-bold">{productCount} produit{productCount > 1 ? 's' : ''}</p>
                      </div>
                    </div>

                    <div className={`p-2.5 rounded-xl border flex items-center gap-2.5 ${
                      isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
                    }`}>
                      <Store className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                      <div>
                        <p className="text-[10px] font-medium text-neutral-400">Solde caisse</p>
                        <p className="text-xs font-bold text-emerald-500">{formatEuro(biz.balance || 0)}</p>
                      </div>
                    </div>
                  </div>

                  {/* Quick Action Buttons */}
                  <div className="pt-2 flex items-center gap-2">
                    {/* Access Showcase (Vitrine) */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectBusiness(biz.id);
                        onOpenVitrine(biz.id);
                      }}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black flex items-center justify-center gap-1.5 transition active:scale-95 shadow-sm"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{t('bizManageShowcase')} ({productCount})</span>
                    </button>

                    {/* Set Active / Selected */}
                    {!isActive && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectBusiness(biz.id);
                        }}
                        className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition active:scale-95 ${
                          isLight 
                            ? 'border-slate-300 hover:bg-slate-100 text-slate-700' 
                            : 'border-neutral-800 hover:bg-neutral-900 text-neutral-300'
                        }`}
                      >
                        {t('bizActivate')}
                      </button>
                    )}

                    {/* Delete Option if multiple */}
                    {businesses.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (deleteConfirmId === biz.id) {
                            handleDelete(biz.id, e);
                          } else {
                            setDeleteConfirmId(biz.id);
                            setTimeout(() => setDeleteConfirmId(null), 3000);
                          }
                        }}
                        className={`p-2.5 rounded-xl border transition active:scale-95 ${
                          deleteConfirmId === biz.id
                            ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                            : isLight
                              ? 'border-slate-200 text-slate-400 hover:text-rose-500 hover:bg-rose-50'
                              : 'border-neutral-900 text-neutral-500 hover:text-rose-400 hover:bg-neutral-900'
                        }`}
                        title={deleteConfirmId === biz.id ? t('confirm') : t('delete')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Big Yellow Add Business Card */}
        <button
          onClick={onOpenNewBusinessModal}
          className={`w-full p-5 rounded-3xl border-2 border-dashed transition flex flex-col items-center justify-center text-center gap-2 group active:scale-[0.98] ${
            isLight
              ? 'border-yellow-400/80 bg-yellow-50/50 hover:bg-yellow-100/60 text-slate-800'
              : 'border-yellow-400/60 bg-yellow-400/5 hover:bg-yellow-400/10 text-white'
          }`}
        >
          <div className="w-12 h-12 rounded-2xl bg-yellow-400 text-black flex items-center justify-center shadow-lg shadow-yellow-400/25 group-hover:scale-110 transition duration-200">
            <Plus className="w-6 h-6 stroke-[3]" />
          </div>
          <div>
            <p className="font-extrabold text-sm text-yellow-500">{t('bizAddNewBusiness')}</p>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              {t('bizBusinessesSubtitle')}
            </p>
          </div>
        </button>
      </div>
    </div>
  );
};
