import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Store, 
  Mail, 
  MapPin, 
  Search, 
  CreditCard, 
  Landmark, 
  PiggyBank, 
  FileText, 
  ChevronDown,
  CheckCircle2
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface NewBusinessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated?: (businessId: string) => void;
}

const COUNTRY_CODES = [
  { code: '+33', flag: '🇫🇷', name: 'France' },
  { code: '+212', flag: '🇲🇦', name: 'Maroc' },
  { code: '+34', flag: '🇪🇸', name: 'Espagne' },
  { code: '+1', flag: '🇺🇸', name: 'États-Unis' },
  { code: '+44', flag: '🇬🇧', name: 'Royaume-Uni' },
  { code: '+49', flag: '🇩🇪', name: 'Allemagne' },
  { code: '+39', flag: '🇮🇹', name: 'Italie' },
  { code: '+32', flag: '🇧🇪', name: 'Belgique' },
  { code: '+41', flag: '🇨🇭', name: 'Suisse' },
  { code: '+221', flag: '🇸🇳', name: 'Sénégal' },
  { code: '+225', flag: '🇨🇮', name: 'Côte d’Ivoire' },
];

export const NewBusinessModal: React.FC<NewBusinessModalProps> = ({
  isOpen,
  onClose,
  onCreated,
}) => {
  if (!isOpen) return null;

  const passenger = vtcStore.getPassenger();

  const [businessName, setBusinessName] = useState('');
  const [countryCode, setCountryCode] = useState('+33');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [address, setAddress] = useState('');
  const [taxId, setTaxId] = useState('');
  const [bankName, setBankName] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [accountType, setAccountType] = useState('Courant / Checking');
  const [legalRepId, setLegalRepId] = useState('');

  // Validation errors matching Screenshot_20261004-232406
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const nameError = hasAttemptedSubmit && !businessName.trim();
  const addressError = hasAttemptedSubmit && !address.trim();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasAttemptedSubmit(true);

    if (!businessName.trim() || !address.trim()) {
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const fullPhone = `${countryCode} ${phoneNumber.trim() || '10 1234 5678'}`;
      const newBiz = vtcStore.addBusiness({
        name: businessName.trim(),
        phone: fullPhone,
        countryCode,
        email: contactEmail.trim() || passenger.email || 'contact@somed.biz',
        address: address.trim(),
        taxId: taxId.trim(),
        bankName: bankName.trim(),
        bankAccount: bankAccount.trim(),
        accountType,
        legalRepId: legalRepId.trim(),
      });

      setIsSubmitting(false);
      onCreated?.(newBiz.id);
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-[1400] bg-black text-white flex flex-col select-none overflow-y-auto animate-in fade-in duration-200">
      {/* Top Header matching Screenshot_20261004-232337 */}
      <header className="px-5 py-4 border-b border-neutral-900 bg-black/95 backdrop-blur-md sticky top-0 z-20 flex items-center justify-between">
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-neutral-900 text-neutral-300 transition active:scale-95"
          title="Retour"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="font-bold text-base tracking-tight">New business</h1>
        <div className="w-10" />
      </header>

      {/* Main Form Container */}
      <form onSubmit={handleSubmit} className="flex-1 max-w-lg mx-auto w-full p-5 space-y-4 pb-20">
        {/* Intro Subtitle */}
        <p className="text-xs text-neutral-400 leading-relaxed font-normal mb-2">
          Fill in your business details. It will be reviewed and approved by the administrator.
        </p>

        {/* 1. Business Name */}
        <div className="space-y-1">
          <div className={`flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-neutral-950 border transition ${
            nameError 
              ? 'border-rose-600 ring-1 ring-rose-600/40' 
              : 'border-neutral-900 focus-within:border-yellow-400/80 focus-within:ring-1 focus-within:ring-yellow-400/40'
          }`}>
            <Store className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <input
              type="text"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="Business name"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-medium"
            />
          </div>
          {nameError && (
            <p className="text-[11px] text-rose-500 font-semibold px-2">
              Name is required
            </p>
          )}
        </div>

        {/* 2. Business Phone with Country Code Picker */}
        <div className="space-y-1.5">
          <label className="text-xs text-neutral-400 font-semibold block px-1">
            Business phone
          </label>
          <div className="flex gap-2">
            {/* Country selector */}
            <div className="relative flex-shrink-0">
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="appearance-none bg-neutral-950 border border-neutral-900 text-sm text-white font-medium pl-3 pr-8 py-3.5 rounded-2xl focus:outline-none focus:border-yellow-400/80 cursor-pointer"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code + c.name} value={c.code} className="bg-neutral-900 text-white">
                    {c.flag} {c.code} ({c.name})
                  </option>
                ))}
              </select>
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-500">
                <ChevronDown className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Phone input */}
            <div className="flex-1 flex items-center px-4 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80 focus-within:ring-1 focus-within:ring-yellow-400/40">
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="10 1234 5678"
                className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-mono"
              />
            </div>
          </div>
        </div>

        {/* 3. Contact Email */}
        <div className="space-y-1">
          <div className="flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80 focus-within:ring-1 focus-within:ring-yellow-400/40">
            <Mail className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <input
              type="email"
              value={contactEmail}
              onChange={(e) => setContactEmail(e.target.value)}
              placeholder="Contact email"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-medium"
            />
          </div>
          <p className="text-[11px] text-neutral-500 px-2">
            If different from your account email
          </p>
        </div>

        {/* 4. Business Address */}
        <div className="space-y-1">
          <div className={`flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-neutral-950 border transition ${
            addressError 
              ? 'border-rose-600 ring-1 ring-rose-600/40' 
              : 'border-neutral-900 focus-within:border-yellow-400/80 focus-within:ring-1 focus-within:ring-yellow-400/40'
          }`}>
            <MapPin className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Business address"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-medium"
            />
            <button
              type="button"
              className="text-neutral-500 hover:text-white transition"
              title="Search address"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
          {addressError && (
            <p className="text-[11px] text-rose-500 font-semibold px-2">
              Address is required
            </p>
          )}
        </div>

        {/* 5. Tax ID (RUT / RFC / NIT) */}
        <div>
          <div className="flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80 focus-within:ring-1 focus-within:ring-yellow-400/40">
            <CreditCard className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <input
              type="text"
              value={taxId}
              onChange={(e) => setTaxId(e.target.value)}
              placeholder="Tax ID (RUT / RFC / NIT)"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-medium"
            />
          </div>
        </div>

        {/* 6. Bank & Bank Account side by side */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2.5 px-3.5 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80">
            <Landmark className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <input
              type="text"
              value={bankName}
              onChange={(e) => setBankName(e.target.value)}
              placeholder="Bank"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-medium"
            />
          </div>

          <div className="flex items-center px-3.5 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80">
            <input
              type="text"
              value={bankAccount}
              onChange={(e) => setBankAccount(e.target.value)}
              placeholder="Bank account"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-mono"
            />
          </div>
        </div>

        {/* 7. Account type Dropdown */}
        <div className="relative">
          <div className="flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80">
            <PiggyBank className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <select
              value={accountType}
              onChange={(e) => setAccountType(e.target.value)}
              className="w-full bg-transparent text-sm text-white focus:outline-none font-medium appearance-none cursor-pointer pr-6"
            >
              <option value="Courant / Checking" className="bg-neutral-900 text-white">Courant / Checking</option>
              <option value="Épargne / Savings" className="bg-neutral-900 text-white">Épargne / Savings</option>
              <option value="Professionnel / Business" className="bg-neutral-900 text-white">Professionnel / Business</option>
            </select>
            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-500">
              <ChevronDown className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* 8. Legal Representative ID */}
        <div>
          <div className="flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-neutral-950 border border-neutral-900 focus-within:border-yellow-400/80 focus-within:ring-1 focus-within:ring-yellow-400/40">
            <FileText className="w-4 h-4 text-neutral-500 flex-shrink-0" />
            <input
              type="text"
              value={legalRepId}
              onChange={(e) => setLegalRepId(e.target.value)}
              placeholder="Legal representative ID"
              className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none font-medium"
            />
          </div>
        </div>

        {/* 9. Submit Request Button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 px-6 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] shadow-lg shadow-yellow-400/20"
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : (
              <span>Submit request</span>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
