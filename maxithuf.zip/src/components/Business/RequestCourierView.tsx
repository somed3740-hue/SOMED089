import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  Bike, 
  Banknote, 
  QrCode, 
  CheckCircle2, 
  Repeat, 
  AlertCircle,
  Plus,
  Minus,
  Navigation,
  Globe
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { formatEuro } from '../../utils/geo';

interface RequestCourierViewProps {
  onBack?: () => void;
  onSuccess?: () => void;
}

export const RequestCourierView: React.FC<RequestCourierViewProps> = ({
  onBack,
  onSuccess,
}) => {
  const isLight = vtcStore.isLightMode();

  // Form state
  const [countryCode, setCountryCode] = useState('+212');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('18 avenue idrissides, Ménara, Marrakech');
  const [serviceType, setServiceType] = useState<'DELIVER_AND_COLLECT' | 'DELIVER_ONLY'>('DELIVER_AND_COLLECT');
  const [orderValue, setOrderValue] = useState('31.00');
  const [prepTimeMin, setPrepTimeMin] = useState(15);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'BANK_TRANSFER'>('CASH');
  const [changeReq, setChangeReq] = useState<'EXACT_AMOUNT' | 'NEEDS_CHANGE'>('EXACT_AMOUNT');
  const [notes, setNotes] = useState('');

  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  const isValid = customerName.trim().length > 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid) return;

    vtcStore.requestCourier({
      customerPhone,
      customerCountryCode: countryCode,
      customerName: customerName.trim(),
      customerAddress: customerAddress.trim() || 'Marrakech Centre',
      serviceType,
      orderValue: parseFloat(orderValue) || 0,
      prepTimeMin,
      paymentMethod,
      changeRequirement: changeReq,
      notes: notes.trim() || undefined,
    });

    setSubmittedMessage('Coursier demandé avec succès ! Recherche d\'un livreur à proximité...');
    setTimeout(() => {
      setSubmittedMessage(null);
      if (onSuccess) onSuccess();
    }, 2000);
  };

  return (
    <div className={`h-full w-full flex flex-col select-none overflow-y-auto transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Header (Screenshots 5, 6) */}
      <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        {onBack ? (
          <button
            onClick={onBack}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        ) : (
          <div className="w-9" />
        )}
        <h2 className="font-bold text-base">Request courier</h2>
        <div className="w-9" />
      </header>

      {/* Form Content */}
      <form onSubmit={handleSubmit} className="flex-1 max-w-lg mx-auto w-full p-5 space-y-6 pb-24">
        {/* Customer Section */}
        <div className="space-y-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-yellow-500">Customer</h3>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Type the phone number to search
            </p>
          </div>

          <div className="flex gap-2">
            <div className={`flex items-center gap-1.5 px-3 py-2.5 rounded-2xl border flex-shrink-0 ${
              isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-neutral-950 border-neutral-900 text-white'
            }`}>
              <Globe className="w-4 h-4 text-sky-400" />
              <select 
                value={countryCode} 
                onChange={(e) => setCountryCode(e.target.value)}
                className="bg-transparent font-bold text-xs focus:outline-none cursor-pointer"
              >
                <option value="+212" className="bg-black text-white">+212</option>
                <option value="+33" className="bg-black text-white">+33</option>
                <option value="+34" className="bg-black text-white">+34</option>
              </select>
            </div>

            <input
              type="tel"
              placeholder="Customer phone"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              className={`flex-1 px-4 py-2.5 rounded-2xl border text-sm font-medium focus:outline-none focus:border-yellow-400 ${
                isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
              }`}
            />
          </div>

          <input
            type="text"
            required
            placeholder="Customer name"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            className={`w-full px-4 py-3 rounded-2xl border text-sm font-medium focus:outline-none focus:border-yellow-400 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
            }`}
          />
        </div>

        {/* Delivery Address */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-yellow-500">Delivery</h3>
          <input
            type="text"
            placeholder="Customer address (optional if unknown)"
            value={customerAddress}
            onChange={(e) => setCustomerAddress(e.target.value)}
            className={`w-full px-4 py-3 rounded-2xl border text-sm font-medium focus:outline-none focus:border-yellow-400 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
            }`}
          />

          <button
            type="button"
            className="flex items-center gap-1.5 text-xs font-bold text-yellow-400 hover:underline pt-1"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Adjust location on the map</span>
          </button>
        </div>

        {/* Service Type (Screenshot 6: Deliver and collect vs Deliver only) */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-yellow-500">Service type</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setServiceType('DELIVER_AND_COLLECT')}
              className={`p-4 rounded-2xl text-left border transition ${
                serviceType === 'DELIVER_AND_COLLECT'
                  ? 'border-yellow-400 bg-yellow-400/10 shadow-sm ring-1 ring-yellow-400'
                  : isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
              }`}
            >
              <Banknote className="w-5 h-5 text-yellow-400 mb-2" />
              <p className="font-bold text-xs text-yellow-400">Deliver and collect</p>
              <p className={`text-[10px] mt-0.5 leading-tight ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Driver collects from the customer
              </p>
            </button>

            <button
              type="button"
              onClick={() => setServiceType('DELIVER_ONLY')}
              className={`p-4 rounded-2xl text-left border transition ${
                serviceType === 'DELIVER_ONLY'
                  ? 'border-yellow-400 bg-yellow-400/10 shadow-sm ring-1 ring-yellow-400'
                  : isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
              }`}
            >
              <Bike className="w-5 h-5 text-emerald-400 mb-2" />
              <p className="font-bold text-xs">Deliver only</p>
              <p className={`text-[10px] mt-0.5 leading-tight ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Customer already paid
              </p>
            </button>
          </div>
        </div>

        {/* Order value (what the driver collects) */}
        {serviceType === 'DELIVER_AND_COLLECT' && (
          <div className="space-y-1">
            <label className="text-xs font-semibold">Order value (what the driver collects)</label>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                placeholder="31.00"
                value={orderValue}
                onChange={(e) => setOrderValue(e.target.value)}
                className={`w-full px-4 py-3 rounded-2xl border text-base font-bold ${
                  isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
                }`}
              />
              <span className="absolute right-4 top-3.5 font-bold text-xs text-neutral-400">EUR</span>
            </div>
          </div>
        )}

        {/* Preparation Time (Screenshot 5: [-] 15 [+] minutes tap to type) */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-yellow-500">Preparation time</h3>
          <div className={`p-4 rounded-3xl border flex items-center justify-between ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
          }`}>
            <button
              type="button"
              onClick={() => setPrepTimeMin(prev => Math.max(5, prev - 5))}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center transition active:scale-95 ${
                isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400'
              }`}
            >
              <Minus className="w-5 h-5 stroke-[3]" />
            </button>

            <div className="text-center">
              <span className="text-3xl font-black">{prepTimeMin}</span>
              <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                minutes (tap to type)
              </p>
            </div>

            <button
              type="button"
              onClick={() => setPrepTimeMin(prev => prev + 5)}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center transition active:scale-95 ${
                isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-900 hover:bg-neutral-800 text-yellow-400'
              }`}
            >
              <Plus className="w-5 h-5 stroke-[3]" />
            </button>
          </div>
        </div>

        {/* Customer Payment Method (Screenshot 5) */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-yellow-500">Customer payment method</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setPaymentMethod('CASH')}
              className={`p-4 rounded-2xl text-center border transition flex flex-col items-center justify-center gap-1.5 ${
                paymentMethod === 'CASH'
                  ? 'border-yellow-400 bg-yellow-400/10 ring-1 ring-yellow-400'
                  : isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
              }`}
            >
              <Banknote className="w-6 h-6 text-yellow-400" />
              <span className="font-bold text-xs">Cash</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('BANK_TRANSFER')}
              className={`p-4 rounded-2xl text-center border transition flex flex-col items-center justify-center gap-1.5 ${
                paymentMethod === 'BANK_TRANSFER'
                  ? 'border-yellow-400 bg-yellow-400/10 ring-1 ring-yellow-400'
                  : isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
              }`}
            >
              <QrCode className="w-6 h-6 text-sky-400" />
              <span className="font-bold text-xs">Bank Transfer</span>
            </button>
          </div>
        </div>

        {/* Change Requirement (Screenshot 5) */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setChangeReq('EXACT_AMOUNT')}
            className={`p-4 rounded-2xl text-center border transition flex flex-col items-center justify-center gap-1 ${
              changeReq === 'EXACT_AMOUNT'
                ? 'border-yellow-400 bg-yellow-400/10 ring-1 ring-yellow-400'
                : isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
            }`}
          >
            <CheckCircle2 className="w-5 h-5 text-yellow-400" />
            <span className="font-bold text-xs text-yellow-400">Exact amount</span>
            <span className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>No change needed</span>
          </button>

          <button
            type="button"
            onClick={() => setChangeReq('NEEDS_CHANGE')}
            className={`p-4 rounded-2xl text-center border transition flex flex-col items-center justify-center gap-1 ${
              changeReq === 'NEEDS_CHANGE'
                ? 'border-yellow-400 bg-yellow-400/10 ring-1 ring-yellow-400'
                : isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900 text-neutral-300'
            }`}
          >
            <Repeat className="w-5 h-5 text-neutral-400" />
            <span className="font-bold text-xs">Needs change</span>
            <span className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Bring change</span>
          </button>
        </div>

        {/* Notes for driver */}
        <div className="space-y-1">
          <label className="text-xs font-semibold">Notes for the driver (optional)</label>
          <input
            type="text"
            placeholder="e.g. Ring intercom #4B, call upon arrival"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className={`w-full px-4 py-3 rounded-2xl border text-xs font-medium focus:outline-none focus:border-yellow-400 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
            }`}
          />
        </div>

        {/* Notice badge (Screenshot 5: Missing the name of the person receiving) */}
        {!isValid && (
          <p className="text-xs text-neutral-400 flex items-center justify-center gap-1.5 pt-1">
            <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
            <span>Missing the name of the person receiving</span>
          </p>
        )}

        {submittedMessage && (
          <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold text-center">
            {submittedMessage}
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={!isValid}
          className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-xl transition active:scale-95 ${
            isValid
              ? 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-yellow-400/20'
              : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-800'
          }`}
        >
          <Bike className="w-5 h-5" />
          <span>Request courier</span>
        </button>
      </form>
    </div>
  );
};
