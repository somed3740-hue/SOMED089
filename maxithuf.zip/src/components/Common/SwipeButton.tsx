import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChevronRight, Check } from 'lucide-react';
import { soundEffects } from '../../utils/audio';

interface SwipeButtonProps {
  label: string;
  onConfirm: () => void;
  variant?: 'emerald' | 'blue' | 'yellow' | 'rose' | 'amber';
  icon?: React.ReactNode;
  disabled?: boolean;
  className?: string;
}

export const SwipeButton: React.FC<SwipeButtonProps> = ({
  label,
  onConfirm,
  variant = 'emerald',
  icon,
  disabled = false,
  className = '',
}) => {
  const [sliderPosition, setSliderPosition] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const startXRef = useRef<number>(0);
  const maxDragRef = useRef<number>(0);

  const getVariantStyles = () => {
    switch (variant) {
      case 'emerald':
        return {
          bg: 'bg-emerald-950/80 border-emerald-500/40',
          fill: 'bg-emerald-600',
          thumb: 'bg-emerald-500 text-white shadow-emerald-500/50',
          text: 'text-emerald-300',
        };
      case 'blue':
        return {
          bg: 'bg-blue-950/80 border-blue-500/40',
          fill: 'bg-blue-600',
          thumb: 'bg-blue-500 text-white shadow-blue-500/50',
          text: 'text-blue-300',
        };
      case 'yellow':
        return {
          bg: 'bg-yellow-950/80 border-yellow-500/40',
          fill: 'bg-yellow-500',
          thumb: 'bg-yellow-400 text-black shadow-yellow-500/50 font-black',
          text: 'text-yellow-300',
        };
      case 'rose':
        return {
          bg: 'bg-rose-950/80 border-rose-500/40',
          fill: 'bg-rose-600',
          thumb: 'bg-rose-500 text-white shadow-rose-500/50',
          text: 'text-rose-300',
        };
      case 'amber':
      default:
        return {
          bg: 'bg-amber-950/80 border-amber-500/40',
          fill: 'bg-amber-600',
          thumb: 'bg-amber-500 text-white shadow-amber-500/50',
          text: 'text-amber-300',
        };
    }
  };

  const styles = getVariantStyles();

  const handleStart = (clientX: number) => {
    if (disabled || isCompleted) return;
    setIsDragging(true);
    startXRef.current = clientX;
    if (containerRef.current) {
      const containerWidth = containerRef.current.clientWidth;
      const thumbWidth = 52; // width of circular thumb
      maxDragRef.current = containerWidth - thumbWidth - 8; // padding
    }
  };

  const handleMove = useCallback((clientX: number) => {
    if (!isDragging || disabled || isCompleted) return;
    const deltaX = clientX - startXRef.current;
    const bounded = Math.max(0, Math.min(deltaX, maxDragRef.current));
    setSliderPosition(bounded);

    // If dragged past 85%, complete the action!
    if (maxDragRef.current > 0 && bounded >= maxDragRef.current * 0.88) {
      setIsDragging(false);
      setIsCompleted(true);
      setSliderPosition(maxDragRef.current);
      
      // Haptic feedback
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate([50, 40, 70]);
        } catch {}
      }
      soundEffects.playSuccessSound();

      setTimeout(() => {
        onConfirm();
        // Reset after confirm
        setTimeout(() => {
          setIsCompleted(false);
          setSliderPosition(0);
        }, 500);
      }, 250);
    }
  }, [isDragging, disabled, isCompleted, onConfirm]);

  const handleEnd = useCallback(() => {
    if (!isDragging) return;
    setIsDragging(false);
    if (!isCompleted) {
      // Spring back to start
      setSliderPosition(0);
    }
  }, [isDragging, isCompleted]);

  useEffect(() => {
    const onTouchMove = (e: TouchEvent) => handleMove(e.touches[0].clientX);
    const onTouchEnd = () => handleEnd();
    const onMouseMove = (e: MouseEvent) => handleMove(e.clientX);
    const onMouseUp = () => handleEnd();

    if (isDragging) {
      window.addEventListener('touchmove', onTouchMove);
      window.addEventListener('touchend', onTouchEnd);
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
    }

    return () => {
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, [isDragging, handleMove, handleEnd]);

  const progressPercent = maxDragRef.current > 0 ? (sliderPosition / maxDragRef.current) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-14 rounded-2xl border overflow-hidden select-none p-1 flex items-center shadow-lg transition-all ${
        styles.bg
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'} ${className}`}
      onTouchStart={(e) => handleStart(e.touches[0].clientX)}
      onMouseDown={(e) => handleStart(e.clientX)}
    >
      {/* Dynamic Background Fill following thumb */}
      <div
        className={`absolute left-0 top-0 bottom-0 rounded-2xl transition-all duration-75 ${styles.fill} opacity-80`}
        style={{
          width: isCompleted ? '100%' : `${sliderPosition + 52}px`,
        }}
      />

      {/* Label Text Centered */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none px-14">
        <span
          className={`text-xs font-black tracking-wide uppercase transition-opacity ${
            styles.text
          } ${isDragging ? 'opacity-70' : 'opacity-100'} ${isCompleted ? 'text-white' : ''}`}
          style={{
            opacity: Math.max(0.15, 1 - (progressPercent / 60)),
          }}
        >
          {isCompleted ? 'Validé !' : label}
        </span>
      </div>

      {/* Draggable Circle Thumb */}
      <div
        className={`relative z-10 w-12 h-12 rounded-xl flex items-center justify-center shadow-xl transform transition-transform ${
          styles.thumb
        } ${isDragging ? 'scale-105' : 'scale-100'}`}
        style={{
          transform: `translateX(${sliderPosition}px)`,
          transition: isDragging ? 'none' : 'transform 0.25s cubic-bezier(0.2, 0.9, 0.3, 1.2)',
        }}
      >
        {isCompleted ? (
          <Check className="w-6 h-6 stroke-[3] animate-in zoom-in-75 duration-150" />
        ) : (
          icon || (
            <div className="flex items-center -space-x-1">
              <ChevronRight className="w-5 h-5 stroke-[2.5]" />
              <ChevronRight className="w-5 h-5 stroke-[2.5] opacity-50 -ml-2" />
            </div>
          )
        )}
      </div>
    </div>
  );
};
