import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Clock, 
  MapPin, 
  DollarSign, 
  User, 
  ChevronRight, 
  FileText, 
  Calendar, 
  CheckCircle2, 
  AlertCircle,
  Filter,
  Download,
  Share2,
  Mail,
  Send,
  Check,
  Search,
  SlidersHorizontal,
  X,
  Car,
  Receipt,
  ArrowUpRight,
  ArrowDownLeft,
  Sparkles,
  ShoppingBag,
  RotateCcw
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { Ride, DriverTransaction, CourierRequest } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';
import { DriverReceiptModal } from './DriverReceiptModal';
import { generateDriverBordereauPDF, generateInvoicePDF } from '../../utils/invoice';
import { soundEffects } from '../../utils/audio';

interface DriverActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'ALL' | 'TRIPS' | 'ORDERS' | 'INVOICES' | 'TRANSACTIONS';
}

export const DriverActivityModal: React.FC<DriverActivityModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'ALL',
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();
  const allRides = vtcStore.getAllRides();
  const courierRequests = vtcStore.getCourierRequests();

  // Filter rides for this driver or relevant rides
  const driverRides = allRides.filter((r) => r.driverId === driver.id || !r.driverId);

  const [activeTab, setActiveTab] = useState<'ALL' | 'TRIPS' | 'ORDERS' | 'INVOICES' | 'TRANSACTIONS'>(initialTab);
  const [filterPeriod, setFilterPeriod] = useState<'ALL' | 'TODAY' | 'WEEK'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRide, setSelectedRide] = useState<Ride | null>(null);

  // Email state
  const [emailModalRide, setEmailModalRide] = useState<Ride | null>(null);
  const [recipientEmail, setRecipientEmail] = useState(driver.email || 'chauffeur@somed.biz');
  const [emailSent, setEmailSent] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const now = Date.now();
  const oneDayMs = 24 * 3600 * 1000;
  const oneWeekMs = 7 * oneDayMs;

  const filteredRides = driverRides.filter((r) => {
    // Period filter
    if (filterPeriod === 'TODAY' && (now - r.createdAt) > oneDayMs) return false;
    if (filterPeriod === 'WEEK' && (now - r.createdAt) > oneWeekMs) return false;

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const pName = r.passengerName?.toLowerCase() || '';
      const pAddr = r.pickup?.address?.toLowerCase() || '';
      const dAddr = r.destination?.address?.toLowerCase() || '';
      const idMatch = r.id.toLowerCase().includes(q);
      return pName.includes(q) || pAddr.includes(q) || dAddr.includes(q) || idMatch;
    }
    return true;
  });

  const totalEarnings = filteredRides
    .filter((r) => r.status === 'COMPLETED')
    .reduce((sum, r) => sum + (r.fare * 0.8) + (r.tip || 0), 0);

  const totalKm = filteredRides
    .filter((r) => r.status === 'COMPLETED')
    .reduce((sum, r) => sum + (r.distanceKm || 0), 0);

  // Driver transactions
  const driverTransactions: DriverTransaction[] = driver.driverTransactions && driver.driverTransactions.length > 0
    ? driver.driverTransactions
    : [
        {
          id: 'tx-drv-1',
          type: 'REMITTANCE_SETTLED',
          title: 'Remise espèces validée',
          amount: 8.00,
          date: '19 sept 2026',
          time: '17:02',
          description: 'Remise d\'espèces encaissées pour la course #TMTZTPOCR',
          status: 'Completed',
          reference: 'FD-GCKBWM4M',
        },
        {
          id: 'tx-drv-2',
          type: 'COMMISSION',
          title: 'Commission plateforme (20%)',
          amount: -3.36,
          date: '19 sept 2026',
          time: '14:02',
          description: 'Commission sur course terminée (Tour Eiffel → Louvre)',
          status: 'Completed',
        },
        {
          id: 'tx-drv-3',
          type: 'REMITTANCE',
          title: 'Virement bancaire hebdomadaire',
          amount: 215.00,
          date: '18 sept 2026',
          time: '09:30',
          description: 'Paiement vers IBAN FR76 **** 9014',
          status: 'Completed',
        },
      ];

  const handleDownloadBordereau = (ride: Ride) => {
    soundEffects.playClick();
    const success = generateDriverBordereauPDF(ride, driver);
    if (success) {
      showToast('Bordereau PDF téléchargé !');
      vtcStore.sendPushNotification({
        title: 'Bordereau téléchargé',
        body: `Le bordereau de rémunération pour la course #${ride.id.slice(-6).toUpperCase()} a été enregistré.`,
        category: 'PAYMENT',
        badge: 'Bordereau'
      });
    }
  };

  const handleShareBordereau = async (ride: Ride) => {
    soundEffects.playClick();
    const netEarn = Math.round((ride.fare || 0) * 0.8 * 100) / 100;
    const text = `Bordereau Chauffeur SOMED #${ride.id.slice(-6).toUpperCase()}\nClient : ${ride.passengerName || 'Passager'}\nNet perçu : ${formatEuro(netEarn + (ride.tip || 0))}\nTrajet : ${ride.pickup?.name || ride.pickup?.address || 'Départ'} → ${ride.destination?.name || ride.destination?.address || 'Arrivée'}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Bordereau SOMED #${ride.id.slice(-6).toUpperCase()}`,
          text: text,
          url: window.location.href,
        });
        showToast('Partagé avec succès !');
        return;
      } catch {}
    }

    try {
      await navigator.clipboard.writeText(text);
      showToast('Détails copiés dans le presse-papiers !');
    } catch {
      showToast('Informations prêtes.');
    }
  };

  const handleSendEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailModalRide) return;

    soundEffects.playSuccessSound();
    setEmailSent(true);

    vtcStore.sendPushNotification({
      title: 'Bordereau envoyé par email',
      body: `Le bordereau #${emailModalRide.id.slice(-6).toUpperCase()} a été transmis à ${recipientEmail}.`,
      category: 'PAYMENT',
      badge: 'Email'
    });

    setTimeout(() => {
      setEmailSent(false);
      setEmailModalRide(null);
      showToast(`Bordereau transmis à ${recipientEmail}`);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-hidden transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Detail Modal */}
        {selectedRide && (
          <DriverReceiptModal
            ride={selectedRide}
            onClose={() => setSelectedRide(null)}
          />
        )}

        {/* Email Send Modal */}
        {emailModalRide && (
          <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-yellow-400" />
                  <h3 className="font-bold text-sm">Envoyer le bordereau</h3>
                </div>
                <button 
                  onClick={() => setEmailModalRide(null)}
                  className="w-7 h-7 rounded-full bg-neutral-900 text-neutral-400 hover:text-white flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="text-xs space-y-1">
                <p className="font-medium">
                  Course #{emailModalRide.id.slice(-6).toUpperCase()}
                </p>
                <p className="text-neutral-400">
                  Net chauffeur : {formatEuro((emailModalRide.fare * 0.8) + (emailModalRide.tip || 0))}
                </p>
              </div>

              <form onSubmit={handleSendEmailSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold mb-1 text-neutral-400">
                    Adresse email du destinataire
                  </label>
                  <input
                    type="email"
                    required
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    placeholder="comptabilite@somed.biz"
                    className={`w-full px-4 py-3 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                      isLight 
                        ? 'bg-slate-100 border-slate-300 text-slate-900' 
                        : 'bg-neutral-900 border-neutral-700 text-white'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={emailSent}
                  className="w-full py-3.5 px-4 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-bold text-sm flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-yellow-400/20"
                >
                  {emailSent ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Envoyé avec succès !</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Transmettre le bordereau</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Floating Toast Notification */}
        {toastMessage && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[1400] bg-black/90 border border-yellow-400/50 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-4 duration-200">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Top Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
                isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h2 className="font-extrabold text-base leading-tight">Historique & Factures Chauffeur</h2>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Courses, bordereaux de rémunération & transactions
              </p>
            </div>
          </div>
          <div className="w-9" />
        </header>

        {/* Search Bar */}
        <div className={`px-4 py-2.5 border-b flex items-center gap-2 flex-shrink-0 ${
          isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          <div className={`flex-1 flex items-center gap-2 px-3 py-1.5 rounded-xl border ${
            isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
          }`}>
            <Search className="w-4 h-4 text-neutral-400 flex-shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher par adresse, client, #course..."
              className="w-full bg-transparent text-xs focus:outline-none placeholder:text-neutral-500"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-neutral-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Metric Cards Banner */}
        <div className={`p-4 border-b flex-shrink-0 grid grid-cols-3 gap-2 text-center text-xs ${
          isLight ? 'bg-slate-100/70 border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'}`}>
            <p className="font-extrabold text-sm text-emerald-500">{formatEuro(totalEarnings)}</p>
            <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Net chauffeur (80%)</p>
          </div>
          <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'}`}>
            <p className="font-extrabold text-sm">{filteredRides.length}</p>
            <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Courses effectuées</p>
          </div>
          <div className={`p-2.5 rounded-xl border ${isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'}`}>
            <p className="font-extrabold text-sm text-yellow-500">{totalKm.toFixed(1)} km</p>
            <p className={`text-[10px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>Distance totale</p>
          </div>
        </div>

        {/* 5 Sub-Tabs: Tous, Trajets VTC, Commandes, Factures & Reçus, Transactions */}
        <div className={`flex border-b overflow-x-auto flex-shrink-0 scrollbar-none px-2 ${
          isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          {[
            { id: 'ALL', label: 'Tous', icon: Sparkles },
            { id: 'TRIPS', label: 'Trajets VTC', icon: Car },
            { id: 'ORDERS', label: 'Commandes', icon: ShoppingBag },
            { id: 'INVOICES', label: 'Factures & Reçus', icon: Receipt },
            { id: 'TRANSACTIONS', label: 'Transactions', icon: DollarSign },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  soundEffects.playClick();
                }}
                className={`flex items-center gap-1.5 py-3 px-3.5 text-xs font-bold whitespace-nowrap border-b-2 transition ${
                  isActive 
                    ? 'border-yellow-400 text-yellow-500' 
                    : isLight 
                      ? 'border-transparent text-slate-500 hover:text-slate-900' 
                      : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Period Filter Selector */}
        <div className={`px-4 py-2 border-b flex items-center justify-between gap-2 flex-shrink-0 text-xs ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-950 border-neutral-900'
        }`}>
          <div className="flex items-center gap-1.5">
            {(['ALL', 'TODAY', 'WEEK'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setFilterPeriod(p)}
                className={`px-3 py-1 rounded-xl font-bold transition text-[11px] ${
                  filterPeriod === p
                    ? 'bg-yellow-400 text-black shadow-sm'
                    : isLight ? 'bg-slate-200/80 text-slate-700 hover:bg-slate-300' : 'bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
              >
                {p === 'ALL' ? 'Tout' : p === 'TODAY' ? 'Aujourd\'hui' : 'Cette semaine'}
              </button>
            ))}
          </div>

          <span className={`text-[11px] font-mono ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
            {filteredRides.length} élément{filteredRides.length > 1 ? 's' : ''}
          </span>
        </div>

        {/* Content Body List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 max-w-lg mx-auto w-full">
          {/* ActiveTab: TRANSACTIONS view */}
          {activeTab === 'TRANSACTIONS' ? (
            <div className="space-y-3">
              {driverTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className={`p-4 rounded-2xl border space-y-2 shadow-sm ${
                    isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        tx.amount > 0 
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}>
                        {tx.amount > 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                      </div>
                      <div>
                        <h4 className="font-bold text-xs">{tx.title}</h4>
                        <p className={`text-[11px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                          {tx.date} {tx.time ? `à ${tx.time}` : ''}
                        </p>
                      </div>
                    </div>

                    <span className={`font-black text-sm ${tx.amount > 0 ? 'text-emerald-500' : 'text-rose-400'}`}>
                      {tx.amount > 0 ? '+' : ''}{formatEuro(tx.amount)}
                    </span>
                  </div>

                  <p className={`text-xs pl-11 ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                    {tx.description}
                  </p>
                </div>
              ))}
            </div>
          ) : activeTab === 'ORDERS' ? (
            /* Orders / Deliveries view for Driver */
            courierRequests.length === 0 ? (
              <div className={`p-8 text-center rounded-3xl border ${
                isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
              }`}>
                <ShoppingBag className="w-10 h-10 mx-auto text-neutral-500 mb-2" />
                <p className="font-bold text-sm">Aucune commande de livraison</p>
                <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Les courses de livraison boutique apparaîtront ici.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {courierRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-4 rounded-3xl border shadow-sm space-y-3 ${
                      isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/20">
                          {req.status}
                        </span>
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-yellow-400/20 text-yellow-500 border border-yellow-400/30">
                          #{req.id.slice(-6).toUpperCase()}
                        </span>
                      </div>
                      <span className="font-black text-sm text-yellow-500">
                        {formatEuro(req.orderValue)}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs font-bold flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-neutral-400" />
                        <span>Client : {req.customerName}</span>
                      </p>
                      <p className={`text-xs flex items-center gap-1.5 ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                        <MapPin className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                        <span className="truncate">{req.customerAddress}</span>
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className={`pt-2.5 border-t flex items-center justify-end gap-1.5 text-xs ${
                      isLight ? 'border-slate-100' : 'border-neutral-900'
                    }`}>
                      <button
                        onClick={() => {
                          soundEffects.playClick();
                          showToast(`Commande #${req.id.slice(-6).toUpperCase()} prise en charge !`);
                        }}
                        className="flex items-center gap-1 py-1.5 px-3 rounded-xl bg-yellow-400 text-black font-bold text-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Gérer livraison</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : filteredRides.length === 0 ? (
            <div className={`p-8 text-center rounded-3xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
            }`}>
              <Clock className="w-10 h-10 mx-auto text-neutral-500 mb-2" />
              <p className="font-bold text-sm">Aucune course pour cette sélection</p>
              <p className={`text-xs mt-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Les courses acceptées et terminées apparaîtront ici.
              </p>
            </div>
          ) : (
            filteredRides.map((ride) => {
              const netEarn = Math.round((ride.fare || 0) * 0.8 * 100) / 100;
              const totalPayout = netEarn + (ride.tip || 0);
              const bordereauNum = `BOR-${new Date(ride.createdAt).getFullYear()}-${ride.id.slice(-6).toUpperCase()}`;

              return (
                <div
                  key={ride.id}
                  onClick={() => setSelectedRide(ride)}
                  className={`p-4 rounded-3xl border transition cursor-pointer shadow-sm space-y-3 group ${
                    isLight 
                      ? 'bg-white border-slate-200 hover:border-slate-300' 
                      : 'bg-neutral-950 border-neutral-900 hover:border-neutral-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        ride.status === 'COMPLETED'
                          ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                          : ride.status === 'CANCELLED'
                          ? 'bg-rose-500/10 text-rose-500 border border-rose-500/20'
                          : 'bg-blue-500/10 text-blue-500 border border-blue-500/20'
                      }`}>
                        {ride.status === 'COMPLETED' ? 'Terminée' : ride.status}
                      </span>
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-yellow-400/20 text-yellow-500 border border-yellow-400/30">
                        #{bordereauNum}
                      </span>
                      <span className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                        {new Date(ride.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-sm text-emerald-500">
                        +{formatEuro(totalPayout)}
                      </span>
                      <span className={`text-[10px] block ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                        (Brut: {formatEuro(ride.fare)})
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1.5 my-2">
                    <p className="text-xs truncate font-medium flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" />
                      <span className="truncate">{ride.pickup?.name || ride.pickup?.address || 'Départ'}</span>
                    </p>
                    <p className={`text-xs truncate flex items-center gap-1.5 ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>
                      <span className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0" />
                      <span className="truncate">{ride.destination?.name || ride.destination?.address || 'Arrivée'}</span>
                    </p>
                  </div>

                  {/* Action Bar: Download PDF, Share, Email, View details */}
                  <div className={`pt-2.5 border-t flex items-center justify-between text-xs ${
                    isLight ? 'border-slate-100' : 'border-neutral-900'
                  }`}>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedRide(ride);
                        }}
                        className={`text-[11px] font-bold flex items-center gap-1 ${
                          isLight ? 'text-blue-600 hover:underline' : 'text-blue-400 hover:underline'
                        }`}
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Voir bordereau</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Download PDF button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownloadBordereau(ride);
                        }}
                        className={`flex items-center gap-1 py-1.5 px-2.5 rounded-xl font-bold transition active:scale-95 ${
                          isLight 
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                            : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-200 hover:text-white'
                        }`}
                        title="Télécharger le bordereau PDF"
                      >
                        <Download className="w-3.5 h-3.5 text-yellow-500" />
                        <span className="text-[11px]">PDF</span>
                      </button>

                      {/* Share button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleShareBordereau(ride);
                        }}
                        className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                          isLight 
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                            : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                        }`}
                        title="Partager le bordereau"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>

                      {/* Email Send button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEmailModalRide(ride);
                        }}
                        className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                          isLight 
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                            : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                        }`}
                        title="Envoyer par email"
                      >
                        <Mail className="w-3.5 h-3.5" />
                      </button>

                      {/* Re-book / Relancer */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          soundEffects.playClick();
                          showToast('Trajet relancé dans le cockpit !');
                          onClose();
                        }}
                        className={`p-1.5 rounded-xl font-bold transition active:scale-95 ${
                          isLight 
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                            : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                        }`}
                        title="Relancer / Recommander"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-emerald-500" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
