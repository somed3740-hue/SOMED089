import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Check, 
  Car, 
  User, 
  Phone, 
  Mail, 
  FileText, 
  Palette, 
  Hash, 
  Layers
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { RideCategory } from '../../types/vtc';

interface DriverEditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DriverEditProfileModal: React.FC<DriverEditProfileModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();

  const [name, setName] = useState(driver.name);
  const [phone, setPhone] = useState(driver.phone);
  const [email, setEmail] = useState(driver.email);
  const [brand, setBrand] = useState(driver.vehicle.brand || 'Alfa Romeo');
  const [model, setModel] = useState(driver.vehicle.model || 'teresa');
  const [plate, setPlate] = useState(driver.vehicle.plate || 'H45H8887');
  const [color, setColor] = useState(driver.vehicle.color || 'Gris');
  const [year, setYear] = useState<number>(driver.vehicle.year || 2019);
  const [category, setCategory] = useState<RideCategory>(driver.vehicle.category || 'CONFORT');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    vtcStore.updateDriverProfile(driver.id, {
      name,
      phone,
      email,
      vehicle: {
        brand,
        model,
        plate: plate.toUpperCase(),
        color,
        year: Number(year),
        category,
      },
    });

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md select-none animate-in fade-in duration-200">
      <div 
        className={`w-full max-w-lg rounded-3xl border shadow-2xl flex flex-col max-h-[90vh] overflow-hidden transition-colors ${
          isLight 
            ? 'bg-white border-slate-200 text-slate-900 shadow-slate-300/50' 
            : 'bg-neutral-950 border-neutral-800 text-white'
        }`}
      >
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-black'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Modifier le profil chauffeur</h2>
          <div className="w-9" />
        </header>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Identity Section */}
          <div className="space-y-3">
            <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Informations personnelles
            </h3>

            <div className="space-y-1">
              <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Nom complet</label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3.5 top-3.5 text-yellow-500" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Téléphone</label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3.5 top-3.5 text-yellow-500" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                      isLight 
                        ? 'bg-slate-100 border-slate-300 text-slate-900' 
                        : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-yellow-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                      isLight 
                        ? 'bg-slate-100 border-slate-300 text-slate-900' 
                        : 'bg-neutral-900 border-neutral-800 text-white'
                    }`}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Vehicle Section */}
          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-neutral-900">
            <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Véhicule de service
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Marque</label>
                <input
                  type="text"
                  required
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder="Ex: Mercedes, Tesla"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Modèle</label>
                <input
                  type="text"
                  required
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="Ex: Classe E, Model 3"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Immatriculation</label>
                <input
                  type="text"
                  required
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  placeholder="H45H8887"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-mono font-bold uppercase focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Couleur</label>
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  placeholder="Noir, Gris..."
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Année</label>
                <input
                  type="number"
                  value={year}
                  min={2015}
                  max={2027}
                  onChange={(e) => setYear(Number(e.target.value))}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 ${
                    isLight 
                      ? 'bg-slate-100 border-slate-300 text-slate-900' 
                      : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className={`text-xs font-semibold ${isLight ? 'text-slate-600' : 'text-neutral-400'}`}>Gamme VTC</label>
              <div className="grid grid-cols-4 gap-2">
                {(['STANDARD', 'CONFORT', 'BERLINE', 'VAN'] as RideCategory[]).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`py-2 px-1 text-center rounded-xl text-xs font-bold border transition ${
                      category === cat
                        ? 'bg-yellow-400 text-black border-yellow-400 shadow-sm'
                        : isLight 
                        ? 'bg-slate-100 border-slate-300 text-slate-600 hover:bg-slate-200' 
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Footer Submit */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={savedSuccess}
              className={`w-full py-3.5 rounded-2xl font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition active:scale-95 ${
                savedSuccess
                  ? 'bg-emerald-500 text-white'
                  : 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-yellow-400/20'
              }`}
            >
              {savedSuccess ? (
                <>
                  <Check className="w-5 h-5 stroke-[3]" />
                  <span>Profil chauffeur mis à jour !</span>
                </>
              ) : (
                <span>Enregistrer les modifications</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
