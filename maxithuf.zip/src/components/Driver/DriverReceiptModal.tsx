import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Printer, 
  Download, 
  MapPin, 
  Car, 
  CheckCircle2, 
  User, 
  CreditCard, 
  ShieldCheck,
  Share2,
  Mail,
  Send,
  Check,
  X,
  Sparkles
} from 'lucide-react';
import { Ride } from '../../types/vtc';
import { formatEuro } from '../../utils/geo';
import { vtcStore } from '../../services/vtcStore';
import { generateDriverBordereauPDF } from '../../utils/invoice';
import { soundEffects } from '../../utils/audio';

interface DriverReceiptModalProps {
  ride: Ride;
  onClose: () => void;
}

export const DriverReceiptModal: React.FC<DriverReceiptModalProps> = ({
  ride,
  onClose,
}) => {
  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();

  const [copied, setCopied] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState(driver.email || 'chauffeur@somed.biz');
  const [emailSent, setEmailSent] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const netEarnings = Math.round((ride.fare || 0) * 0.8 * 100) / 100;
  const commission = Math.round((ride.fare || 0) * 0.2 * 100) / 100;
  const tip = ride.tip || 0;
  const totalPayout = Math.round((netEarnings + tip) * 100) / 100;
  const bordereauNum = `BOR-${new Date(ride.createdAt || Date.now()).getFullYear()}-${(ride.id || 'SOMED').slice(-6).toUpperCase()}`;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const handleDownloadPDF = () => {
    soundEffects.playClick();
    const success = generateDriverBordereauPDF(ride, driver);
    if (success) {
      showToast(`Bordereau PDF ${bordereauNum} téléchargé !`);
      vtcStore.sendPushNotification({
        title: 'Bordereau chauffeur téléchargé',
        body: `Le bordereau de course ${bordereauNum} (${formatEuro(totalPayout)}) a été enregistré.`,
        category: 'PAYMENT',
        badge: 'Bordereau'
      });
    }
  };

  const handleShare = async () => {
    soundEffects.playClick();
    const shareText = `Bordereau Chauffeur SOMED #${bordereauNum}\nCourse #${ride.id.slice(-6).toUpperCase()}\nClient : ${ride.passengerName || 'Passager'}\nDe : ${ride.pickup?.name || ride.pickup?.address || 'Départ'}\nÀ : ${ride.destination?.name || ride.destination?.address || 'Arrivée'}\nNet perçu : ${formatEuro(totalPayout)} (Brut : ${formatEuro(ride.fare)})\nDate : ${new Date(ride.createdAt).toLocaleDateString('fr-FR')}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Bordereau SOMED #${bordereauNum}`,
          text: shareText,
          url: window.location.href,
        });
        showToast('Bordereau partagé avec succès !');
        return;
      } catch {}
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      showToast('Bordereau copié dans le presse-papiers !');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Informations prêtes.');
    }
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    soundEffects.playSuccessSound();
    setEmailSent(true);

    vtcStore.sendPushNotification({
      title: 'Bordereau envoyé par email',
      body: `Le bordereau ${bordereauNum} (${formatEuro(totalPayout)}) a été transmis à ${recipientEmail}.`,
      category: 'PAYMENT',
      badge: 'Email'
    });

    setTimeout(() => {
      setEmailSent(false);
      setShowEmailModal(false);
      showToast(`Bordereau transmis à ${recipientEmail}`);
    }, 1500);
  };

  const handlePrint = () => {
    try {
      window.print();
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-[1350] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md select-none animate-in fade-in duration-200">
      <div 
        className={`w-full max-w-md rounded-3xl border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden transition-colors ${
          isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
        }`}
      >
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-black'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h2 className="font-extrabold text-sm">Bordereau Chauffeur & Reçu</h2>
            <p className={`text-[10px] font-mono ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              #{bordereauNum}
            </p>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={handlePrint}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition ${
                isLight ? 'hover:bg-slate-200 text-slate-700' : 'hover:bg-neutral-800 text-neutral-300'
              }`}
              title="Imprimer le bordereau"
            >
              <Printer className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Receipt Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Status Badge */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500">
            <span className="flex items-center gap-2 font-bold text-xs">
              <CheckCircle2 className="w-4 h-4" />
              Course validée & rémunérée
            </span>
            <span className="text-[11px] font-black bg-emerald-500/20 px-2 py-0.5 rounded-full">
              80% NET CHAUFFEUR
            </span>
          </div>

          {/* Action Row: Télécharger, Partager, Envoyer */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownloadPDF}
              className="py-2.5 px-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md shadow-yellow-400/20"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Télécharger</span>
            </button>

            <button
              onClick={handleShare}
              className={`py-2.5 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800' 
                  : 'bg-neutral-900 hover:bg-neutral-850 border-neutral-800 text-neutral-200'
              }`}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{copied ? 'Copié !' : 'Partager'}</span>
            </button>

            <button
              onClick={() => setShowEmailModal(true)}
              className={`py-2.5 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 ${
                isLight 
                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800' 
                  : 'bg-neutral-900 hover:bg-neutral-850 border-neutral-800 text-neutral-200'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Envoyer</span>
            </button>
          </div>

          {/* Passenger & Date info */}
          <div className={`p-4 rounded-2xl border space-y-2 text-xs ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
          }`}>
            <div className="flex justify-between items-center">
              <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Date & heure :</span>
              <span className="font-semibold">
                {new Date(ride.createdAt).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Passager :</span>
              <span className="font-bold flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-yellow-500" />
                <span>{ride.passengerName || 'Client SOMED'}</span>
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className={isLight ? 'text-slate-500' : 'text-neutral-400'}>Gamme & Véhicule :</span>
              <span className="font-semibold">{ride.category || 'CONFORT'} · {driver.vehicle.model} ({driver.vehicle.plate})</span>
            </div>
          </div>

          {/* Route details */}
          <div className={`p-4 rounded-2xl border space-y-3 ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-neutral-900/60 border-neutral-800'
          }`}>
            <div className="flex items-start gap-2.5 text-xs">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 mt-1 flex-shrink-0" />
              <div>
                <p className={`text-[10px] font-bold uppercase ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Prise en charge
                </p>
                <p className="font-semibold">{ride.pickup?.name || ride.pickup?.address || 'Départ'}</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 text-xs">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500 mt-1 flex-shrink-0" />
              <div>
                <p className={`text-[10px] font-bold uppercase ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Destination finale
                </p>
                <p className="font-semibold">{ride.destination?.name || ride.destination?.address || 'Arrivée'}</p>
              </div>
            </div>

            <div className={`pt-2 border-t flex justify-between text-xs font-medium ${
              isLight ? 'border-slate-200 text-slate-500' : 'border-neutral-800 text-neutral-400'
            }`}>
              <span>Distance : {(ride.distanceKm || 5.2).toFixed(1)} km</span>
              <span>Durée : {ride.durationMin || 18} min</span>
            </div>
          </div>

          {/* Financial Breakdown */}
          <div className={`p-4 rounded-2xl border space-y-2.5 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-900 border-neutral-800'
          }`}>
            <h4 className="font-bold text-xs uppercase tracking-wider mb-2">Décompte de rémunération</h4>

            <div className="flex justify-between text-xs">
              <span className={isLight ? 'text-slate-600' : 'text-neutral-400'}>Montant brut facturé au client</span>
              <span className="font-medium">{formatEuro(ride.fare)}</span>
            </div>

            <div className="flex justify-between text-xs text-rose-500">
              <span>Commission plateforme SOMED (20%)</span>
              <span>-{formatEuro(commission)}</span>
            </div>

            {tip > 0 && (
              <div className="flex justify-between text-xs text-emerald-500 font-medium">
                <span>Pourboire passager (100% net)</span>
                <span>+{formatEuro(tip)}</span>
              </div>
            )}

            <div className={`pt-3 border-t flex justify-between items-center ${
              isLight ? 'border-slate-200' : 'border-neutral-800'
            }`}>
              <div>
                <p className="font-bold text-sm">Net perçu par le chauffeur</p>
                <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Crédité sur votre portefeuille
                </p>
              </div>
              <p className="text-xl font-black text-emerald-500">
                {formatEuro(totalPayout)}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className={`p-4 border-t flex justify-end ${
          isLight ? 'border-slate-200 bg-slate-50' : 'border-neutral-900 bg-black'
        }`}>
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs transition"
          >
            Fermer le bordereau
          </button>
        </footer>
      </div>

      {/* Email sending dialog */}
      {showEmailModal && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className={`rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4 border ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800/40">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-yellow-400 text-black flex items-center justify-center">
                  <Mail className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm">Envoyer le bordereau</h3>
                  <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Bordereau #{bordereauNum}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowEmailModal(false)}
                className="w-7 h-7 rounded-full flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-neutral-300'}`}>
              Transmettez le bordereau PDF de votre course ({formatEuro(totalPayout)}) vers votre adresse ou celle de votre expert-comptable.
            </p>

            <form onSubmit={handleSendEmail} className="space-y-3">
              <div>
                <label className="text-xs font-semibold block mb-1">Email destinataire</label>
                <input
                  type="email"
                  required
                  placeholder="votre.email@comptabilite.com"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:border-yellow-400 ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-neutral-900 border-neutral-800 text-white'
                  }`}
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowEmailModal(false)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition ${
                    isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
                  }`}
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={emailSent}
                  className="flex-1 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xs rounded-xl shadow-md transition active:scale-95 flex items-center justify-center gap-1.5"
                >
                  {emailSent ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Transmis !</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Envoyer</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[1600] bg-neutral-900/95 border border-yellow-400/60 text-white px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2.5 text-xs font-bold animate-in fade-in slide-in-from-bottom duration-200">
          <Sparkles className="w-4 h-4 text-yellow-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
