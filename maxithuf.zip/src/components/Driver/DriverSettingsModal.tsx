import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Navigation, 
  MapPin, 
  Volume2, 
  VolumeX, 
  Sun, 
  Moon, 
  Smartphone, 
  Check, 
  Compass, 
  Shield, 
  Globe,
  Sliders,
  CheckCircle2
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { useTranslation, SUPPORTED_LANGUAGES, Language } from '../../utils/i18n';
import { soundEffects } from '../../utils/audio';

interface DriverSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DriverSettingsModal: React.FC<DriverSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();
  const passenger = vtcStore.getPassenger();
  const { lang, t, setLanguage } = useTranslation();

  const [preferredGps, setPreferredGps] = useState<'waze' | 'google' | 'inapp'>(
    driver.preferredGps || 'waze'
  );
  const [searchRadius, setSearchRadius] = useState<number>(driver.searchRadiusKm || 15);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(driver.soundAlertsEnabled !== false);
  const [autoAccept, setAutoAccept] = useState<boolean>(driver.autoAccept || false);

  const handleAppearanceChange = (mode: 'light' | 'dark' | 'auto') => {
    vtcStore.setAppearance(mode);
  };

  const handleSelectLanguage = (code: Language) => {
    soundEffects.playClick();
    setLanguage(code);

    const labels: Record<Language, string> = {
      fr: 'Français activé pour toute l’application',
      en: 'English activated across all interfaces',
      es: 'Español activado en todas las interfaces',
    };

    vtcStore.sendPushNotification({
      title: t('language'),
      body: labels[code],
      category: 'SYSTEM',
      badge: code.toUpperCase(),
    });
  };

  const handleSaveSettings = () => {
    vtcStore.updateDriverSettings(driver.id, {
      preferredGps,
      searchRadiusKm: searchRadius,
      soundAlertsEnabled: soundEnabled,
      autoAccept,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col select-none animate-in fade-in duration-200">
      <div 
        className={`h-full w-full flex flex-col overflow-y-auto transition-colors ${
          isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
        }`}
      >
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
          isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-base">Paramètres Chauffeur</h2>
          <div className="w-9" />
        </header>

        {/* Content */}
        <div className="flex-1 max-w-lg mx-auto w-full p-5 space-y-5">
          {/* Language Selection Section (Français, Anglais, Espagnol) */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div>
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Globe className="w-4 h-4 text-yellow-500" />
                <span>{t('language')}</span>
              </h3>
              <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                {t('languageSubtitle')}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {SUPPORTED_LANGUAGES.map((item) => {
                const isSelected = lang === item.code;
                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => handleSelectLanguage(item.code)}
                    className={`py-3 px-2 rounded-2xl text-xs font-bold flex flex-col items-center justify-center gap-1 border transition active:scale-95 ${
                      isSelected
                        ? 'bg-yellow-400 text-black border-yellow-400 shadow-md ring-2 ring-yellow-400/30'
                        : isLight 
                        ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100' 
                        : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white'
                    }`}
                  >
                    <span className="text-xl">{item.flag}</span>
                    <span>{item.name}</span>
                    {isSelected && (
                      <span className="text-[9px] bg-black text-yellow-400 px-1.5 py-0.2 rounded-full font-black flex items-center gap-0.5">
                        <Check className="w-2.5 h-2.5" /> {t('active')}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Appearance Section (Clair / Sombre) */}
          <div className={`p-5 rounded-3xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div>
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Sun className="w-4 h-4 text-yellow-500" />
                <span>{t('appearance')}</span>
              </h3>
              <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Choisissez le mode d'affichage de l'application
              </p>
            </div>

            <div className={`grid grid-cols-3 gap-2 p-1.5 rounded-2xl border ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
            }`}>
              <button
                type="button"
                onClick={() => handleAppearanceChange('light')}
                className={`py-3 px-2 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition ${
                  passenger.appearance === 'light'
                    ? 'bg-yellow-400 text-black shadow-md'
                    : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>Mode Clair</span>
              </button>

              <button
                type="button"
                onClick={() => handleAppearanceChange('dark')}
                className={`py-3 px-2 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition ${
                  passenger.appearance === 'dark'
                    ? 'bg-yellow-400 text-black shadow-md'
                    : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>Mode Sombre</span>
              </button>

              <button
                type="button"
                onClick={() => handleAppearanceChange('auto')}
                className={`py-3 px-2 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition ${
                  passenger.appearance === 'auto'
                    ? 'bg-yellow-400 text-black shadow-md'
                    : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>Système</span>
              </button>
            </div>
          </div>

          {/* Navigation GPS Choice */}
          <div className={`p-5 rounded-3xl border space-y-3.5 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div>
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Navigation className="w-4 h-4 text-blue-500" />
                <span>Application GPS de guidage par défaut</span>
              </h3>
              <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Lancée automatiquement lors de la prise en charge et du trajet
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'waze', label: 'Waze', desc: 'Alertes trafic & radars' },
                { id: 'google', label: 'Google Maps', desc: 'Guidage précis' },
                { id: 'inapp', label: 'GPS SOMED', desc: 'Carte intégrée' },
              ].map((gps) => (
                <button
                  key={gps.id}
                  type="button"
                  onClick={() => setPreferredGps(gps.id as any)}
                  className={`p-3 rounded-2xl text-left border transition ${
                    preferredGps === gps.id
                      ? 'bg-yellow-400 text-black border-yellow-400 shadow-md font-bold'
                      : isLight 
                      ? 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200' 
                      : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <p className="font-bold text-xs">{gps.label}</p>
                  <p className={`text-[10px] mt-0.5 line-clamp-1 ${
                    preferredGps === gps.id ? 'text-black/80' : isLight ? 'text-slate-500' : 'text-neutral-500'
                  }`}>
                    {gps.desc}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Search Radius & Dispatch preferences */}
          <div className={`p-5 rounded-3xl border space-y-3.5 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-800'
          }`}>
            <div>
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Compass className="w-4 h-4 text-emerald-500" />
                <span>Rayon de recherche des courses</span>
              </h3>
              <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                Distance maximale de prise en charge : <strong className="text-yellow-500 font-bold">{searchRadius} km</strong>
              </p>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[5, 10, 15, 30].map((km) => (
                <button
                  key={km}
                  type="button"
                  onClick={() => setSearchRadius(km)}
                  className={`py-2 rounded-xl text-xs font-bold border transition ${
                    searchRadius === km
                      ? 'bg-yellow-400 text-black border-yellow-400'
                      : isLight ? 'bg-slate-100 border-slate-200 text-slate-600' : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                  }`}
                >
                  {km} km
                </button>
              ))}
            </div>
          </div>

          {/* Sound & Alert Toggles */}
          <div className={`p-5 rounded-3xl border divide-y ${
            isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-800 divide-neutral-900'
          }`}>
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="font-bold text-xs">Alertes sonores de courses</p>
                <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Sonnerie d'urgence lors d'une nouvelle demande
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                  soundEnabled ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-black shadow transform transition duration-200 ${
                  soundEnabled ? 'translate-x-5 bg-black' : 'translate-x-0 bg-white'
                }`} />
              </button>
            </div>

            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="font-bold text-xs">Acceptation automatique</p>
                <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                  Accepter directement les courses dans mon rayon
                </p>
              </div>
              <button
                type="button"
                onClick={() => setAutoAccept(!autoAccept)}
                className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                  autoAccept ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-black shadow transform transition duration-200 ${
                  autoAccept ? 'translate-x-5 bg-black' : 'translate-x-0 bg-white'
                }`} />
              </button>
            </div>
          </div>

          {/* Save Button */}
          <div className="pt-2">
            <button
              onClick={handleSaveSettings}
              className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-2xl text-xs shadow-lg transition active:scale-95"
            >
              Enregistrer les paramètres
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
