import React, { useState, useEffect } from 'react';
import { 
  Power, 
  DollarSign, 
  Star, 
  TrendingUp, 
  Navigation, 
  MapPin, 
  CheckCircle, 
  Phone, 
  MessageSquare, 
  Shield, 
  ShieldCheck,
  Clock, 
  Check, 
  Volume2,
  PanelLeftClose,
  PanelLeftOpen,
  Maximize2,
  Wallet,
  Settings,
  User,
  Sun,
  Moon,
  ChevronRight,
  FileText,
  Repeat
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { VtcMap } from '../Map/VtcMap';
import { formatEuro, getGoogleMapsUrl, getWazeUrl } from '../../utils/geo';
import { ChatModal } from '../Modals/ChatModal';
import { CallModal } from '../Modals/CallModal';
import { soundEffects } from '../../utils/audio';
import { DriverProfileModal } from './DriverProfileModal';
import { DriverEditProfileModal } from './DriverEditProfileModal';
import { DriverEarningsModal } from './DriverEarningsModal';
import { DriverActivityModal } from './DriverActivityModal';
import { DriverSettingsModal } from './DriverSettingsModal';
import { SwipeButton } from '../Common/SwipeButton';
import { useTranslation } from '../../utils/i18n';

interface DriverViewProps {
  onSwitchMode?: () => void;
}

export const DriverView: React.FC<DriverViewProps> = ({ onSwitchMode }) => {
  const isLight = vtcStore.isLightMode();
  const driver = vtcStore.getCurrentDriver();
  const allDrivers = vtcStore.getAllDrivers();
  const activeRide = vtcStore.getActiveRideForDriver(driver.id);
  const incomingRequests = vtcStore.getIncomingRequestsForDriver(driver);
  const { lang, t } = useTranslation();

  const [requestCountdown, setRequestCountdown] = useState(15);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isCallOpen, setIsCallOpen] = useState(false);
  const [isPanelCollapsed, setIsPanelCollapsed] = useState(false);

  // Dedicated Driver Modals
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isEarningsOpen, setIsEarningsOpen] = useState(false);
  const [isActivityOpen, setIsActivityOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Incoming request countdown
  useEffect(() => {
    if (incomingRequests.length > 0) {
      setRequestCountdown(15);
      soundEffects.playRideRequestAlert();

      const timer = setInterval(() => {
        setRequestCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [incomingRequests.length]);

  const currentIncoming = incomingRequests[0];

  const handleToggleOnline = () => {
    vtcStore.toggleDriverOnline(driver.id);
  };

  const handleAcceptRide = () => {
    if (currentIncoming) {
      vtcStore.acceptRide(driver.id, currentIncoming.id);
    }
  };

  const handleDeclineRide = () => {
    if (currentIncoming) {
      vtcStore.cancelRide(currentIncoming.id);
    }
  };

  const handleArrived = () => {
    if (activeRide) {
      vtcStore.driverArrivedAtPickup(activeRide.id);
    }
  };

  const handleStartTrip = () => {
    if (activeRide) {
      vtcStore.startRideTrip(activeRide.id);
    }
  };

  const handleCompleteTrip = () => {
    if (activeRide) {
      vtcStore.completeRide(activeRide.id);
    }
  };

  return (
    <div className={`relative h-full w-full flex flex-col md:flex-row overflow-hidden transition-colors ${
      isLight ? 'bg-slate-100 text-slate-900' : 'bg-slate-950 text-slate-100'
    }`}>
      {/* Contact Modals */}
      {isChatOpen && activeRide && (
        <ChatModal
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          otherPartyName={activeRide.passengerName}
          otherPartyRole="Passager"
          isDriverView={true}
        />
      )}

      {isCallOpen && activeRide && (
        <CallModal
          isOpen={isCallOpen}
          onClose={() => setIsCallOpen(false)}
          callerName={activeRide.passengerName}
          callerRole="Client Passager"
        />
      )}

      {/* Driver Feature Modals */}
      <DriverProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onOpenEditProfile={() => {
          setIsProfileOpen(false);
          setIsEditProfileOpen(true);
        }}
        onOpenEarnings={() => {
          setIsProfileOpen(false);
          setIsEarningsOpen(true);
        }}
        onOpenActivity={() => {
          setIsProfileOpen(false);
          setIsActivityOpen(true);
        }}
        onOpenSettings={() => {
          setIsProfileOpen(false);
          setIsSettingsOpen(true);
        }}
        onSwitchMode={onSwitchMode}
      />

      <DriverEditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      <DriverEarningsModal
        isOpen={isEarningsOpen}
        onClose={() => setIsEarningsOpen(false)}
      />

      <DriverActivityModal
        isOpen={isActivityOpen}
        onClose={() => setIsActivityOpen(false)}
      />

      <DriverSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* LEFT PANEL: Driver cockpit & dispatch status */}
      <div className={`w-full md:w-[440px] flex-shrink-0 z-20 flex flex-col h-[55%] md:h-full backdrop-blur-xl border-t md:border-t-0 md:border-r shadow-2xl order-2 md:order-1 overflow-y-auto transition-all duration-300 ${
        isLight 
          ? 'bg-white/95 border-slate-200 text-slate-900 shadow-slate-200' 
          : 'bg-slate-900/95 border-slate-800 text-slate-100'
      } ${
        isPanelCollapsed ? 'hidden' : 'flex'
      }`}>
        {/* Driver Top Header & Profile Switcher */}
        <div className={`p-4 border-b ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/80 border-slate-800'}`}>
          <div className="flex items-center justify-between gap-2">
            <div 
              onClick={() => setIsProfileOpen(true)}
              className="flex items-center gap-3 min-w-0 cursor-pointer group"
              title="Voir mon profil chauffeur"
            >
              <div className="relative flex-shrink-0">
                <div className="w-11 h-11 rounded-full border-2 border-emerald-500 overflow-hidden flex items-center justify-center font-bold text-white text-base bg-slate-800 shadow">
                  <img
                    src={driver.avatarUrl}
                    alt={driver.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 ${
                  isLight ? 'border-white' : 'border-slate-900'
                } ${
                  driver.isOnline ? 'bg-emerald-500' : 'bg-slate-500'
                }`} />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-bold leading-tight truncate group-hover:text-yellow-500 transition">
                    {driver.name}
                  </p>
                  <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded font-mono flex-shrink-0 shadow-sm">
                    ★ {driver.rating.toFixed(2)}
                  </span>
                </div>
                <p className={`text-xs truncate font-medium ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  {driver.vehicle.model} · <span className="font-mono">{driver.vehicle.plate}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-shrink-0">
              {/* Quick Theme Toggle (Light / Dark) */}
              <button
                onClick={() => vtcStore.toggleAppearance()}
                title={isLight ? t('dark') : t('light')}
                className={`w-8 h-8 rounded-xl flex items-center justify-center border transition active:scale-95 ${
                  isLight 
                    ? 'bg-slate-200 hover:bg-slate-300 text-slate-800 border-slate-300' 
                    : 'bg-slate-800 hover:bg-slate-700 text-yellow-400 border-slate-700'
                }`}
              >
                {isLight ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </button>

              {/* Online/Offline Toggle */}
              <button
                onClick={handleToggleOnline}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-lg active:scale-95 ${
                  driver.isOnline
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                    : isLight 
                    ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' 
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
                }`}
              >
                <Power className="w-3.5 h-3.5" />
                <span>{driver.isOnline ? t('online').toUpperCase() : t('offline').toUpperCase()}</span>
              </button>

              {/* Collapse Button */}
              <button
                onClick={() => setIsPanelCollapsed(true)}
                title="Masquer le panneau pour voir la carte en plein écran"
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs border transition ${
                  isLight 
                    ? 'bg-slate-200 hover:bg-slate-300 text-slate-700 border-slate-300' 
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
              >
                <PanelLeftClose className="w-3.5 h-3.5 text-amber-500" />
                <span className="hidden sm:inline font-medium text-[11px]">{t('close')}</span>
              </button>
            </div>
          </div>

          {/* DRIVER FEATURE QUICK ACTIONS TOOLBAR */}
          <div className="grid grid-cols-4 gap-1.5 mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-800/80">
            <button
              onClick={() => setIsEarningsOpen(true)}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                isLight 
                  ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800 shadow-sm' 
                  : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200'
              }`}
            >
              <Wallet className="w-4 h-4 text-emerald-500" />
              <span className="text-[10px] font-bold">{t('driverEarnings')}</span>
            </button>

            <button
              onClick={() => setIsActivityOpen(true)}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                isLight 
                  ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800 shadow-sm' 
                  : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200'
              }`}
            >
              <Clock className="w-4 h-4 text-blue-500" />
              <span className="text-[10px] font-bold">{t('driverActivity')}</span>
            </button>

            <button
              onClick={() => setIsProfileOpen(true)}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                isLight 
                  ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800 shadow-sm' 
                  : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200'
              }`}
            >
              <User className="w-4 h-4 text-yellow-500" />
              <span className="text-[10px] font-bold">{t('driverMyProfile')}</span>
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                isLight 
                  ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800 shadow-sm' 
                  : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200'
              }`}
            >
              <Settings className="w-4 h-4 text-slate-500" />
              <span className="text-[10px] font-bold">{t('driverSettings')}</span>
            </button>
          </div>

          {/* Quick Driver Profile Selector */}
          <div className="mt-2.5 flex items-center gap-2 overflow-x-auto no-scrollbar pt-2 border-t border-slate-200 dark:border-slate-800/60">
            <span className={`text-[10px] font-semibold uppercase tracking-wider flex-shrink-0 ${
              isLight ? 'text-slate-500' : 'text-slate-500'
            }`}>
              Chauffeur :
            </span>
            {allDrivers.map((d) => (
              <button
                key={d.id}
                onClick={() => vtcStore.setCurrentDriverId(d.id)}
                className={`text-[11px] px-2.5 py-1 rounded-lg border transition whitespace-nowrap ${
                  d.id === driver.id
                    ? 'bg-yellow-400 border-yellow-500 text-black font-bold shadow-sm'
                    : isLight 
                    ? 'bg-white border-slate-200 text-slate-600 hover:text-black' 
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {d.name.split(' ')[0]} ({d.vehicle.category})
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Cockpit States */}
        {activeRide ? (
          /* ACTIVE NAVIGATION STATE */
          <div className="p-4 space-y-4 flex-1 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Turn-by-turn guidance header */}
              <div className="bg-blue-600 text-white p-4 rounded-2xl shadow-xl shadow-blue-600/20">
                <div className="flex items-center justify-between text-xs text-blue-200 uppercase tracking-wider font-semibold mb-1">
                  <span>Navigation GPS Chauffeur</span>
                  <span>{activeRide.status}</span>
                </div>
                <h3 className="text-lg font-bold">
                  {activeRide.status === 'ACCEPTED' && 'Rendez-vous au point de prise en charge'}
                  {activeRide.status === 'ARRIVING' && 'Vous êtes sur place · Attente du passager'}
                  {activeRide.status === 'IN_PROGRESS' && 'Trajet en cours vers la destination'}
                </h3>
                <p className="text-xs text-blue-100 mt-1 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">
                    {activeRide.status === 'IN_PROGRESS'
                      ? activeRide.destination.name || activeRide.destination.address
                      : activeRide.pickup.name || activeRide.pickup.address}
                  </span>
                </p>
              </div>

              {/* Passenger Info & Contact */}
              <div className={`border rounded-2xl p-4 space-y-3 ${
                isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-slate-950 border-slate-800 text-white'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-full bg-slate-800 text-white border border-slate-700 flex items-center justify-center font-bold text-sm">
                      {activeRide.passengerName.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-sm">{activeRide.passengerName}</p>
                      <p className="text-xs text-amber-500 font-semibold">
                        ⭐ {activeRide.passengerRating.toFixed(2)} · Client vérifié
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Revenu net (80%)</p>
                    <p className="text-base font-bold text-emerald-500">{formatEuro(activeRide.fare * 0.8)}</p>
                  </div>
                </div>

                {/* External GPS launcher (Waze & Google Maps) */}
                <div className={`pt-2 border-t ${isLight ? 'border-slate-200' : 'border-slate-800/80'}`}>
                  <p className={`text-[10px] font-semibold uppercase mb-1.5 ${isLight ? 'text-slate-500' : 'text-slate-500'}`}>
                    Lancer guidage GPS externe :
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={getWazeUrl(
                        activeRide.status === 'IN_PROGRESS' ? activeRide.destination.lat : activeRide.pickup.lat,
                        activeRide.status === 'IN_PROGRESS' ? activeRide.destination.lng : activeRide.pickup.lng
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold border transition ${
                        isLight 
                          ? 'bg-white hover:bg-slate-100 text-sky-600 border-slate-200' 
                          : 'bg-slate-900 hover:bg-slate-800 text-sky-400 border-slate-700'
                      }`}
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Waze</span>
                    </a>
                    <a
                      href={getGoogleMapsUrl(
                        activeRide.status === 'IN_PROGRESS' ? activeRide.destination.lat : activeRide.pickup.lat,
                        activeRide.status === 'IN_PROGRESS' ? activeRide.destination.lng : activeRide.pickup.lng
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold border transition ${
                        isLight 
                          ? 'bg-white hover:bg-slate-100 text-emerald-600 border-slate-200' 
                          : 'bg-slate-900 hover:bg-slate-800 text-emerald-400 border-slate-700'
                      }`}
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Google Maps</span>
                    </a>
                  </div>
                </div>

                {/* Call and Chat Buttons */}
                <div className={`grid grid-cols-2 gap-2 pt-2 border-t ${isLight ? 'border-slate-200' : 'border-slate-800/80'}`}>
                  <button
                    onClick={() => setIsChatOpen(true)}
                    className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold transition ${
                      isLight 
                        ? 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200' 
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-700'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4 text-blue-500" />
                    <span>Message client</span>
                  </button>
                  <button
                    onClick={() => setIsCallOpen(true)}
                    className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold transition ${
                      isLight 
                        ? 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200' 
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-700'
                    }`}
                  >
                    <Phone className="w-4 h-4 text-emerald-500" />
                    <span>Appeler</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Driver Navigation Action Buttons in Swipe Mode */}
            <div className="space-y-3 pt-3">
              {activeRide.status === 'ACCEPTED' && (
                <div className="space-y-2">
                  <p className="text-[11px] text-slate-400 font-semibold text-center uppercase tracking-wide">
                    Action Chauffeur (Mode Glissé) :
                  </p>
                  <SwipeButton
                    label="Glisser : Je suis arrivé sur place"
                    onConfirm={handleArrived}
                    variant="emerald"
                    icon={<CheckCircle className="w-5 h-5 text-white" />}
                  />
                </div>
              )}

              {activeRide.status === 'ARRIVING' && (
                <div className="space-y-3">
                  {/* Passenger OTP Code Verification Card */}
                  <div className={`p-3.5 rounded-2xl border ${
                    activeRide.isCodeVerified 
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' 
                      : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-yellow-400" />
                        <div>
                          <p className="text-xs font-bold">Code de sécurité passager</p>
                          <p className="text-[10px] opacity-75">
                            {activeRide.isCodeVerified 
                              ? 'Code vérifié et confirmé' 
                              : 'Vérifiez le code partagé par le passager'}
                          </p>
                        </div>
                      </div>
                      <span className="font-mono font-black text-base bg-black/60 px-2.5 py-1 rounded-xl border border-yellow-400/40 text-yellow-300 tracking-widest shadow-inner">
                        {activeRide.verificationCode || activeRide.id.slice(-4)}
                      </span>
                    </div>

                    {!activeRide.isCodeVerified ? (
                      <div className="mt-3">
                        <SwipeButton
                          label="Glisser : Valider le code client"
                          onConfirm={() => vtcStore.verifyRideCode(activeRide.id)}
                          variant="yellow"
                          icon={<ShieldCheck className="w-5 h-5 text-black" />}
                        />
                      </div>
                    ) : (
                      <div className="mt-2 py-1 px-2.5 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-center text-xs font-bold text-emerald-400 flex items-center justify-center gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Code validé avec succès ✓</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <p className="text-[11px] text-slate-400 font-semibold text-center uppercase tracking-wide">
                      Prise en charge client :
                    </p>
                    <SwipeButton
                      label="Glisser : Démarrer la course"
                      onConfirm={handleStartTrip}
                      variant="blue"
                      icon={<Navigation className="w-5 h-5 text-white" />}
                    />
                  </div>
                </div>
              )}

              {activeRide.status === 'IN_PROGRESS' && (
                <div className="space-y-2">
                  <p className="text-[11px] text-slate-400 font-semibold text-center uppercase tracking-wide">
                    Fin de trajet :
                  </p>
                  <SwipeButton
                    label="Glisser : Terminer & Encaisser"
                    onConfirm={handleCompleteTrip}
                    variant="emerald"
                    icon={<Check className="w-5 h-5 text-white stroke-[3]" />}
                  />
                </div>
              )}
            </div>
          </div>
        ) : (
          /* IDLE / WAITING OR INCOMING REQUEST STATE */
          <div className="p-4 space-y-4">
            {/* Incoming Request Alert Modal Card */}
            {currentIncoming && driver.isOnline ? (
              <div className="bg-slate-950 border-2 border-emerald-500 rounded-2xl p-4 shadow-2xl relative overflow-hidden animate-pulse">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    Nouvelle demande de course !
                  </span>
                  <span className="text-xs font-bold bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-500/40">
                    {requestCountdown}s
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-400">Gamme demandée :</span>
                    <span className="font-bold text-white text-xs">{currentIncoming.category}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-400">Revenu net estimé :</span>
                    <span className="font-bold text-emerald-400 text-lg">{formatEuro(currentIncoming.fare * 0.8)}</span>
                  </div>
                  <div className="text-xs text-slate-300 pt-1 border-t border-slate-800">
                    <p className="truncate"><strong className="text-emerald-500">Prise en charge:</strong> {currentIncoming.pickup.name || currentIncoming.pickup.address}</p>
                    <p className="truncate text-slate-400"><strong className="text-rose-500">Destination:</strong> {currentIncoming.destination.name || currentIncoming.destination.address}</p>
                  </div>
                </div>

                {/* Accept in Swipe Mode */}
                <div className="space-y-2">
                  <SwipeButton
                    label="Glisser pour accepter la course"
                    onConfirm={handleAcceptRide}
                    variant="emerald"
                    icon={<Check className="w-5 h-5 text-white stroke-[3]" />}
                  />

                  <button
                    onClick={handleDeclineRide}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-slate-400 rounded-xl font-semibold text-xs border border-slate-700/60 transition"
                  >
                    Refuser la demande
                  </button>
                </div>
              </div>
            ) : null}

            {/* Waiting Radar indicator if online & no active ride */}
            {driver.isOnline && !currentIncoming && (
              <div className={`border rounded-2xl p-5 text-center space-y-3 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950 border-slate-800'
              }`}>
                <div className="relative w-14 h-14 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-emerald-500/20 radar-ping" />
                  <div className="w-10 h-10 bg-emerald-600/30 text-emerald-500 border border-emerald-500/40 rounded-full flex items-center justify-center">
                    <Navigation className="w-5 h-5 animate-pulse" />
                  </div>
                </div>
                <div>
                  <h4 className="font-bold text-sm">Prêt pour de nouvelles courses</h4>
                  <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                    Positionnement actif · Radar connecté
                  </p>
                </div>
                <button
                  onClick={() => vtcStore.seedDemoRide()}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${
                    isLight 
                      ? 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200' 
                      : 'bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border-blue-500/40'
                  }`}
                >
                  + Déclencher une course test
                </button>
              </div>
            )}

            {/* Offline notice */}
            {!driver.isOnline && (
              <div className={`border rounded-2xl p-5 text-center space-y-2 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
              }`}>
                <Power className="w-8 h-8 text-slate-400 mx-auto" />
                <h4 className="font-bold text-sm">Vous êtes actuellement hors ligne</h4>
                <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Passez en ligne pour recevoir des demandes de clients et générer des revenus.
                </p>
              </div>
            )}

            {/* Driver Earnings Dashboard Card */}
            <div 
              onClick={() => setIsEarningsOpen(true)}
              className={`border rounded-2xl p-4 space-y-3 cursor-pointer transition hover:scale-[1.01] ${
                isLight ? 'bg-white border-slate-200 hover:border-slate-300 shadow-sm' : 'bg-slate-950 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${
                  isLight ? 'text-slate-600' : 'text-slate-400'
                }`}>
                  <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Performances & Revenus</span>
                </h4>
                <span className="text-[11px] font-bold text-yellow-500 flex items-center gap-0.5">
                  Détails <ChevronRight className="w-3 h-3" />
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className={`p-3 rounded-xl border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800/80'
                }`}>
                  <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Gains aujourd'hui</p>
                  <p className="text-lg font-bold text-emerald-500">{formatEuro(driver.todayEarnings)}</p>
                </div>
                <div className={`p-3 rounded-xl border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800/80'
                }`}>
                  <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Solde portefeuille</p>
                  <p className="text-lg font-bold text-yellow-500">{formatEuro(driver.driverWalletBalance || 0)}</p>
                </div>
              </div>

              <div className={`grid grid-cols-3 gap-2 pt-2 border-t text-center text-xs ${
                isLight ? 'border-slate-100' : 'border-slate-800/80'
              }`}>
                <div>
                  <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-500'}`}>Courses</p>
                  <p className="font-bold">{driver.totalRides}</p>
                </div>
                <div>
                  <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-500'}`}>Note</p>
                  <p className="font-bold text-amber-500 flex items-center justify-center gap-0.5">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span>{driver.rating.toFixed(2)}</span>
                  </p>
                </div>
                <div>
                  <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-slate-500'}`}>Acceptation</p>
                  <p className="font-bold text-emerald-500">{driver.acceptanceRate}%</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* RIGHT PANEL: Live Navigation Map (Full Screen when panel collapsed) */}
      <div className={`order-1 md:order-2 relative transition-all duration-300 ${
        isPanelCollapsed ? 'w-full h-full flex-1' : 'flex-1 h-[45%] md:h-full'
      }`}>
        {/* Floating Map Controls & Cockpit Toggle */}
        <div className="absolute top-4 left-4 z-[990] flex items-center gap-2 pointer-events-auto">
          {isPanelCollapsed ? (
            <button
              onClick={() => setIsPanelCollapsed(false)}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-900/95 hover:bg-slate-800 text-white rounded-2xl shadow-2xl border border-slate-700/80 backdrop-blur-md transition font-semibold text-xs group active:scale-95 ring-1 ring-white/10"
            >
              <PanelLeftOpen className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition" />
              <span>Afficher le cockpit chauffeur</span>
              {currentIncoming ? (
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full text-[10px] font-bold animate-pulse">
                  Course reçue ({requestCountdown}s)
                </span>
              ) : activeRide ? (
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full text-[10px] font-bold">
                  {activeRide.status === 'ACCEPTED'
                    ? 'Vers prise en charge'
                    : activeRide.status === 'ARRIVING'
                    ? 'Sur place'
                    : activeRide.status === 'IN_PROGRESS'
                    ? 'Trajet en cours'
                    : activeRide.status}
                </span>
              ) : (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                  driver.isOnline
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    : 'bg-slate-700/50 text-slate-400 border-slate-600/40'
                }`}>
                  {driver.isOnline ? 'En service' : 'Hors ligne'}
                </span>
              )}
            </button>
          ) : (
            <button
              onClick={() => setIsPanelCollapsed(true)}
              title="Voir la carte en plein écran (masquer le cockpit)"
              className={`hidden md:flex items-center gap-1.5 px-3 py-2 rounded-xl shadow-lg border backdrop-blur-md transition text-xs font-semibold ${
                isLight 
                  ? 'bg-white/90 hover:bg-white text-slate-800 border-slate-300 shadow-slate-200' 
                  : 'bg-slate-900/90 hover:bg-slate-800 text-slate-200 border-slate-700/80'
              }`}
            >
              <Maximize2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Carte plein écran</span>
            </button>
          )}

          {/* Quick theme toggle floating on map */}
          <button
            onClick={() => vtcStore.toggleAppearance()}
            title={isLight ? 'Passer en Mode Sombre' : 'Passer en Mode Clair'}
            className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-lg border backdrop-blur-md transition active:scale-95 ${
              isLight 
                ? 'bg-white/90 hover:bg-white text-slate-800 border-slate-300' 
                : 'bg-slate-900/90 hover:bg-slate-800 text-yellow-400 border-slate-700/80'
            }`}
          >
            {isLight ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>

        <VtcMap
          pickup={activeRide?.pickup || currentIncoming?.pickup}
          destination={activeRide?.destination || currentIncoming?.destination}
          activeRide={activeRide}
          drivers={allDrivers}
        />
      </div>
    </div>
  );
};
