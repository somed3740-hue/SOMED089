import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  Map, 
  AdvancedMarker, 
  InfoWindow, 
  useMap, 
  useMapsLibrary 
} from '@vis.gl/react-google-maps';
import { DriverProfile, LocationPoint, Ride } from '../../types/vtc';
import { Car, Navigation, MapPin, Crosshair, Star, ShieldCheck } from 'lucide-react';

export interface GoogleVtcMapProps {
  center?: [number, number];
  zoom?: number;
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeRide?: Ride | null;
  drivers?: DriverProfile[];
  interactive?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  className?: string;
  theme?: 'dark' | 'light';
}

/**
 * Subcomponent to handle Route computation and Polyline rendering
 * using Google Maps Routes API (Route.computeRoutes)
 */
function RouteRenderer({
  pickup,
  destination,
  activeRide,
}: {
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeRide?: Ride | null;
}) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  const effectivePickup = activeRide ? activeRide.pickup : pickup;
  const effectiveDest = activeRide ? activeRide.destination : destination;

  useEffect(() => {
    if (!map) return;

    // Clear previous polylines
    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];

    // Case 1: Active ride has pre-computed / simulated route points
    if (activeRide && activeRide.currentRoutePoints && activeRide.currentRoutePoints.length > 1) {
      const path = activeRide.currentRoutePoints.map(([lat, lng]) => ({ lat, lng }));
      const poly = new google.maps.Polyline({
        path,
        strokeColor: '#2563eb',
        strokeWeight: 5,
        strokeOpacity: 0.9,
        map,
      });
      polylinesRef.current = [poly];
      return;
    }

    // Case 2: We have pickup and destination - compute actual driving route via Routes API
    if (effectivePickup && effectiveDest) {
      if (routesLib && (routesLib as any).Route?.computeRoutes) {
        const request = {
          origin: { lat: effectivePickup.lat, lng: effectivePickup.lng },
          destination: { lat: effectiveDest.lat, lng: effectiveDest.lng },
          travelMode: 'DRIVING',
          fields: ['path', 'distanceMeters', 'durationMillis', 'viewport', 'legs'],
        };

        (routesLib as any).Route.computeRoutes(request)
          .then(({ routes }: { routes: any[] }) => {
            if (!routes || routes.length === 0) return;
            const primaryRoute = routes[0];

            if (typeof primaryRoute.createPolylines === 'function') {
              const newPolylines = primaryRoute.createPolylines();
              newPolylines.forEach((poly: google.maps.Polyline) => {
                poly.setOptions({
                  strokeColor: '#2563eb',
                  strokeWeight: 5,
                  strokeOpacity: 0.9,
                });
                poly.setMap(map);
              });
              polylinesRef.current = newPolylines;
            } else if (primaryRoute.path) {
              const poly = new google.maps.Polyline({
                path: primaryRoute.path,
                strokeColor: '#2563eb',
                strokeWeight: 5,
                strokeOpacity: 0.9,
                map,
              });
              polylinesRef.current = [poly];
            }

            if (primaryRoute.viewport) {
              map.fitBounds(primaryRoute.viewport);
            }
          })
          .catch((err: any) => {
            console.warn('Routes API computeRoutes fallback to direct path:', err);
            // Fallback direct line with dashed effect
            const poly = new google.maps.Polyline({
              path: [
                { lat: effectivePickup.lat, lng: effectivePickup.lng },
                { lat: effectiveDest.lat, lng: effectiveDest.lng },
              ],
              strokeColor: '#3b82f6',
              strokeWeight: 4,
              strokeOpacity: 0.8,
              map,
            });
            polylinesRef.current = [poly];
          });
      } else {
        // Fallback standard polyline
        const poly = new google.maps.Polyline({
          path: [
            { lat: effectivePickup.lat, lng: effectivePickup.lng },
            { lat: effectiveDest.lat, lng: effectiveDest.lng },
          ],
          strokeColor: '#3b82f6',
          strokeWeight: 4,
          strokeOpacity: 0.8,
          map,
        });
        polylinesRef.current = [poly];
      }
    }

    return () => {
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [map, routesLib, effectivePickup, effectiveDest, activeRide]);

  return null;
}

/**
 * Camera Bounds Controller
 */
function CameraBoundsController({
  pickup,
  destination,
  activeRide,
  drivers,
}: {
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeRide?: Ride | null;
  drivers?: DriverProfile[];
}) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    const boundsPoints: google.maps.LatLngLiteral[] = [];

    const effectivePickup = activeRide ? activeRide.pickup : pickup;
    const effectiveDest = activeRide ? activeRide.destination : destination;

    if (effectivePickup) {
      boundsPoints.push({ lat: effectivePickup.lat, lng: effectivePickup.lng });
    }
    if (effectiveDest) {
      boundsPoints.push({ lat: effectiveDest.lat, lng: effectiveDest.lng });
    }
    if (activeRide?.driverLocation) {
      boundsPoints.push({ lat: activeRide.driverLocation.lat, lng: activeRide.driverLocation.lng });
    }

    if (boundsPoints.length >= 2) {
      const bounds = new google.maps.LatLngBounds();
      boundsPoints.forEach((pt) => bounds.extend(pt));
      map.fitBounds(bounds, { top: 70, right: 70, bottom: 70, left: 70 });
    } else if (boundsPoints.length === 1) {
      map.panTo(boundsPoints[0]);
    }
  }, [map, pickup, destination, activeRide]);

  return null;
}

export const GoogleVtcMap: React.FC<GoogleVtcMapProps> = ({
  center = [48.8566, 2.3522],
  zoom = 13,
  pickup,
  destination,
  activeRide,
  drivers = [],
  interactive = true,
  onMapClick,
  className = 'h-full w-full',
  theme = 'dark',
}) => {
  const [selectedDriver, setSelectedDriver] = useState<DriverProfile | null>(null);
  const [selectedPin, setSelectedPin] = useState<'pickup' | 'dest' | null>(null);

  const effectivePickup = activeRide ? activeRide.pickup : pickup;
  const effectiveDest = activeRide ? activeRide.destination : destination;

  const mapCenter = effectivePickup
    ? { lat: effectivePickup.lat, lng: effectivePickup.lng }
    : { lat: center[0], lng: center[1] };

  return (
    <div className={`relative ${className} min-h-[300px]`}>
      <Map
        mapId="DEMO_MAP_ID"
        defaultCenter={mapCenter}
        defaultZoom={zoom}
        gestureHandling={interactive ? 'greedy' : 'none'}
        disableDefaultUI={false}
        zoomControl={interactive}
        streetViewControl={false}
        mapTypeControl={false}
        fullscreenControl={false}
        colorScheme={theme === 'dark' ? 'DARK' : 'LIGHT'}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        onClick={(e) => {
          if (interactive && onMapClick && e.detail?.latLng) {
            onMapClick(e.detail.latLng.lat, e.detail.latLng.lng);
          }
          setSelectedDriver(null);
          setSelectedPin(null);
        }}
        className="h-full w-full"
      >
        {/* Route computation layer */}
        <RouteRenderer
          pickup={pickup}
          destination={destination}
          activeRide={activeRide}
        />

        {/* Dynamic camera bounds manager */}
        <CameraBoundsController
          pickup={pickup}
          destination={destination}
          activeRide={activeRide}
          drivers={drivers}
        />

        {/* 1. Fleet Available Drivers */}
        {drivers.map((drv) => {
          if (activeRide?.driverId === drv.id) return null;
          if (!drv.isOnline) return null;

          return (
            <AdvancedMarker
              key={drv.id}
              position={{ lat: drv.location.lat, lng: drv.location.lng }}
              onClick={() => setSelectedDriver(drv)}
              title={`${drv.name} - ${drv.vehicle.model}`}
            >
              <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-slate-900 border-2 border-emerald-500 shadow-xl text-emerald-400 transform transition-transform hover:scale-110 cursor-pointer">
                <Car className="w-4 h-4" />
              </div>
            </AdvancedMarker>
          );
        })}

        {/* Fleet Driver Info Window */}
        {selectedDriver && (
          <InfoWindow
            position={{ lat: selectedDriver.location.lat, lng: selectedDriver.location.lng }}
            onCloseClick={() => setSelectedDriver(null)}
          >
            <div className="p-2 text-slate-900 font-sans max-w-[220px]">
              <div className="flex items-center gap-1.5 mb-1">
                <span className="font-bold text-sm">{selectedDriver.name}</span>
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-xs text-slate-600">
                {selectedDriver.vehicle.model} · {selectedDriver.vehicle.category}
              </p>
              <div className="flex items-center gap-2 mt-1.5 text-xs">
                <span className="flex items-center gap-1 text-amber-500 font-bold">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  {selectedDriver.rating.toFixed(2)}
                </span>
                <span className="text-emerald-700 font-medium">Disponible</span>
              </div>
            </div>
          </InfoWindow>
        )}

        {/* 2. Pickup Location Marker */}
        {effectivePickup && (
          <AdvancedMarker
            position={{ lat: effectivePickup.lat, lng: effectivePickup.lng }}
            onClick={() => setSelectedPin('pickup')}
            title="Lieu de prise en charge"
          >
            <div className="relative flex flex-col items-center cursor-pointer group">
              <div className="w-8 h-8 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-2xl border-2 border-white ring-2 ring-emerald-400 transform transition-transform group-hover:scale-110">
                <Navigation className="w-4 h-4" />
              </div>
              <span className="mt-1 bg-slate-900/90 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow whitespace-nowrap border border-slate-700">
                Départ
              </span>
            </div>
          </AdvancedMarker>
        )}

        {/* Pickup Info Window */}
        {selectedPin === 'pickup' && effectivePickup && (
          <InfoWindow
            position={{ lat: effectivePickup.lat, lng: effectivePickup.lng }}
            onCloseClick={() => setSelectedPin(null)}
          >
            <div className="p-1.5 text-slate-900 font-sans max-w-[220px]">
              <span className="font-bold text-xs text-emerald-700 block">Lieu de prise en charge</span>
              <p className="text-xs mt-0.5 text-slate-700">{effectivePickup.address}</p>
            </div>
          </InfoWindow>
        )}

        {/* 3. Destination Location Marker */}
        {effectiveDest && (
          <AdvancedMarker
            position={{ lat: effectiveDest.lat, lng: effectiveDest.lng }}
            onClick={() => setSelectedPin('dest')}
            title="Destination d'arrivée"
          >
            <div className="relative flex flex-col items-center cursor-pointer group">
              <div className="w-8 h-8 bg-rose-600 text-white rounded-full flex items-center justify-center shadow-2xl border-2 border-white ring-2 ring-rose-400 transform transition-transform group-hover:scale-110">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="mt-1 bg-slate-900/90 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow whitespace-nowrap border border-slate-700">
                Arrivée
              </span>
            </div>
          </AdvancedMarker>
        )}

        {/* Destination Info Window */}
        {selectedPin === 'dest' && effectiveDest && (
          <InfoWindow
            position={{ lat: effectiveDest.lat, lng: effectiveDest.lng }}
            onCloseClick={() => setSelectedPin(null)}
          >
            <div className="p-1.5 text-slate-900 font-sans max-w-[220px]">
              <span className="font-bold text-xs text-rose-700 block">Destination</span>
              <p className="text-xs mt-0.5 text-slate-700">{effectiveDest.address}</p>
            </div>
          </InfoWindow>
        )}

        {/* 4. Active Assigned Driver Marker (Live Ride) */}
        {activeRide &&
          activeRide.driverLocation &&
          ['ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(activeRide.status) && (
            <AdvancedMarker
              position={{
                lat: activeRide.driverLocation.lat,
                lng: activeRide.driverLocation.lng,
              }}
              title={`Chauffeur en route: ${activeRide.driverName || 'Chauffeur'}`}
            >
              <div className="relative flex flex-col items-center cursor-pointer">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white border-2 border-white shadow-2xl ring-4 ring-blue-500/40 animate-pulse">
                  <Car className="w-5 h-5" />
                </div>
                <div className="mt-1 bg-blue-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full shadow-lg whitespace-nowrap">
                  {activeRide.driverName || 'Chauffeur'}
                </div>
              </div>
            </AdvancedMarker>
          )}
      </Map>

      {/* Decorative GPS & Google Maps Status Badge */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-2 bg-slate-950/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 text-xs text-slate-200 pointer-events-none shadow-lg">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
        <span className="font-bold text-white">Google Maps</span>
        <span className="text-[10px] text-emerald-400 font-medium">· GPS Temps Réel</span>
      </div>
    </div>
  );
};
