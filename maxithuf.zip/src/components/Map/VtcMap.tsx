import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { DriverProfile, LocationPoint, Ride } from '../../types/vtc';
import { vtcStore } from '../../services/vtcStore';
import { GoogleVtcMap } from './GoogleVtcMap';

export interface VtcMapProps {
  center?: [number, number];
  zoom?: number;
  pickup?: LocationPoint | null;
  destination?: LocationPoint | null;
  activeRide?: Ride | null;
  drivers?: DriverProfile[];
  interactive?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  className?: string;
  theme?: 'dark' | 'light';
}

/**
 * Leaflet map fallback implementation
 */
const LeafletVtcMap: React.FC<VtcMapProps> = ({
  center = [48.8566, 2.3522], // Paris
  zoom = 13,
  pickup,
  destination,
  activeRide,
  drivers = [],
  interactive = true,
  onMapClick,
  className = 'h-full w-full',
  theme = 'dark',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.Polyline | null>(null);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center,
      zoom,
      zoomControl: false,
      attributionControl: false,
    });

    const tileUrl =
      theme === 'dark'
        ? 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

    L.tileLayer(tileUrl, {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    L.control.zoom({ position: 'topright' }).addTo(map);

    const markersGroup = L.layerGroup().addTo(map);
    markersLayerRef.current = markersGroup;

    if (interactive && onMapClick) {
      map.on('click', (e: L.LeafletMouseEvent) => {
        onMapClick(e.latlng.lat, e.latlng.lng);
      });
    }

    mapInstanceRef.current = map;

    let resizeObserver: ResizeObserver | null = null;
    if (mapContainerRef.current && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        map.invalidateSize();
      });
      resizeObserver.observe(mapContainerRef.current);
    }

    return () => {
      if (resizeObserver) resizeObserver.disconnect();
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Markers and Routes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    if (routeLayerRef.current) {
      routeLayerRef.current.remove();
      routeLayerRef.current = null;
    }

    const boundsPoints: [number, number][] = [];

    // 1. Available fleet drivers around the map
    drivers.forEach((drv) => {
      if (activeRide?.driverId === drv.id) return;
      if (!drv.isOnline) return;

      const driverIcon = L.divIcon({
        className: 'custom-driver-icon',
        html: `
          <div class="relative flex items-center justify-center w-8 h-8 rounded-full bg-slate-900 border-2 border-emerald-500 shadow-lg text-emerald-400 transform transition-transform hover:scale-110">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
            </svg>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = L.marker([drv.location.lat, drv.location.lng], { icon: driverIcon });
      marker.bindPopup(`
        <div class="p-2 text-xs font-sans">
          <p class="font-bold text-slate-900">${drv.name}</p>
          <p class="text-slate-600">${drv.vehicle.model} (${drv.vehicle.category})</p>
          <p class="text-emerald-700 font-semibold mt-1">⭐ ${drv.rating.toFixed(2)} · Disponible</p>
        </div>
      `);
      markersGroup.addLayer(marker);
    });

    // 2. Pickup Location Marker
    const effectivePickup = activeRide ? activeRide.pickup : pickup;
    if (effectivePickup) {
      boundsPoints.push([effectivePickup.lat, effectivePickup.lng]);
      const pickupIcon = L.divIcon({
        className: 'custom-pickup-icon',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="w-7 h-7 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-xl border-2 border-white ring-2 ring-emerald-400">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
              </svg>
            </div>
            <span class="absolute -bottom-6 bg-slate-900/90 text-white text-[10px] font-semibold px-2 py-0.5 rounded shadow whitespace-nowrap border border-slate-700">Départ</span>
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const marker = L.marker([effectivePickup.lat, effectivePickup.lng], { icon: pickupIcon });
      marker.bindPopup(`<b>Départ:</b><br/>${effectivePickup.address}`);
      markersGroup.addLayer(marker);
    }

    // 3. Destination Location Marker
    const effectiveDest = activeRide ? activeRide.destination : destination;
    if (effectiveDest) {
      boundsPoints.push([effectiveDest.lat, effectiveDest.lng]);
      const destIcon = L.divIcon({
        className: 'custom-dest-icon',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="w-7 h-7 bg-rose-600 text-white rounded-full flex items-center justify-center shadow-xl border-2 border-white ring-2 ring-rose-400">
              <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M14.4 6L14 4H5v17h2v-7h5.6l.4 2h7V6z"/>
              </svg>
            </div>
            <span class="absolute -bottom-6 bg-slate-900/90 text-white text-[10px] font-semibold px-2 py-0.5 rounded shadow whitespace-nowrap border border-slate-700">Arrivée</span>
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const marker = L.marker([effectiveDest.lat, effectiveDest.lng], { icon: destIcon });
      marker.bindPopup(`<b>Arrivée:</b><br/>${effectiveDest.address}`);
      markersGroup.addLayer(marker);
    }

    // 4. Active Assigned Driver Marker (Animated position)
    if (activeRide && activeRide.driverLocation && ['ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(activeRide.status)) {
      boundsPoints.push([activeRide.driverLocation.lat, activeRide.driverLocation.lng]);
      const activeDriverIcon = L.divIcon({
        className: 'custom-active-driver',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white border-2 border-white shadow-2xl ring-4 ring-blue-500/40">
              <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
              </svg>
            </div>
            <div class="absolute -top-6 bg-blue-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full shadow-lg whitespace-nowrap">
              ${activeRide.driverName || 'Chauffeur'}
            </div>
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      });

      const marker = L.marker([activeRide.driverLocation.lat, activeRide.driverLocation.lng], {
        icon: activeDriverIcon,
      });
      markersGroup.addLayer(marker);
    }

    // 5. Draw Route Polyline
    if (activeRide && activeRide.currentRoutePoints && activeRide.currentRoutePoints.length > 0) {
      const poly = L.polyline(activeRide.currentRoutePoints, {
        color: '#2563eb',
        weight: 5,
        opacity: 0.85,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);
      routeLayerRef.current = poly;
    } else if (effectivePickup && effectiveDest) {
      const directLine = L.polyline(
        [
          [effectivePickup.lat, effectivePickup.lng],
          [effectiveDest.lat, effectiveDest.lng],
        ],
        {
          color: '#3b82f6',
          weight: 4,
          dashArray: '8, 8',
          opacity: 0.7,
        }
      ).addTo(map);
      routeLayerRef.current = directLine;
    }

    if (boundsPoints.length >= 2) {
      map.fitBounds(L.latLngBounds(boundsPoints), {
        padding: [60, 60],
        maxZoom: 15,
        animate: true,
      });
    }
  }, [pickup, destination, activeRide, drivers, theme]);

  return (
    <div className={`relative ${className} min-h-[300px]`}>
      <div ref={mapContainerRef} className="h-full w-full rounded-2xl overflow-hidden shadow-inner" />
      <div className="absolute top-4 left-4 z-[400] flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs text-slate-300 pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
        <span className="font-medium">Leaflet · GPS Actif</span>
      </div>
    </div>
  );
};

/**
 * Main VtcMap component:
 * Defaults to Google Maps Platform via @vis.gl/react-google-maps.
 * Falls back to Leaflet if explicitly chosen by the user in Settings.
 */
export const VtcMap: React.FC<VtcMapProps> = (props) => {
  const passenger = vtcStore.getPassenger();
  const mapEngine = passenger.mapEngine || 'google';

  // If user explicitly configured Leaflet in settings, render Leaflet
  if (mapEngine === 'leaflet') {
    return <LeafletVtcMap {...props} />;
  }

  // Otherwise, default to Google Maps Platform
  return <GoogleVtcMap {...props} />;
};
