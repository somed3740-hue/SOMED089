import React, { useState, useEffect } from 'react';
import { Phone, PhoneOff, Mic, MicOff, Volume2, VolumeX, ShieldCheck } from 'lucide-react';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  callerName: string;
  callerRole: string;
  avatarUrl?: string;
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  callerName,
  callerRole,
}) => {
  const [seconds, setSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(true);

  useEffect(() => {
    if (!isOpen) {
      setSeconds(0);
      return;
    }
    const interval = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remaining = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-sm p-6 flex flex-col items-center text-center shadow-2xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 inset-x-0 h-32 bg-blue-500/10 blur-2xl" />

        {/* Masked numbers privacy badge */}
        <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-3 py-1 rounded-full mb-8 z-10">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Appel sécurisé (Numéro masqué)</span>
        </div>

        {/* Profile Avatar with Audio Waveform Ring */}
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-full bg-slate-800 border-2 border-blue-500/50 flex items-center justify-center text-2xl font-bold text-white shadow-xl">
            {callerName.charAt(0)}
          </div>
          <div className="absolute -inset-2 rounded-full border border-blue-500/30 animate-ping pointer-events-none" />
        </div>

        <h3 className="text-xl font-bold text-white">{callerName}</h3>
        <p className="text-sm text-slate-400 mt-1">{callerRole}</p>
        <p className="text-xs text-blue-400 font-mono mt-3">{formatTimer(seconds)}</p>

        {/* Call Controls */}
        <div className="grid grid-cols-2 gap-4 w-full mt-10">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition border ${
              isMuted
                ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            <span className="text-xs">{isMuted ? 'Micro coupé' : 'Muet'}</span>
          </button>

          <button
            onClick={() => setIsSpeaker(!isSpeaker)}
            className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition border ${
              isSpeaker
                ? 'bg-blue-500/20 border-blue-500/40 text-blue-400'
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {isSpeaker ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            <span className="text-xs">Haut-parleur</span>
          </button>
        </div>

        {/* End Call Button */}
        <button
          onClick={onClose}
          className="mt-8 w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/40 transition hover:scale-105 active:scale-95"
        >
          <PhoneOff className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};
