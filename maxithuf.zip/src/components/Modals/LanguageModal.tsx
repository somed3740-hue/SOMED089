import React from 'react';
import { Globe, Check, X } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { soundEffects } from '../../utils/audio';
import { SUPPORTED_LANGUAGES, Language, useTranslation } from '../../utils/i18n';

interface LanguageModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LanguageModal: React.FC<LanguageModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const { lang, t, setLanguage } = useTranslation();

  const handleSelectLanguage = (code: Language) => {
    soundEffects.playClick();
    setLanguage(code);

    const labels: Record<Language, string> = {
      fr: 'Français activé pour toute l’application',
      en: 'English activated across all interfaces',
      es: 'Español activado en todas las interfaces',
    };

    vtcStore.sendPushNotification({
      title: t('language'),
      body: labels[code],
      category: 'SYSTEM',
      badge: code.toUpperCase(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-[2200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200 select-none">
      <div className={`w-full max-w-sm rounded-3xl border shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-800 text-white'
      }`}>
        {/* Header */}
        <div className={`px-5 py-4 border-b flex items-center justify-between ${
          isLight ? 'border-slate-100 bg-slate-50' : 'border-neutral-900 bg-neutral-900/60'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm">{t('language')}</h3>
              <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                {t('languageSubtitle')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'hover:bg-slate-200 text-slate-500' : 'hover:bg-neutral-800 text-neutral-400 hover:text-white'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Language Options List */}
        <div className="p-4 space-y-2.5">
          {SUPPORTED_LANGUAGES.map((item) => {
            const isSelected = lang === item.code;
            return (
              <button
                key={item.code}
                onClick={() => handleSelectLanguage(item.code)}
                className={`w-full p-3.5 rounded-2xl border transition flex items-center justify-between text-left group active:scale-[0.98] ${
                  isSelected
                    ? isLight
                      ? 'border-yellow-400 bg-yellow-50/60 ring-2 ring-yellow-400/40 shadow-sm'
                      : 'border-yellow-400 bg-yellow-400/10 ring-2 ring-yellow-400/30 shadow-sm'
                    : isLight
                      ? 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70 hover:border-slate-300'
                      : 'border-neutral-900 bg-neutral-900/50 hover:bg-neutral-900 hover:border-neutral-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl flex-shrink-0" role="img" aria-label={item.name}>
                    {item.flag}
                  </span>
                  <div>
                    <p className={`font-extrabold text-sm ${isSelected ? 'text-yellow-500' : ''}`}>
                      {item.name}
                    </p>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      {item.label}
                    </p>
                  </div>
                </div>

                <div className={`w-6 h-6 rounded-full flex items-center justify-center transition ${
                  isSelected
                    ? 'bg-yellow-400 text-black shadow-md'
                    : isLight ? 'border border-slate-300' : 'border border-neutral-700'
                }`}>
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer Note */}
        <div className={`px-5 py-3 border-t text-center ${
          isLight ? 'border-slate-100 bg-slate-50/50 text-slate-500' : 'border-neutral-900 bg-neutral-900/40 text-neutral-400'
        }`}>
          <p className="text-[11px]">
            {lang === 'fr' && 'Langue appliquée instantanément à toute l’application'}
            {lang === 'en' && 'Language instantly applied across the entire app'}
            {lang === 'es' && 'Idioma aplicado instantáneamente en toda la aplicación'}
          </p>
        </div>
      </div>
    </div>
  );
};
