import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Car, 
  Tag, 
  UserCheck, 
  MessageSquare, 
  Wallet, 
  ShieldCheck, 
  Bell, 
  Trash2, 
  CheckCheck, 
  Sparkles, 
  Package, 
  Store, 
  Clock, 
  ChevronRight,
  Sliders,
  Send,
  SlidersHorizontal,
  Info
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { AppNotification, NotificationCategory } from '../../types/vtc';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPermissions?: () => void;
  onSelectAction?: (notif: AppNotification) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onOpenPermissions,
  onSelectAction,
}) => {
  const [activeTab, setActiveTab] = useState<'history' | 'settings'>('history');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | NotificationCategory>('ALL');
  
  // Custom push simulator state
  const [customTitle, setCustomTitle] = useState('');
  const [customBody, setCustomBody] = useState('');
  const [customCategory, setCustomCategory] = useState<NotificationCategory>('RIDE');
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);

  if (!isOpen) return null;

  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const prefs = passenger.notificationPreferences;
  const notifications = vtcStore.getNotifications();
  const unreadCount = vtcStore.getUnreadNotificationsCount();

  const handleToggle = (key: keyof typeof prefs) => {
    vtcStore.updateNotificationPreferences({
      [key]: !prefs[key],
    });
  };

  const handleMarkAllRead = () => {
    vtcStore.markAllNotificationsAsRead();
  };

  const handleClearAll = () => {
    if (confirm('Voulez-vous effacer tout l\'historique des notifications ?')) {
      vtcStore.clearAllNotifications();
    }
  };

  const handleSendCustomPush = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;

    vtcStore.sendPushNotification({
      title: customTitle,
      body: customBody || 'Notification envoyée depuis le centre de contrôle SOMED.',
      category: customCategory,
      badge: 'Test En Direct'
    });

    setCustomTitle('');
    setCustomBody('');
  };

  const handleTriggerPreset = (type: 'driver_assigned' | 'driver_arrived' | 'payment_ok' | 'courier_delivering' | 'promo') => {
    switch (type) {
      case 'driver_assigned':
        vtcStore.sendPushNotification({
          title: 'Chauffeur confirmé !',
          body: 'Sofiane arrive dans 3 minutes avec sa Mercedes Classe E (GD-411-AZ).',
          category: 'RIDE',
          badge: 'En route',
          actions: [
            { id: 'view', label: 'Suivre la course', actionType: 'VIEW_RIDE', variant: 'primary' }
          ]
        });
        break;
      case 'driver_arrived':
        vtcStore.sendPushNotification({
          title: 'Votre chauffeur est là !',
          body: 'Votre chauffeur vous attend au point de rendez-vous.',
          category: 'RIDE',
          badge: 'Arrivé',
          actions: [
            { id: 'ready', label: 'Je descends', actionType: 'VIEW_RIDE', variant: 'primary' }
          ]
        });
        break;
      case 'payment_ok':
        vtcStore.sendPushNotification({
          title: 'Paiement de 34,50 € validé',
          body: 'Votre facture SOMED Prestige est prête et téléchargeable au format PDF.',
          category: 'PAYMENT',
          badge: 'Reçu',
          actions: [
            { id: 'rec', label: 'Voir facture', actionType: 'VIEW_WALLET', variant: 'primary' }
          ]
        });
        break;
      case 'courier_delivering':
        vtcStore.sendPushNotification({
          title: 'Coursier en approche de votre adresse',
          body: 'Votre colis express arrive d\'ici 5 minutes au point de livraison.',
          category: 'DELIVERY',
          badge: 'Express',
          actions: [
            { id: 'del', label: 'Suivre coursier', actionType: 'VIEW_DELIVERY', variant: 'primary' }
          ]
        });
        break;
      case 'promo':
        vtcStore.sendPushNotification({
          title: 'Offre Prestige : -20% sur votre course',
          body: 'Le code promo PRESTIGE20 a été activé sur votre profil SOMED.',
          category: 'SYSTEM',
          badge: 'Promo VIP'
        });
        break;
    }
  };

  const filteredNotifications = notifications.filter((n) => {
    if (categoryFilter === 'ALL') return true;
    return n.category === categoryFilter;
  });

  const notificationItems = [
    {
      key: 'tripUpdates' as const,
      label: 'Mises à jour des courses',
      desc: 'Statut du trajet, arrivée du chauffeur, fin de course',
      icon: Car,
    },
    {
      key: 'promotions' as const,
      label: 'Promotions et offres VIP',
      desc: 'Réductions, codes avantages et offres exclusives',
      icon: Tag,
    },
    {
      key: 'rideRequests' as const,
      label: 'Demandes de courses à proximité',
      desc: 'Alertes sur les réservations et disponibilités proches',
      icon: UserCheck,
    },
    {
      key: 'chatMessages' as const,
      label: 'Messages de messagerie',
      desc: 'Messages en direct avec le chauffeur pendant la course',
      icon: MessageSquare,
    },
    {
      key: 'walletPayments' as const,
      label: 'Portefeuille et reçus',
      desc: 'Confirmations de paiement, recharges et reçus PDF',
      icon: Wallet,
    },
  ];

  return (
    <div className="fixed inset-0 z-[1300] flex flex-col bg-black/80 backdrop-blur-md text-white select-none animate-in fade-in duration-200">
      <div className={`flex flex-col h-full max-w-lg mx-auto w-full border-x shadow-2xl transition-colors ${
        isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-neutral-950 border-neutral-900 text-white'
      }`}>
        {/* Header */}
        <header className={`px-5 py-4 border-b flex items-center justify-between flex-shrink-0 ${
          isLight ? 'border-slate-200 bg-white' : 'border-neutral-900 bg-black'
        }`}>
          <button
            onClick={onClose}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
              isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-700' : 'bg-neutral-900 text-neutral-300 hover:text-white'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center">
            <h2 className="font-extrabold text-sm sm:text-base flex items-center justify-center gap-1.5">
              <Bell className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              <span>Notifications & Push</span>
              {unreadCount > 0 && (
                <span className="bg-yellow-400 text-black text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {unreadCount}
                </span>
              )}
            </h2>
            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
              Alertes push en direct & Historique
            </p>
          </div>

          {onOpenPermissions ? (
            <button
              onClick={() => {
                onClose();
                onOpenPermissions();
              }}
              className="p-2 rounded-xl bg-yellow-400/20 text-yellow-500 hover:bg-yellow-400/30 transition active:scale-95"
              title="Gérer les autorisations système"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>
          ) : (
            <div className="w-9" />
          )}
        </header>

        {/* Tab switcher: Historique vs Réglages */}
        <div className={`p-2 border-b flex items-center gap-2 ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900 border-neutral-800'
        }`}>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-yellow-400 text-black shadow-sm'
                : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Historique Push ({notifications.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              activeTab === 'settings'
                ? 'bg-yellow-400 text-black shadow-sm'
                : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Préférences & Types</span>
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'history' ? (
            /* TAB 1: HISTORIQUE PUSH */
            <div className="space-y-3">
              {/* Category Filter Pills & Actions */}
              <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 no-scrollbar">
                <div className="flex items-center gap-1.5">
                  {(['ALL', 'RIDE', 'DELIVERY', 'PAYMENT', 'SYSTEM'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setCategoryFilter(cat)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition whitespace-nowrap ${
                        categoryFilter === cat
                          ? 'bg-yellow-400 text-black'
                          : isLight ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                      }`}
                    >
                      {cat === 'ALL' && 'Toutes'}
                      {cat === 'RIDE' && 'Courses'}
                      {cat === 'DELIVERY' && 'Livraisons'}
                      {cat === 'PAYMENT' && 'Paiements'}
                      {cat === 'SYSTEM' && 'Système'}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1 flex-shrink-0">
                  {unreadCount > 0 && (
                    <button
                      onClick={handleMarkAllRead}
                      className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition ${
                        isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                      }`}
                      title="Tout marquer comme lu"
                    >
                      <CheckCheck className="w-3.5 h-3.5 text-yellow-500" />
                    </button>
                  )}
                  {notifications.length > 0 && (
                    <button
                      onClick={handleClearAll}
                      className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition ${
                        isLight ? 'text-slate-600 hover:text-rose-600' : 'text-neutral-400 hover:text-rose-400'
                      }`}
                      title="Effacer tout l'historique"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Push Simulator Expandable Box */}
              <div className={`rounded-2xl border p-3.5 transition ${
                isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-neutral-900 border-neutral-800'
              }`}>
                <div 
                  onClick={() => setIsSimulatorOpen(!isSimulatorOpen)}
                  className="flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-yellow-500" />
                    <span className="font-bold text-xs">Simulateur de Notifications Push</span>
                  </div>
                  <span className="text-[10px] font-bold text-yellow-500">
                    {isSimulatorOpen ? 'Masquer' : 'Tester push qui descend ↓'}
                  </span>
                </div>

                {isSimulatorOpen && (
                  <div className="mt-3 pt-3 border-t border-neutral-500/20 space-y-3">
                    <p className={`text-[11px] leading-relaxed ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      Cliquez pour déclencher une vraie bannière push descendant du haut de votre écran avec son et vibration :
                    </p>

                    {/* Quick Presets */}
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        onClick={() => handleTriggerPreset('driver_assigned')}
                        className={`p-2 rounded-xl text-[11px] font-bold text-left transition flex items-center gap-1.5 ${
                          isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                        }`}
                      >
                        <Car className="w-3.5 h-3.5 text-yellow-400" />
                        <span>Chauffeur assigné</span>
                      </button>

                      <button
                        onClick={() => handleTriggerPreset('driver_arrived')}
                        className={`p-2 rounded-xl text-[11px] font-bold text-left transition flex items-center gap-1.5 ${
                          isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                        }`}
                      >
                        <Car className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Chauffeur arrivé</span>
                      </button>

                      <button
                        onClick={() => handleTriggerPreset('payment_ok')}
                        className={`p-2 rounded-xl text-[11px] font-bold text-left transition flex items-center gap-1.5 ${
                          isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                        }`}
                      >
                        <Wallet className="w-3.5 h-3.5 text-amber-400" />
                        <span>Paiement validé</span>
                      </button>

                      <button
                        onClick={() => handleTriggerPreset('courier_delivering')}
                        className={`p-2 rounded-xl text-[11px] font-bold text-left transition flex items-center gap-1.5 ${
                          isLight ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                        }`}
                      >
                        <Package className="w-3.5 h-3.5 text-sky-400" />
                        <span>Coursier express</span>
                      </button>
                    </div>

                    {/* Custom Push Form */}
                    <form onSubmit={handleSendCustomPush} className="pt-2 border-t border-neutral-500/20 space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customTitle}
                          onChange={(e) => setCustomTitle(e.target.value)}
                          placeholder="Titre de votre notification..."
                          className={`flex-1 px-3 py-1.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                            isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-800 border-neutral-700 text-white'
                          }`}
                        />
                        <select
                          value={customCategory}
                          onChange={(e) => setCustomCategory(e.target.value as any)}
                          className={`px-2 py-1.5 rounded-xl text-xs border focus:outline-none ${
                            isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-800 border-neutral-700 text-white'
                          }`}
                        >
                          <option value="RIDE">Course</option>
                          <option value="DELIVERY">Livraison</option>
                          <option value="BUSINESS">Business</option>
                          <option value="PAYMENT">Paiement</option>
                          <option value="SYSTEM">Système</option>
                        </select>
                      </div>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customBody}
                          onChange={(e) => setCustomBody(e.target.value)}
                          placeholder="Message descriptif du push..."
                          className={`flex-1 px-3 py-1.5 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-yellow-400 ${
                            isLight ? 'bg-slate-100 border-slate-300 text-slate-900' : 'bg-neutral-800 border-neutral-700 text-white'
                          }`}
                        />
                        <button
                          type="submit"
                          disabled={!customTitle.trim()}
                          className="px-3 py-1.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 disabled:opacity-50 text-black font-black text-xs transition flex items-center gap-1"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Envoyer</span>
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </div>

              {/* Notification List */}
              {filteredNotifications.length === 0 ? (
                <div className={`p-8 text-center rounded-2xl border ${
                  isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                }`}>
                  <Bell className="w-8 h-8 mx-auto text-neutral-500 mb-2" />
                  <p className="font-bold text-sm">Aucune notification</p>
                  <p className="text-xs mt-1">Vous êtes à jour ! Toutes les alertes de vos courses apparaîtront ici.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredNotifications.map((notif) => {
                    const dateFormatted = new Date(notif.timestamp).toLocaleTimeString('fr-FR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    });

                    return (
                      <div
                        key={notif.id}
                        onClick={() => {
                          vtcStore.markNotificationAsRead(notif.id);
                          if (onSelectAction) {
                            onSelectAction(notif);
                          }
                        }}
                        className={`p-3.5 rounded-2xl border transition cursor-pointer ${
                          !notif.read
                            ? isLight 
                              ? 'bg-amber-50/70 border-yellow-300 shadow-sm' 
                              : 'bg-yellow-400/5 border-yellow-400/30'
                            : isLight
                            ? 'bg-white border-slate-200 hover:border-slate-300'
                            : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2.5 min-w-0">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 ${
                              notif.category === 'RIDE' ? 'bg-yellow-400/20 text-yellow-500' :
                              notif.category === 'DELIVERY' ? 'bg-emerald-400/20 text-emerald-400' :
                              notif.category === 'PAYMENT' ? 'bg-amber-400/20 text-amber-400' :
                              'bg-neutral-800 text-neutral-300'
                            }`}>
                              {notif.category === 'RIDE' && <Car className="w-4 h-4" />}
                              {notif.category === 'DELIVERY' && <Package className="w-4 h-4" />}
                              {notif.category === 'BUSINESS' && <Store className="w-4 h-4" />}
                              {notif.category === 'PAYMENT' && <Wallet className="w-4 h-4" />}
                              {notif.category === 'SYSTEM' && <Bell className="w-4 h-4" />}
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <h4 className={`text-xs font-bold leading-tight ${
                                  !notif.read ? 'text-yellow-500' : isLight ? 'text-slate-900' : 'text-white'
                                }`}>
                                  {notif.title}
                                </h4>
                                {!notif.read && (
                                  <span className="w-2 h-2 rounded-full bg-yellow-400 flex-shrink-0 animate-pulse" />
                                )}
                              </div>
                              <p className={`text-[11px] mt-0.5 leading-relaxed line-clamp-2 ${
                                isLight ? 'text-slate-600' : 'text-neutral-400'
                              }`}>
                                {notif.body}
                              </p>
                              <span className={`text-[10px] block mt-1 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                                {dateFormatted}
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              vtcStore.deleteNotification(notif.id);
                            }}
                            className={`p-1.5 rounded-lg transition ${
                              isLight ? 'text-slate-400 hover:text-rose-600' : 'text-neutral-500 hover:text-rose-400'
                            }`}
                            title="Supprimer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            /* TAB 2: PRÉFÉRENCES & TYPES D'ALERTES */
            <div className="space-y-4">
              {/* Yellow Info Banner in French */}
              <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-2xl p-4 flex items-center gap-3 text-yellow-300 text-xs font-semibold">
                <Info className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span>Personnalisez les notifications et alertes sonores que vous souhaitez recevoir sur SOMED</span>
              </div>

              {/* Permissions shortcut button */}
              {onOpenPermissions && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenPermissions();
                  }}
                  className={`w-full p-4 rounded-2xl border transition flex items-center justify-between text-left ${
                    isLight 
                      ? 'bg-white hover:bg-slate-50 border-slate-200' 
                      : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm">Gérer les autorisations du navigateur</h4>
                      <p className={`text-[11px] mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                        Notifications push, géolocalisation GPS, microphone et stockage
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>
              )}

              {/* List of Notification Toggles in French */}
              <div className="space-y-3">
                {notificationItems.map((item) => {
                  const Icon = item.icon;
                  const isEnabled = prefs[item.key];

                  return (
                    <div
                      key={item.key}
                      onClick={() => handleToggle(item.key)}
                      className={`rounded-2xl p-4 border flex items-center justify-between cursor-pointer transition ${
                        isLight
                          ? 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                          : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3.5 min-w-0 pr-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          isLight ? 'bg-slate-100 text-slate-700' : 'bg-neutral-800 text-neutral-300'
                        }`}>
                          <Icon className="w-5 h-5 stroke-[1.8]" />
                        </div>
                        <div className="min-w-0">
                          <p className={`font-bold text-xs sm:text-sm leading-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>
                            {item.label}
                          </p>
                          <p className={`text-[11px] mt-0.5 leading-snug ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                            {item.desc}
                          </p>
                        </div>
                      </div>

                      {/* Yellow Switch Toggle */}
                      <div
                        className={`w-12 h-7 rounded-full flex items-center p-1 transition-colors duration-200 flex-shrink-0 ${
                          isEnabled ? 'bg-yellow-400' : isLight ? 'bg-slate-300' : 'bg-neutral-800'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 ${
                            isEnabled ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className={`p-4 border-t flex items-center justify-between ${
          isLight ? 'border-slate-200 bg-white' : 'border-neutral-900 bg-neutral-950'
        }`}>
          <button
            onClick={onClose}
            className={`w-full py-3 rounded-xl font-bold text-xs transition ${
              isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'
            }`}
          >
            Fermer les notifications
          </button>
        </footer>
      </div>
    </div>
  );
};
