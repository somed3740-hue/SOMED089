import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Banknote, 
  Building2, 
  Plus, 
  CreditCard, 
  Check, 
  MoreVertical,
  X,
  Trash2
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface PaymentMethodsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PaymentMethodsModal: React.FC<PaymentMethodsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const passenger = vtcStore.getPassenger();
  const [selectedMethod, setSelectedMethod] = useState<'CASH' | 'BANK' | string>('card-1');
  const [showAddCard, setShowAddCard] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expDate, setExpDate] = useState('');
  const [cvc, setCvc] = useState('');

  const handleAddCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const last4 = cardNumber.slice(-4) || '8899';
    const [expMonth, expYear] = expDate.split('/') || ['12', '2030'];
    vtcStore.addSavedCard({
      brand: 'VISA',
      last4,
      expMonth: expMonth || '12',
      expYear: expYear || '2030',
      isDefault: passenger.savedCards.length === 0,
      gateway: 'via Stripe',
    });
    setCardNumber('');
    setExpDate('');
    setCvc('');
    setShowAddCard(false);
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Top Header (Screenshot 5) */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">Payment methods</h2>
        <div className="w-9" />
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6 max-w-md mx-auto w-full">
        {/* Cash section (Screenshot 5) */}
        <div className="space-y-3">
          <h3 className="text-xs font-semibold text-neutral-400">Cash</h3>

          {/* Cash Item */}
          <div 
            onClick={() => setSelectedMethod('CASH')}
            className={`bg-neutral-950 p-4 rounded-2xl border transition cursor-pointer flex items-center gap-3.5 ${
              selectedMethod === 'CASH' ? 'border-yellow-400 ring-1 ring-yellow-400' : 'border-neutral-900 hover:border-neutral-800'
            }`}
          >
            <div className="w-11 h-11 rounded-xl bg-emerald-950/70 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
              <Banknote className="w-6 h-6 stroke-[1.8]" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm text-white leading-tight">Cash</p>
              <p className="text-xs text-neutral-400 mt-0.5">Pay the driver at the end of the trip</p>
            </div>
            {selectedMethod === 'CASH' && (
              <div className="w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center">
                <Check className="w-3.5 h-3.5 text-black stroke-[3]" />
              </div>
            )}
          </div>
        </div>

        {/* Bank Transfer section (Screenshot 5) */}
        <div className="space-y-3">
          <h3 className="text-xs font-semibold text-neutral-400">Cash</h3>

          <div 
            onClick={() => setSelectedMethod('BANK')}
            className={`bg-neutral-950 p-4 rounded-2xl border transition cursor-pointer flex items-center gap-3.5 ${
              selectedMethod === 'BANK' ? 'border-yellow-400 ring-1 ring-yellow-400' : 'border-neutral-900 hover:border-neutral-800'
            }`}
          >
            <div className="w-11 h-11 rounded-xl bg-emerald-950/70 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
              <Building2 className="w-6 h-6 stroke-[1.8]" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm text-white leading-tight">Bank Transfer</p>
              <p className="text-xs text-neutral-400 mt-0.5">Pay the driver at the end of the trip</p>
            </div>
            {selectedMethod === 'BANK' && (
              <div className="w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center">
                <Check className="w-3.5 h-3.5 text-black stroke-[3]" />
              </div>
            )}
          </div>
        </div>

        {/* Saved Cards section (Screenshot 5) */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-neutral-400">Saved cards</h3>
            <button
              onClick={() => setShowAddCard(true)}
              className="text-xs font-bold text-yellow-400 hover:text-yellow-300 flex items-center gap-1 transition"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Add</span>
            </button>
          </div>

          {/* Cards List */}
          <div className="space-y-2.5">
            {passenger.savedCards.map((card) => {
              const isSelected = selectedMethod === card.id || card.isDefault;
              return (
                <div
                  key={card.id}
                  onClick={() => setSelectedMethod(card.id)}
                  className={`bg-neutral-950 p-4 rounded-2xl border transition cursor-pointer flex items-center gap-3.5 ${
                    isSelected ? 'border-yellow-400 ring-1 ring-yellow-400/80 shadow-lg shadow-yellow-400/5' : 'border-neutral-900 hover:border-neutral-800'
                  }`}
                >
                  <div className="w-11 h-11 rounded-xl bg-indigo-950/80 border border-indigo-800/60 flex items-center justify-center text-indigo-300">
                    <CreditCard className="w-6 h-6 stroke-[1.8]" />
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-sm text-white leading-tight">
                        {card.brand} ****{card.last4}
                      </p>
                      {card.isDefault && (
                        <span className="text-[10px] font-bold bg-yellow-400/20 text-yellow-400 border border-yellow-400/40 px-1.5 py-0.2 rounded-md">
                          Default
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Expires {card.expMonth}/{card.expYear} {card.gateway}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-black stroke-[3]" />
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm('Supprimer cette carte enregistrée ?')) {
                          vtcStore.removeSavedCard(card.id);
                        }
                      }}
                      className="p-1 text-neutral-500 hover:text-rose-400 transition"
                      title="Supprimer la carte"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Add Card Modal */}
      {showAddCard && (
        <div className="fixed inset-0 z-[1300] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm">
          <form 
            onSubmit={handleAddCardSubmit}
            className="bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4 animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between pb-2 border-b border-neutral-900">
              <h3 className="font-bold text-base text-white">Ajouter une carte</h3>
              <button
                type="button"
                onClick={() => setShowAddCard(false)}
                className="w-8 h-8 rounded-full bg-neutral-900 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs text-neutral-400 font-semibold block mb-1">Numéro de carte</label>
              <input
                type="text"
                placeholder="4242 •••• •••• 4242"
                required
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-neutral-400 font-semibold block mb-1">MM / AA</label>
                <input
                  type="text"
                  placeholder="12/30"
                  required
                  value={expDate}
                  onChange={(e) => setExpDate(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400"
                />
              </div>
              <div>
                <label className="text-xs text-neutral-400 font-semibold block mb-1">CVC</label>
                <input
                  type="password"
                  placeholder="123"
                  maxLength={4}
                  required
                  value={cvc}
                  onChange={(e) => setCvc(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black rounded-2xl transition active:scale-98 text-sm shadow-xl shadow-yellow-400/10 mt-2"
            >
              Enregistrer la carte sécurisée
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
