import React, { useState } from 'react';
import { ArrowLeft, Tag, CheckCircle2, Sparkles } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface PromotionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PromotionsModal: React.FC<PromotionsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [promoInput, setPromoInput] = useState('');
  const [activePromos, setActivePromos] = useState<Array<{ code: string; title: string; discount: number; desc: string }>>([
    {
      code: 'SOMEDVIP',
      title: 'SOMED VIP Prestige',
      discount: 20,
      desc: '20% de réduction immédiate sur votre prochain trajet Berline & Confort',
    }
  ]);
  const [feedback, setFeedback] = useState<{ message: string; success: boolean } | null>(null);

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;

    const res = vtcStore.applyPromoCode(promoInput);
    if (res.success) {
      if (!activePromos.some(p => p.code === promoInput.trim().toUpperCase())) {
        setActivePromos([
          ...activePromos,
          {
            code: promoInput.trim().toUpperCase(),
            title: `Promotion ${promoInput.trim().toUpperCase()}`,
            discount: res.discountPercent,
            desc: res.message,
          }
        ]);
      }
      setFeedback({ message: res.message, success: true });
      setPromoInput('');
    } else {
      setFeedback({ message: res.message, success: false });
    }
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Top Header (Screenshot 9) */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">Promotions</h2>
        <div className="w-9" />
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6 max-w-md mx-auto w-full">
        {/* Have a code? Card (Screenshot 9) */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-3xl p-5 space-y-3 shadow-md">
          <h3 className="font-bold text-sm text-white">Have a code?</h3>
          <p className="text-xs text-neutral-400">Enter a promo code or referral code</p>

          <form onSubmit={handleApply} className="flex gap-2 pt-1">
            <input
              type="text"
              placeholder="Enter your code"
              value={promoInput}
              onChange={(e) => {
                setPromoInput(e.target.value);
                setFeedback(null);
              }}
              className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white uppercase placeholder-neutral-500 focus:outline-none focus:border-yellow-400 font-mono tracking-wider"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs rounded-xl shadow-md transition active:scale-98"
            >
              Apply
            </button>
          </form>

          {feedback && (
            <p className={`text-xs font-semibold ${feedback.success ? 'text-emerald-400' : 'text-rose-400'}`}>
              {feedback.message}
            </p>
          )}

          {/* Quick Suggestions */}
          <div className="flex items-center gap-2 pt-1">
            <span className="text-[10px] text-neutral-500 font-medium">Codes d'essai :</span>
            <button
              type="button"
              onClick={() => setPromoInput('SOMEDVIP')}
              className="text-[10px] bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border border-neutral-800 px-2 py-0.5 rounded font-mono"
            >
              SOMEDVIP (-20%)
            </button>
            <button
              type="button"
              onClick={() => setPromoInput('WELCOME10')}
              className="text-[10px] bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border border-neutral-800 px-2 py-0.5 rounded font-mono"
            >
              WELCOME10 (-10%)
            </button>
          </div>
        </div>

        {/* Active promotions (Screenshot 9) */}
        <div className="space-y-3">
          <h3 className="font-bold text-sm text-white">Active promotions</h3>

          {activePromos.length === 0 ? (
            <div className="bg-neutral-950 border border-neutral-900 rounded-3xl p-8 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-neutral-900 flex items-center justify-center text-neutral-500">
                <Tag className="w-7 h-7 stroke-[1.5]" />
              </div>
              <p className="text-sm font-semibold text-white">No active promotions</p>
              <p className="text-xs text-neutral-500">
                Enter a promo code to get discounts
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {activePromos.map((p) => (
                <div
                  key={p.code}
                  className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 flex items-center justify-between shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-yellow-400/20 text-yellow-400 border border-yellow-400/30 flex items-center justify-center font-bold">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm text-white">{p.code}</p>
                        <span className="text-[10px] font-bold bg-yellow-400 text-black px-1.5 py-0.2 rounded">
                          -{p.discount}%
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 mt-0.5">{p.desc}</p>
                    </div>
                  </div>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
