import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Briefcase, 
  Clock, 
  Plus, 
  MoreVertical, 
  X, 
  MapPin, 
  Trash2 
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { SavedLocationItem } from '../../types/vtc';

interface SavedLocationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLocation?: (loc: { name: string; address: string; lat: number; lng: number }) => void;
}

export const SavedLocationsModal: React.FC<SavedLocationsModalProps> = ({
  isOpen,
  onClose,
  onSelectLocation,
}) => {
  if (!isOpen) return null;

  const passenger = vtcStore.getPassenger();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newAddress, setNewAddress] = useState('');

  const favorites = passenger.savedLocations.filter(l => l.type === 'FAVORITE');
  const recents = passenger.savedLocations.filter(l => l.type === 'RECENT');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newAddress) return;
    vtcStore.addSavedLocation({
      title: newTitle,
      address: newAddress,
      lat: 31.6295 + (Math.random() - 0.5) * 0.05,
      lng: -7.9811 + (Math.random() - 0.5) * 0.05,
      type: 'FAVORITE',
      iconType: 'work',
    });
    setNewTitle('');
    setNewAddress('');
    setShowAddModal(false);
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Top Header (Screenshot 6) */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">Saved locations</h2>
        <div className="w-9" />
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6 max-w-md mx-auto w-full">
        {/* Favorite locations section */}
        {favorites.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-neutral-400">Favorite locations</h3>

            <div className="space-y-2">
              {favorites.map((fav) => (
                <div
                  key={fav.id}
                  onClick={() => {
                    if (onSelectLocation) {
                      onSelectLocation({ name: fav.title, address: fav.address, lat: fav.lat, lng: fav.lng });
                      onClose();
                    }
                  }}
                  className="bg-neutral-950 p-4 rounded-2xl border border-neutral-900 hover:border-neutral-800 transition cursor-pointer flex items-center gap-3.5 group"
                >
                  <div className="w-11 h-11 rounded-xl bg-blue-950/70 border border-blue-800/60 flex items-center justify-center text-blue-400 flex-shrink-0">
                    <Briefcase className="w-5 h-5 stroke-[1.8]" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm text-white truncate leading-tight group-hover:text-yellow-400 transition">
                      {fav.title}
                    </p>
                    <p className="text-xs text-neutral-400 truncate mt-0.5">{fav.address}</p>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      vtcStore.removeSavedLocation(fav.id);
                    }}
                    className="p-1.5 text-neutral-500 hover:text-rose-400 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent locations section (Screenshot 6) */}
        <div className="space-y-3">
          <h3 className="text-xs font-semibold text-neutral-400">Recent locations</h3>

          <div className="space-y-2">
            {recents.map((loc) => (
              <div
                key={loc.id}
                onClick={() => {
                  if (onSelectLocation) {
                    onSelectLocation({ name: loc.title, address: loc.address, lat: loc.lat, lng: loc.lng });
                    onClose();
                  }
                }}
                className="bg-neutral-950 p-4 rounded-2xl border border-neutral-900 hover:border-neutral-800 transition cursor-pointer flex items-center gap-3.5 group"
              >
                <div className="w-11 h-11 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 flex-shrink-0">
                  <Clock className="w-5 h-5 stroke-[1.8]" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm text-white truncate leading-tight group-hover:text-yellow-400 transition">
                    {loc.title}
                  </p>
                  <p className="text-xs text-neutral-400 truncate mt-0.5">{loc.address}</p>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    vtcStore.removeSavedLocation(loc.id);
                  }}
                  className="p-1.5 text-neutral-500 hover:text-rose-400 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Yellow + Add location Button (Screenshot 6) */}
        <div className="pt-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="w-full py-3.5 px-4 rounded-2xl border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 font-bold text-sm flex items-center justify-center gap-2 transition active:scale-98 shadow-lg shadow-yellow-400/5"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add location</span>
          </button>
        </div>
      </div>

      {/* Add Location Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[1300] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm">
          <form
            onSubmit={handleAddSubmit}
            className="bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4 animate-in slide-in-from-bottom duration-200"
          >
            <div className="flex items-center justify-between pb-2 border-b border-neutral-900">
              <h3 className="font-bold text-base text-white">Ajouter un lieu</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full bg-neutral-900 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs text-neutral-400 font-semibold block mb-1">Nom du lieu</label>
              <input
                type="text"
                placeholder="Ex: Bureau, Maison, Salle de sport..."
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="text-xs text-neutral-400 font-semibold block mb-1">Adresse complète</label>
              <input
                type="text"
                placeholder="Ex: 18 Avenue Idrissides, Marrakech..."
                required
                value={newAddress}
                onChange={(e) => setNewAddress(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-yellow-400"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black rounded-2xl transition active:scale-98 text-sm shadow-xl shadow-yellow-400/10 mt-2"
            >
              Enregistrer l'adresse
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
