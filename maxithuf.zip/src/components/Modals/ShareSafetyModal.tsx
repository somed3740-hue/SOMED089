import React, { useState } from 'react';
import { Shield, Share2, Copy, Check, AlertOctagon, PhoneCall, X, MapPin } from 'lucide-react';
import { Ride } from '../../types/vtc';

interface ShareSafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
  ride: Ride;
}

export const ShareSafetyModal: React.FC<ShareSafetyModalProps> = ({
  isOpen,
  onClose,
  ride,
}) => {
  const [copied, setCopied] = useState(false);
  const [sosSent, setSosSent] = useState(false);

  if (!isOpen) return null;

  const shareUrl = `${window.location.origin}/track?ride=${ride.id}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTriggerSOS = () => {
    setSosSent(true);
  };

  return (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">Centre de Sécurité & Partage</h3>
              <p className="text-[11px] text-slate-400">Trajet sécurisé et suivi en direct</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Share live tracking link */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
            <Share2 className="w-4 h-4 text-blue-400" />
            <span>Partager le suivi en direct avec vos proches</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Vos proches pourront voir la position du véhicule en temps réel, l'immatriculation et l'heure d'arrivée estimée.
          </p>

          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl p-2">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="bg-transparent text-xs text-slate-300 flex-1 outline-none px-2 font-mono truncate"
            />
            <button
              onClick={handleCopyLink}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copié !' : 'Copier'}</span>
            </button>
          </div>
        </div>

        {/* Live Vehicle Identity Proof */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3.5 text-xs space-y-2">
          <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Informations officielles de sécurité</p>
          <div className="grid grid-cols-2 gap-2 text-slate-300">
            <div>
              <span className="text-slate-500 block text-[10px]">Chauffeur</span>
              <strong className="text-white">{ride.driverName || 'Partenaire SOMED'}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Plaque d'immatriculation</span>
              <strong className="text-blue-400 font-mono">{ride.vehiclePlate || 'FX-892-WP'}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Véhicule</span>
              <span>{ride.vehicleModel || 'Standard'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Code PIN Course</span>
              <span className="font-mono text-emerald-400 font-bold">{ride.id.slice(-4)}</span>
            </div>
          </div>
        </div>

        {/* Emergency SOS Assistance */}
        <div className="bg-rose-950/20 border border-rose-900/40 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
              <AlertOctagon className="w-4 h-4" />
              <span>Assistance d'Urgence 24/7</span>
            </div>
            <span className="text-[10px] text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded-full font-semibold">
              Appel 112
            </span>
          </div>

          <p className="text-[11px] text-slate-400">
            En cas de danger immédiat ou de situation suspecte, contactez instantanément les services de secours avec transmission de vos coordonnées GPS.
          </p>

          {!sosSent ? (
            <div className="flex gap-2">
              <a
                href="tel:112"
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition shadow-lg shadow-rose-600/30"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Appeler le 112</span>
              </a>
              <button
                onClick={handleTriggerSOS}
                className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-rose-400 border border-rose-800/40 rounded-xl text-xs font-semibold transition"
              >
                Alerter le support SOMED
              </button>
            </div>
          ) : (
            <div className="bg-rose-500/20 text-rose-200 p-2.5 rounded-xl text-xs text-center border border-rose-500/40">
              Alerte d'urgence transmise à notre centre de sécurité. Un agent prend en charge votre dossier.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
