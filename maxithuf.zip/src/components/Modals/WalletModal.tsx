import React, { useState } from 'react';
import { 
  ArrowLeft, 
  RotateCw, 
  Wallet, 
  Receipt, 
  Plus, 
  CheckCircle2, 
  X,
  CreditCard,
  ArrowUpRight
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [showTopUpSheet, setShowTopUpSheet] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState<number>(20);
  const [isProcessing, setIsProcessing] = useState(false);

  const passenger = vtcStore.getPassenger();
  const transactions = passenger.walletTransactions || [];

  const handleConfirmTopUp = () => {
    setIsProcessing(true);
    setTimeout(() => {
      vtcStore.topUpWallet(topUpAmount, 'Rechargement Carte Visa ****4242');
      setIsProcessing(false);
      setShowTopUpSheet(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-[1250] flex flex-col bg-black text-white select-none animate-in fade-in duration-200">
      {/* Top Header (Screenshot 1) */}
      <header className="px-5 py-4 border-b border-neutral-900 flex items-center justify-between flex-shrink-0 bg-black">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base text-white">My wallet</h2>
        <button
          onClick={() => {}}
          className="w-9 h-9 rounded-full bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition active:scale-95"
        >
          <RotateCw className="w-4 h-4" />
        </button>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6 max-w-md mx-auto w-full">
        {/* Big Yellow Available Balance Card (Screenshot 1) */}
        <div className="w-full bg-yellow-400 rounded-3xl p-6 text-black shadow-xl shadow-yellow-400/10 space-y-4">
          <div className="flex items-center gap-2 text-neutral-800 text-xs font-bold">
            <Wallet className="w-4 h-4" />
            <span>Available balance</span>
          </div>

          <div className="text-4xl font-black tracking-tight">
            {passenger.walletBalance.toFixed(2)} EUR
          </div>

          <button
            onClick={() => setShowTopUpSheet(true)}
            className="w-full py-3.5 px-4 bg-white hover:bg-neutral-100 text-yellow-500 font-black rounded-2xl shadow-md transition active:scale-98 text-sm"
          >
            Top up wallet
          </button>
        </div>

        {/* Top-up requests (Screenshot 1) */}
        <div className="space-y-2">
          <h3 className="font-bold text-sm text-white">Top-up requests</h3>
          <p className="text-xs text-neutral-400">
            You don't have top-up requests yet.
          </p>
        </div>

        {/* Recent transactions (Screenshot 1) */}
        <div className="space-y-3 pt-2">
          <h3 className="font-bold text-sm text-white">Recent transactions</h3>

          {transactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-neutral-900 flex items-center justify-center text-neutral-500">
                <Receipt className="w-8 h-8 stroke-[1.5]" />
              </div>
              <p className="text-xs text-neutral-400 font-medium">No transactions</p>
            </div>
          ) : (
            <div className="space-y-2">
              {transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                      <ArrowUpRight className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-xs text-white leading-tight">{tx.description}</p>
                      <p className="text-[11px] text-neutral-500 mt-0.5">{tx.date}</p>
                    </div>
                  </div>
                  <span className="font-bold text-sm text-emerald-400">
                    +{tx.amount.toFixed(2)} €
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Top up Dialog / Sheet */}
      {showTopUpSheet && (
        <div className="fixed inset-0 z-[1300] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-5 animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-900">
              <h3 className="font-bold text-base text-white">Recharger votre solde</h3>
              <button
                onClick={() => setShowTopUpSheet(false)}
                className="w-8 h-8 rounded-full bg-neutral-900 text-neutral-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[10, 20, 50, 100].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setTopUpAmount(amt)}
                  className={`py-2.5 rounded-xl font-bold text-xs border transition ${
                    topUpAmount === amt
                      ? 'bg-yellow-400 text-black border-yellow-400 shadow-md'
                      : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  +{amt}€
                </button>
              ))}
            </div>

            <div className="bg-neutral-900/60 p-3.5 rounded-2xl border border-neutral-800 flex items-center gap-3">
              <CreditCard className="w-5 h-5 text-yellow-400" />
              <div className="text-xs">
                <p className="font-bold text-white">VISA ****4242</p>
                <p className="text-[11px] text-neutral-400">Paiement sécurisé via Stripe</p>
              </div>
            </div>

            <button
              onClick={handleConfirmTopUp}
              disabled={isProcessing}
              className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black rounded-2xl transition active:scale-98 text-sm shadow-xl shadow-yellow-400/10 flex items-center justify-center gap-2"
            >
              {isProcessing ? 'Traitement en cours...' : `Confirmer le rechargement de ${topUpAmount} EUR`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
