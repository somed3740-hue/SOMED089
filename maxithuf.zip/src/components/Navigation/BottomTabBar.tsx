import React from 'react';
import { Car, Bike, Clock, User } from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { useTranslation } from '../../utils/i18n';

interface BottomTabBarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({
  currentTab,
  onSelectTab,
}) => {
  const isLight = vtcStore.isLightMode();
  const { t } = useTranslation();

  const tabs = [
    { id: 'taxi', label: t('tabTaxi'), icon: Car },
    { id: 'delivery', label: t('tabDelivery'), icon: Bike },
    { id: 'activity', label: t('tabActivity'), icon: Clock },
    { id: 'profile', label: t('tabProfile'), icon: User },
  ];

  return (
    <nav className={`h-16 border-t px-6 flex items-center justify-around flex-shrink-0 z-30 select-none shadow-2xl transition-colors ${
      isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-black border-neutral-900 text-neutral-400'
    }`}>
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className="flex flex-col items-center justify-center gap-1 py-1 px-3 relative transition active:scale-95 group"
          >
            {isActive ? (
              <div className="w-12 h-7 rounded-full bg-yellow-400 flex items-center justify-center transition-all shadow-md shadow-yellow-400/20">
                <Icon className="w-4 h-4 text-black stroke-[2.5]" />
              </div>
            ) : (
              <div className={`w-12 h-7 flex items-center justify-center transition ${
                isLight ? 'text-slate-500 group-hover:text-black' : 'text-neutral-400 group-hover:text-white'
              }`}>
                <Icon className="w-5 h-5 stroke-[1.8]" />
              </div>
            )}
            <span
              className={`text-[10px] font-semibold transition ${
                isActive 
                  ? 'text-yellow-500 font-bold' 
                  : isLight ? 'text-slate-500 group-hover:text-black' : 'text-neutral-400 group-hover:text-neutral-200'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
