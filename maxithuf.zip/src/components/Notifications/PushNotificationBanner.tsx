import React, { useEffect, useState, useRef } from 'react';
import { 
  X, 
  Car, 
  Package, 
  Store, 
  Wallet, 
  Bell, 
  ShieldCheck, 
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { AppNotification, NotificationAction } from '../../types/vtc';

interface PushNotificationBannerProps {
  onActionClick?: (action: NotificationAction, notification: AppNotification) => void;
  onOpenNotifications?: () => void;
}

export const PushNotificationBanner: React.FC<PushNotificationBannerProps> = ({
  onActionClick,
  onOpenNotifications,
}) => {
  const [notification, setNotification] = useState<AppNotification | null>(null);
  const [isExiting, setIsExiting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(100);
  const isLight = vtcStore.isLightMode();

  const dragStartY = useRef<number | null>(null);
  const currentDragOffset = useRef<number>(0);
  const [dragOffset, setDragOffset] = useState(0);

  useEffect(() => {
    const update = () => {
      const active = vtcStore.getActivePushNotification();
      if (active && (!notification || notification.id !== active.id)) {
        setNotification(active);
        setIsExiting(false);
        setProgress(100);
        setDragOffset(0);
      } else if (!active && notification) {
        setIsExiting(true);
        const timer = setTimeout(() => {
          setNotification(null);
          setIsExiting(false);
        }, 320);
        return () => clearTimeout(timer);
      }
    };

    update();
    const unsubscribe = vtcStore.subscribe(update);
    return () => unsubscribe();
  }, [notification]);

  // Countdown timer for progress bar (pauses on hover)
  useEffect(() => {
    if (!notification || isExiting || isPaused) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleDismiss();
          return 0;
        }
        return prev - 1.6; // ~6.2s total
      });
    }, 100);

    return () => clearInterval(interval);
  }, [notification, isExiting, isPaused]);

  const handleDismiss = () => {
    setIsExiting(true);
    setTimeout(() => {
      vtcStore.dismissActivePushNotification();
      setNotification(null);
      setIsExiting(false);
      setDragOffset(0);
    }, 280);
  };

  const handleTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    dragStartY.current = clientY;
    setIsPaused(true);
  };

  const handleTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (dragStartY.current === null) return;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const diff = clientY - dragStartY.current;
    // Only allow dragging upwards to dismiss
    if (diff < 0) {
      currentDragOffset.current = diff;
      setDragOffset(diff);
    }
  };

  const handleTouchEnd = () => {
    if (currentDragOffset.current < -40) {
      handleDismiss();
    } else {
      setDragOffset(0);
    }
    dragStartY.current = null;
    currentDragOffset.current = 0;
    setIsPaused(false);
  };

  if (!notification) return null;

  const getCategoryIcon = () => {
    switch (notification.category) {
      case 'RIDE':
        return <Car className="w-3.5 h-3.5 text-yellow-400" />;
      case 'DELIVERY':
        return <Package className="w-3.5 h-3.5 text-emerald-400" />;
      case 'BUSINESS':
        return <Store className="w-3.5 h-3.5 text-sky-400" />;
      case 'PAYMENT':
        return <Wallet className="w-3.5 h-3.5 text-amber-400" />;
      case 'SECURITY':
        return <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />;
      default:
        return <Bell className="w-3.5 h-3.5 text-yellow-400" />;
    }
  };

  const getCategoryLabel = () => {
    switch (notification.category) {
      case 'RIDE':
        return 'SOMED · Course VTC';
      case 'DELIVERY':
        return 'SOMED · Livraison';
      case 'BUSINESS':
        return 'SOMED · Business';
      case 'PAYMENT':
        return 'SOMED · Paiement';
      case 'SECURITY':
        return 'SOMED · Sécurité';
      default:
        return 'SOMED · Notification';
    }
  };

  return (
    <div 
      className="fixed top-3 left-0 right-0 z-[2500] flex justify-center px-3 pointer-events-none select-none"
      style={{
        transform: `translateY(${dragOffset}px)`,
        transition: dragStartY.current ? 'none' : 'transform 0.25s ease-out'
      }}
    >
      <div
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleTouchStart}
        onMouseMove={handleTouchMove}
        onMouseUp={handleTouchEnd}
        className={`pointer-events-auto w-full max-w-md rounded-2xl p-3.5 shadow-2xl backdrop-blur-xl border transition-all duration-300 ease-out cursor-pointer ${
          isExiting 
            ? '-translate-y-24 opacity-0 scale-95' 
            : 'translate-y-0 opacity-100 scale-100 animate-in slide-in-from-top-6 duration-300'
        } ${
          isLight
            ? 'bg-white/95 border-slate-200/90 text-slate-900 shadow-slate-900/15'
            : 'bg-neutral-900/95 border-neutral-700/80 text-white shadow-black/80 ring-1 ring-yellow-400/20'
        }`}
        style={{
          boxShadow: isLight 
            ? '0 20px 35px -10px rgba(0, 0, 0, 0.18), 0 0 0 1px rgba(0,0,0,0.06)' 
            : '0 20px 40px -10px rgba(0, 0, 0, 0.8), 0 0 20px rgba(254, 216, 0, 0.12)'
        }}
        onClick={(e) => {
          // If clicked outside buttons, open notifications center
          if ((e.target as HTMLElement).tagName !== 'BUTTON') {
            if (onOpenNotifications) {
              onOpenNotifications();
              handleDismiss();
            }
          }
        }}
      >
        {/* Drag/Swipe Indicator Handle */}
        <div className="w-10 h-1 rounded-full bg-neutral-500/40 mx-auto -mt-1 mb-2 hover:bg-neutral-400/60" />

        {/* Header bar */}
        <div className="flex items-center justify-between gap-2 pb-1.5 border-b border-neutral-500/20">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded-lg overflow-hidden bg-[#EAF37B] p-0.5 flex-shrink-0 flex items-center justify-center shadow-sm">
              <img 
                src="/somed-logo.png" 
                alt="SOMED" 
                className="w-full h-full object-cover" 
              />
            </div>

            <div className="flex items-center gap-1.5 min-w-0">
              <span className={`text-[11px] font-black tracking-wide truncate ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                {getCategoryLabel()}
              </span>
              <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-neutral-400'}`}>
                ·
              </span>
              <span className={`text-[10px] font-medium ${isLight ? 'text-slate-400' : 'text-neutral-400'}`}>
                À l'instant
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1 flex-shrink-0">
            {notification.badge && (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-yellow-400/20 text-yellow-400 border border-yellow-400/40">
                {notification.badge}
              </span>
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleDismiss();
              }}
              className={`w-6 h-6 rounded-full flex items-center justify-center transition ${
                isLight 
                  ? 'hover:bg-slate-200 text-slate-500' 
                  : 'hover:bg-neutral-800 text-neutral-400 hover:text-white'
              }`}
              title="Fermer la notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="mt-2 flex items-start gap-2.5">
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 ${
            isLight ? 'bg-slate-100' : 'bg-neutral-800 border border-neutral-700/60'
          }`}>
            {getCategoryIcon()}
          </div>

          <div className="flex-1 min-w-0 pr-1">
            <h4 className={`text-xs font-bold leading-snug line-clamp-1 ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}>
              {notification.title}
            </h4>
            <p className={`text-[11px] mt-0.5 leading-relaxed line-clamp-2 ${
              isLight ? 'text-slate-600' : 'text-neutral-300'
            }`}>
              {notification.body}
            </p>
          </div>
        </div>

        {/* Optional Action Buttons */}
        {notification.actions && notification.actions.length > 0 && (
          <div className="mt-2.5 pt-2 border-t border-neutral-500/20 flex items-center gap-2">
            {notification.actions.map((act) => (
              <button
                key={act.id}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onActionClick) {
                    onActionClick(act, notification);
                  }
                  handleDismiss();
                }}
                className={`flex-1 py-1.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 active:scale-95 ${
                  act.variant === 'primary' || !act.variant
                    ? 'bg-yellow-400 hover:bg-yellow-300 text-black shadow-sm font-black'
                    : isLight
                    ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                }`}
              >
                <span>{act.label}</span>
                <ChevronRight className="w-3 h-3 stroke-[2.5]" />
              </button>
            ))}
          </div>
        )}

        {/* Auto-dismiss countdown bar at bottom */}
        <div className="w-full h-1 bg-neutral-500/20 rounded-full mt-2.5 overflow-hidden">
          <div 
            className="h-full bg-yellow-400 transition-all duration-100 ease-linear rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
};
