import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Settings, 
  Camera, 
  User, 
  CreditCard, 
  Wallet, 
  MapPin, 
  Clock, 
  ChevronRight, 
  Bell, 
  Globe, 
  Sun, 
  Moon, 
  Smartphone, 
  RefreshCw, 
  FileText, 
  ShieldCheck, 
  LogOut,
  Star,
  Check
} from 'lucide-react';
import { vtcStore } from '../../services/vtcStore';
import { LegalModal } from '../Modals/LegalModal';
import { LanguageModal } from '../Modals/LanguageModal';
import { useTranslation, SUPPORTED_LANGUAGES, Language } from '../../utils/i18n';
import { soundEffects } from '../../utils/audio';

interface ProfileViewProps {
  onBack: () => void;
  onOpenEditProfile: () => void;
  onOpenPaymentMethods: () => void;
  onOpenWallet: () => void;
  onOpenSavedLocations: () => void;
  onOpenTripHistory: () => void;
  onOpenReceipts?: () => void;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
  onSwitchMode: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onBack,
  onOpenEditProfile,
  onOpenPaymentMethods,
  onOpenWallet,
  onOpenSavedLocations,
  onOpenTripHistory,
  onOpenReceipts,
  onOpenNotifications,
  onOpenSettings,
  onSwitchMode,
}) => {
  const isLight = vtcStore.isLightMode();
  const passenger = vtcStore.getPassenger();
  const { lang, t, setLanguage } = useTranslation();
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [legalModal, setLegalModal] = useState<{ isOpen: boolean; type: 'terms' | 'privacy' }>({
    isOpen: false,
    type: 'terms'
  });

  const handleAppearanceChange = (mode: 'light' | 'dark' | 'auto') => {
    vtcStore.setAppearance(mode);
  };

  const handleSelectLanguage = (code: Language) => {
    soundEffects.playClick();
    setLanguage(code);

    const labels: Record<Language, string> = {
      fr: 'Français activé pour toute l’application',
      en: 'English activated across all interfaces',
      es: 'Español activado en todas las interfaces',
    };

    vtcStore.sendPushNotification({
      title: t('language'),
      body: labels[code],
      category: 'SYSTEM',
      badge: code.toUpperCase(),
    });
  };

  return (
    <div className={`h-full w-full flex flex-col overflow-y-auto select-none transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-black text-white'
    }`}>
      {/* Top Header */}
      <header className={`px-5 py-4 border-b flex items-center justify-between sticky top-0 backdrop-blur-md z-20 ${
        isLight ? 'border-slate-200 bg-white/95' : 'border-neutral-900 bg-black/95'
      }`}>
        <button
          onClick={onBack}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
            isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
          }`}
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-base">{t('profileTitle')}</h2>
        <button
          onClick={onOpenSettings}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 ${
            isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300'
          }`}
        >
          <Settings className="w-5 h-5" />
        </button>
      </header>

      {/* Profile Header Details */}
      <div className={`p-6 flex flex-col items-center border-b ${
        isLight ? 'border-slate-200 bg-white/70' : 'border-neutral-900 bg-neutral-950/40'
      }`}>
        <div className="relative mb-3 group cursor-pointer" onClick={onOpenEditProfile}>
          <div className="w-24 h-24 rounded-full bg-neutral-900 border-2 border-yellow-400 p-0.5 overflow-hidden flex items-center justify-center shadow-xl">
            <img
              src={passenger.avatarUrl}
              alt={passenger.name}
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <button 
            className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-yellow-400 text-black flex items-center justify-center shadow-lg border-2 border-black hover:scale-105 transition"
            title={t('editProfile')}
          >
            <Camera className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        <h1 className="font-bold text-xl tracking-tight">{passenger.name}</h1>
        <p className={`text-xs mt-0.5 font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
          {passenger.phone}
        </p>

        {/* 3 Stats Cards */}
        <div className={`grid grid-cols-3 gap-3 w-full max-w-sm mt-5 p-3 rounded-2xl border text-center ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900/60 border-neutral-800/80'
        }`}>
          <div>
            <p className="text-base font-bold">{passenger.tripsCount}</p>
            <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('tabTaxi')}</p>
          </div>
          <div className={`border-x ${isLight ? 'border-slate-200' : 'border-neutral-800'}`}>
            <p className="text-base font-bold text-yellow-500 flex items-center justify-center gap-1">
              <Star className="w-3.5 h-3.5 fill-yellow-400" />
              <span>{passenger.rating.toFixed(1)}</span>
            </p>
            <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('driverRating')}</p>
          </div>
          <div>
            <p className="text-base font-bold">{passenger.memberSince}</p>
            <p className={`text-[11px] font-medium ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{t('memberSince')}</p>
          </div>
        </div>
      </div>

      {/* Account Section List */}
      <div className="px-5 py-4 space-y-4">
        <div>
          <h3 className={`text-xs font-semibold mb-2 px-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            {t('accountSection')}
          </h3>
          <div className={`rounded-2xl border divide-y overflow-hidden ${
            isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
          }`}>
            <button
              onClick={onOpenEditProfile}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <User className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">{t('editProfile')}</span>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            <button
              onClick={onOpenPaymentMethods}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <CreditCard className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">{t('drawerPaymentMethods')}</span>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            <button
              onClick={onOpenWallet}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-sm font-medium">{t('drawerWallet')}</span>
                  <p className="text-[11px] text-yellow-500 font-bold">{passenger.walletBalance.toFixed(2)} EUR</p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            <button
              onClick={onOpenSavedLocations}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <MapPin className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">{t('drawerSavedPlaces')}</span>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Historique des courses */}
            <button
              onClick={onOpenTripHistory}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <Clock className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">{t('drawerActivity')}</span>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>
          </div>
        </div>

        {/* ================= SECTION LANGUE DE L'APPLICATION (Français, Anglais, Espagnol) ================= */}
        <div>
          <h3 className={`text-xs font-semibold mb-2 px-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            {t('language')}
          </h3>
          <div className={`p-4 rounded-2xl border space-y-3 ${
            isLight ? 'bg-white border-slate-200' : 'bg-neutral-950 border-neutral-900'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-yellow-400/20 text-yellow-500 flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold">{t('language')}</h4>
                  <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    {t('languageSubtitle')}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400 text-black uppercase">
                {lang}
              </span>
            </div>

            {/* 3 Selectable Buttons: Français, English, Español */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              {SUPPORTED_LANGUAGES.map((item) => {
                const isSelected = lang === item.code;
                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => handleSelectLanguage(item.code)}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition active:scale-95 ${
                      isSelected
                        ? 'bg-yellow-400 border-yellow-400 text-black font-extrabold shadow-md shadow-yellow-400/20 ring-2 ring-yellow-400/40'
                        : isLight 
                        ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300' 
                        : 'bg-neutral-900/80 border-neutral-800 text-neutral-300 hover:bg-neutral-900 hover:text-white'
                    }`}
                  >
                    <span className="text-xl">{item.flag}</span>
                    <span className="text-xs font-bold">{item.name}</span>
                    {isSelected && (
                      <span className="text-[9px] bg-black text-yellow-400 px-1.5 py-0.2 rounded-full font-black flex items-center gap-0.5">
                        <Check className="w-2.5 h-2.5" /> {t('active')}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* General & Preferences Section */}
        <div>
          <h3 className={`text-xs font-semibold mb-2 px-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            {t('preferencesSection')}
          </h3>
          <div className={`rounded-2xl border divide-y overflow-hidden ${
            isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
          }`}>
            <button
              onClick={onOpenNotifications}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <Bell className="w-4 h-4" />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{t('notifications')}</span>
                  {vtcStore.getUnreadNotificationsCount() > 0 && (
                    <span className="bg-yellow-400 text-black text-[10px] font-black px-1.5 py-0.2 rounded-full">
                      {vtcStore.getUnreadNotificationsCount()}
                    </span>
                  )}
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            {/* Appearance Segmented Control */}
            <div className="p-4 space-y-2.5">
              <span className={`text-xs font-semibold ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                {t('appearance')}
              </span>
              <div className={`grid grid-cols-3 gap-2 p-1.5 rounded-xl border ${
                isLight ? 'bg-slate-100 border-slate-200' : 'bg-neutral-900/80 border-neutral-800'
              }`}>
                <button
                  onClick={() => handleAppearanceChange('light')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    passenger.appearance === 'light'
                      ? 'bg-yellow-400 text-black shadow-md'
                      : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                  <span>{t('light')}</span>
                </button>

                <button
                  onClick={() => handleAppearanceChange('dark')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    passenger.appearance === 'dark'
                      ? 'bg-yellow-400 text-black shadow-md'
                      : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>{t('dark')}</span>
                </button>

                <button
                  onClick={() => handleAppearanceChange('auto')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    passenger.appearance === 'auto'
                      ? 'bg-yellow-400 text-black shadow-md'
                      : isLight ? 'text-slate-600 hover:text-black' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>{t('auto')}</span>
                </button>
              </div>
            </div>

            {/* Switch mode */}
            <button
              onClick={onSwitchMode}
              className={`w-full p-4 flex items-center justify-between transition group text-left ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-slate-100 text-slate-600' : 'bg-neutral-900 text-neutral-400'
                } group-hover:text-yellow-500`}>
                  <RefreshCw className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-sm font-medium">{t('switchInterface')}</span>
                  <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    Passager, Chauffeur, Business
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>
          </div>
        </div>

        {/* Legal Section */}
        <div>
          <h3 className={`text-xs font-semibold mb-2 px-1 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
            {t('legalTerms')}
          </h3>
          <div className={`rounded-2xl border divide-y overflow-hidden ${
            isLight ? 'bg-white border-slate-200 divide-slate-100' : 'bg-neutral-950 border-neutral-900 divide-neutral-900'
          }`}>
            <button
              onClick={() => setLegalModal({ isOpen: true, type: 'terms' })}
              className={`w-full p-4 flex items-center justify-between cursor-pointer transition text-left group ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-yellow-50 text-yellow-600' : 'bg-yellow-400/10 text-yellow-400'
                } group-hover:scale-105 transition`}>
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-sm font-medium block">{t('legalTerms')}</span>
                  <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                    Conditions officielles (14 sections)
                  </span>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 transition group-hover:translate-x-0.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>

            <button
              onClick={() => setLegalModal({ isOpen: true, type: 'privacy' })}
              className={`w-full p-4 flex items-center justify-between cursor-pointer transition text-left group ${
                isLight ? 'hover:bg-slate-50' : 'hover:bg-neutral-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                  isLight ? 'bg-emerald-50 text-emerald-600' : 'bg-emerald-400/10 text-emerald-400'
                } group-hover:scale-105 transition`}>
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-sm font-medium block">{t('privacyPolicy')}</span>
                  <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                    Politique RGPD (15 sections)
                  </span>
                </div>
              </div>
              <ChevronRight className={`w-4 h-4 transition group-hover:translate-x-0.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
            </button>
          </div>
        </div>

        {/* Big Yellow Log Out Button */}
        <div className="pt-2 pb-6 space-y-3">
          <button
            onClick={() => {
              if (confirm('Voulez-vous vous déconnecter de votre session SOMED ?')) {
                onBack();
              }
            }}
            className="w-full py-3.5 px-4 rounded-2xl border-2 border-yellow-400 text-yellow-500 hover:bg-yellow-400/10 font-bold text-sm flex items-center justify-center gap-2 transition active:scale-98 shadow-lg shadow-yellow-400/5"
          >
            <LogOut className="w-4 h-4" />
            <span>{t('logout')}</span>
          </button>

          <p className={`text-[11px] text-center font-mono ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
            SOMED v1.0.2 (#3) — {t('appName')}
          </p>
        </div>
      </div>

      {/* Interactive Legal Modal */}
      <LegalModal
        isOpen={legalModal.isOpen}
        type={legalModal.type}
        onClose={() => setLegalModal(prev => ({ ...prev, isOpen: false }))}
      />

      {/* Language Selection Modal */}
      <LanguageModal
        isOpen={isLanguageModalOpen}
        onClose={() => setIsLanguageModalOpen(false)}
      />
    </div>
  );
};
