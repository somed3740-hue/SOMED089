import { CategoryInfo, LocationPoint, RideCategory } from '../types/vtc';

// Famous landmarks & hubs for realistic instant testing (France & Marrakech)
export const PRESET_LOCATIONS: LocationPoint[] = [
  {
    name: '18 avenue idrissides',
    address: '18 avenue idrissides, Ménara, Marrakech',
    lat: 31.6225,
    lng: -8.0125,
  },
  {
    name: 'Voiture Super Puissante',
    address: 'Voiture Super Puissante, Marrakech, Marruecos',
    lat: 31.6295,
    lng: -7.9811,
  },
  {
    name: 'Establishment la Maison du Savoir',
    address: 'Establishment la Maison du Savoir, Marrakech, Marruecos',
    lat: 31.6380,
    lng: -8.0050,
  },
  {
    name: 'Targa Gueliz',
    address: 'Targa Gueliz, Marrakech, Marruecos',
    lat: 31.6441,
    lng: -8.0315,
  },
  {
    name: 'Dr. Morsi Barakat Jamal',
    address: 'Dr. Morsi Barakat Jamal, Marrakech, Marruecos',
    lat: 31.6300,
    lng: -8.0100,
  },
  {
    name: 'Tour Eiffel',
    address: 'Champ de Mars, 5 Av. Anatole France, 75007 Paris',
    lat: 48.8584,
    lng: 2.2945,
  },
  {
    name: 'Champs-Élysées',
    address: 'Av. des Champs-Élysées, 75008 Paris',
    lat: 48.8698,
    lng: 2.3075,
  },
  {
    name: 'Musée du Louvre',
    address: 'Rue de Rivoli, 75001 Paris',
    lat: 48.8606,
    lng: 2.3376,
  },
  {
    name: 'Gare de Lyon',
    address: 'Pl. Louis Armand, 75012 Paris',
    lat: 48.8448,
    lng: 2.3735,
  },
  {
    name: 'Opéra Garnier',
    address: 'Pl. de l\'Opéra, 75009 Paris',
    lat: 48.8719,
    lng: 2.3316,
  },
  {
    name: 'La Défense',
    address: '1 Parvis de la Défense, 92800 Puteaux',
    lat: 48.8924,
    lng: 2.2361,
  },
  {
    name: 'Aéroport Paris-CDG (Terminal 2E)',
    address: '95700 Roissy-en-France',
    lat: 49.0042,
    lng: 2.5709,
  },
  {
    name: 'Aéroport Paris-Orly (Terminal 4)',
    address: '94390 Orly',
    lat: 48.7262,
    lng: 2.3652,
  },
  {
    name: 'Montmartre / Sacré-Cœur',
    address: '35 Rue du Chevalier de la Barre, 75018 Paris',
    lat: 48.8867,
    lng: 2.3431,
  },
  {
    name: 'Gare du Nord',
    address: '18 Rue de Dunkerque, 75010 Paris',
    lat: 48.8809,
    lng: 2.3553,
  },
];

export const CATEGORIES_CONFIG: Record<RideCategory, CategoryInfo> = {
  STANDARD: {
    id: 'STANDARD',
    name: 'Standard',
    tagline: 'Économique & rapide au quotidien',
    multiplier: 1.0,
    baseFare: 5.5,
    perKm: 1.45,
    perMin: 0.35,
    capacity: 4,
    exampleVehicle: 'Peugeot 508 / Toyota Corolla',
    etaMinutes: 3,
  },
  CONFORT: {
    id: 'CONFORT',
    name: 'Confort',
    tagline: 'Véhicules récents & chauffeurs top notés',
    multiplier: 1.25,
    baseFare: 8.0,
    perKm: 1.85,
    perMin: 0.45,
    capacity: 4,
    exampleVehicle: 'Tesla Model 3 / Lexus ES',
    etaMinutes: 4,
  },
  BERLINE: {
    id: 'BERLINE',
    name: 'Berline VIP',
    tagline: 'Expérience haut de gamme avec service premium',
    multiplier: 1.7,
    baseFare: 14.0,
    perKm: 2.6,
    perMin: 0.7,
    capacity: 3,
    exampleVehicle: 'Mercedes Classe E / BMW Série 5',
    etaMinutes: 6,
  },
  VAN: {
    id: 'VAN',
    name: 'Van 6 Places',
    tagline: 'Idéal pour groupes et bagages volumineux',
    multiplier: 1.9,
    baseFare: 16.0,
    perKm: 2.9,
    perMin: 0.75,
    capacity: 6,
    exampleVehicle: 'Mercedes Classe V',
    etaMinutes: 7,
  },
};

/**
 * Computes great circle distance using Haversine formula
 */
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.max(0.5, Math.round(d * 10) / 10);
}

/**
 * Calculates total route distance including optional intermediate stops
 */
export function calculateTotalRouteDistance(
  pickup: LocationPoint,
  destination: LocationPoint,
  stops: LocationPoint[] = []
): number {
  const allWaypoints = [pickup, ...stops, destination];
  let total = 0;
  for (let i = 0; i < allWaypoints.length - 1; i++) {
    total += calculateDistanceKm(
      allWaypoints[i].lat,
      allWaypoints[i].lng,
      allWaypoints[i + 1].lat,
      allWaypoints[i + 1].lng
    );
  }
  return Math.round(total * 10) / 10;
}

/**
 * Estimates duration in minutes given distance in km and Paris traffic coefficient
 */
export function estimateDurationMinutes(distanceKm: number, stopsCount: number = 0): number {
  const minutes = Math.round((distanceKm / 24) * 60) + 4 + stopsCount * 5;
  return Math.max(5, minutes);
}

/**
 * Calculates fare according to category and distance
 */
export function calculateFare(
  category: RideCategory,
  distanceKm: number,
  durationMin: number,
  surgeMultiplier: number = 1.0,
  stopsCount: number = 0
): number {
  const cfg = CATEGORIES_CONFIG[category];
  const stopSurcharge = stopsCount * 3.50; // 3.50€ per intermediate stop
  const raw = (cfg.baseFare + distanceKm * cfg.perKm + durationMin * cfg.perMin + stopSurcharge) * surgeMultiplier;
  return Math.round(Math.max(cfg.baseFare, raw) * 100) / 100;
}

/**
 * Generates an interpolated sequence of waypoints for realistic route rendering
 */
export function generateRoutePoints(
  startLat: number,
  startLng: number,
  endLat: number,
  endLng: number,
  steps: number = 25
): [number, number][] {
  const points: [number, number][] = [];
  
  const midLat = (startLat + endLat) / 2;
  const midLng = (startLng + endLng) / 2;
  
  const deltaLat = endLat - startLat;
  const deltaLng = endLng - startLng;
  const curveFactor = 0.08;
  const curveLat = midLat - deltaLng * curveFactor;
  const curveLng = midLng + deltaLat * curveFactor;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const lat = (1 - t) * (1 - t) * startLat + 2 * (1 - t) * t * curveLat + t * t * endLat;
    const lng = (1 - t) * (1 - t) * startLng + 2 * (1 - t) * t * curveLng + t * t * endLng;
    points.push([lat, lng]);
  }
  return points;
}

/**
 * Real live address searching using data.gouv.fr and Nominatim
 */
export async function searchRealAddresses(query: string): Promise<LocationPoint[]> {
  if (!query || query.trim().length < 2) return [];

  try {
    // 1. Try French National Address Database (Base Adresse Nationale - Fast, accurate, free)
    const encoded = encodeURIComponent(query.trim());
    const res = await fetch(`https://api-adresse.data.gouv.fr/search/?q=${encoded}&limit=6`, {
      headers: { Accept: 'application/json' },
    });

    if (res.ok) {
      const data = await res.json();
      if (data && data.features && data.features.length > 0) {
        return data.features.map((f: any) => ({
          name: f.properties.name || f.properties.label,
          address: f.properties.label || `${f.properties.name}, ${f.properties.city}`,
          lat: f.geometry.coordinates[1],
          lng: f.geometry.coordinates[0],
        }));
      }
    }
  } catch {
    // fallback
  }

  // 2. Fallback to OpenStreetMap Nominatim for international queries or non-standard addresses
  try {
    const nomRes = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&addressdetails=1`
    );
    if (nomRes.ok) {
      const nomData = await nomRes.json();
      return nomData.map((item: any) => ({
        name: item.display_name.split(',')[0],
        address: item.display_name,
        lat: parseFloat(item.lat),
        lng: parseFloat(item.lon),
      }));
    }
  } catch {
    // Return empty array
  }

  return [];
}

/**
 * Real road routing via OSRM (Open Source Routing Machine)
 */
export async function fetchRealRoadRoute(
  startLat: number,
  startLng: number,
  endLat: number,
  endLng: number
): Promise<[number, number][]> {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${startLng},${startLat};${endLng},${endLat}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      if (data.routes && data.routes[0] && data.routes[0].geometry) {
        const coords = data.routes[0].geometry.coordinates; // [lng, lat]
        return coords.map((c: [number, number]) => [c[1], c[0]]);
      }
    }
  } catch {
    // fallback
  }

  // Fallback to geometric interpolation
  return generateRoutePoints(startLat, startLng, endLat, endLng, 25);
}

/**
 * External Navigation URL generators for Driver
 */
export function getWazeUrl(lat: number, lng: number): string {
  return `https://www.waze.com/ul?ll=${lat},${lng}&navigate=yes`;
}

export function getGoogleMapsUrl(lat: number, lng: number): string {
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
}

export function formatEuro(amount: number): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
  }).format(amount);
}

