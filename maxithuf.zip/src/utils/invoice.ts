import { jsPDF } from 'jspdf';
import { Ride, DriverProfile, CourierRequest, BusinessProfile } from '../types/vtc';
import { formatEuro } from './geo';

/**
 * Generates an official Passenger/Client Tax Invoice (Facture de transport VTC)
 */
export function generateInvoicePDF(ride: Ride): boolean {
  try {
    const doc = new jsPDF();
    const invoiceNum = ride.invoiceNumber || `FAC-${new Date(ride.createdAt || Date.now()).getFullYear()}-${(ride.id || 'SOMED').slice(-6).toUpperCase()}`;
    const dateStr = new Date(ride.createdAt || Date.now()).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const vatRate = 0.10; // 10% TVA Transport de personnes en France
    const fare = Number(ride.fare) || 0;
    const tip = Number(ride.tip) || 0;
    const totalTTC = fare + tip;
    const totalHT = totalTTC / (1 + vatRate);
    const tvaAmount = totalTTC - totalHT;

    const pickupText = ride.pickup?.name || ride.pickup?.address || 'Lieu de prise en charge';
    const destText = ride.destination?.name || ride.destination?.address || 'Destination';
    const driverName = ride.driverName || 'Alexandre Dupont';
    const vehicleModel = ride.vehicleModel || 'Mercedes Classe E';
    const vehiclePlate = ride.vehiclePlate || 'GD-411-AZ';
    const passengerName = ride.passengerName || 'SOMED dine';
    const passengerPhone = ride.passengerPhone || '+3360587241';
    const distKm = ride.distanceKm || 5.2;
    const durMin = ride.durationMin || 18;
    const cat = ride.category || 'CONFORT';

    // Header Dark Banner
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, 210, 40, 'F');

    // Title
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.text('SOMED VTC PRESTIGE', 20, 25);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text('FACTURE DE TRANSPORT DE PERSONNES (ACQUITTÉE)', 20, 32);

    // Document meta
    doc.setFontSize(9);
    doc.text(`Facture N°: ${invoiceNum}`, 135, 20);
    doc.text(`Date: ${dateStr}`, 135, 26);
    doc.text('Statut: Acquittée (Payé)', 135, 32);

    // Platform & Legal info
    doc.setTextColor(51, 65, 85);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Émetteur :', 20, 52);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text('SOMED MOBILITY SAS', 20, 58);
    doc.text('SIRET : 892 411 930 00024 · RCS Paris', 20, 63);
    doc.text('Registre EVTC : EVTC075210988', 20, 68);
    doc.text('TVA Intracommunautaire : FR 48 892411930', 20, 73);

    // Client info
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Client (Passager) :', 120, 52);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`Nom : ${passengerName}`, 120, 58);
    doc.text(`Téléphone : ${passengerPhone}`, 120, 63);
    doc.text(`Moyen de paiement : ${ride.paymentMethod === 'CARD' ? 'Carte Bancaire (Stripe)' : ride.paymentMethod === 'APPLE_PAY' ? 'Apple Pay' : 'Espèces'}`, 120, 68);

    // Trajet Details Box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(20, 80, 170, 50, 3, 3, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text('Détails de la prestation de transport VTC', 25, 88);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Chauffeur : ${driverName}`, 25, 96);
    doc.text(`Véhicule : ${vehicleModel} (${vehiclePlate}) · Gamme ${cat}`, 25, 102);
    doc.text(`Départ : ${pickupText}`, 25, 108);
    doc.text(`Arrivée : ${destText}`, 25, 114);
    doc.text(`Distance : ${distKm} km · Durée : ${durMin} minutes`, 25, 120);

    // Financial Table Header
    doc.setFillColor(241, 245, 249);
    doc.rect(20, 138, 170, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59);
    doc.text('Description', 25, 143);
    doc.text('Taux TVA', 110, 143);
    doc.text('Montant HT', 140, 143);
    doc.text('Montant TTC', 170, 143);

    // Financial Line: Ride
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);
    doc.text(`Course VTC (${cat}) - ${distKm} km`, 25, 152);
    doc.text('10,00 %', 110, 152);
    doc.text(formatEuro(fare / 1.10), 140, 152);
    doc.text(formatEuro(fare), 170, 152);

    // Financial Line: Tip if any
    let yPos = 160;
    if (tip > 0) {
      doc.text('Pourboire Chauffeur (100% reversé)', 25, yPos);
      doc.text('0,00 %', 110, yPos);
      doc.text(formatEuro(tip), 140, yPos);
      doc.text(formatEuro(tip), 170, yPos);
      yPos += 8;
    }

    // Summary Totals
    doc.line(20, yPos, 190, yPos);
    yPos += 8;

    doc.setFont('helvetica', 'normal');
    doc.text('Total Hors Taxes (HT) :', 115, yPos);
    doc.text(formatEuro(totalHT), 165, yPos);
    yPos += 6;

    doc.text('TVA (10,00 %) :', 115, yPos);
    doc.text(formatEuro(tvaAmount), 165, yPos);
    yPos += 7;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('Total Payé TTC :', 115, yPos);
    doc.text(formatEuro(totalTTC), 165, yPos);

    // Legal Mentions Footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('Facture acquittée établie conformément à l\'article L. 3122-1 du Code des transports régissant l\'activité de VTC.', 20, 270);
    doc.text('Paiement électronique sécurisé. Aucun escompte pour paiement anticipé. Contact : contact@somed.biz', 20, 275);

    // Reliable PDF download
    savePdfWithFallback(doc, `Facture-${invoiceNum}.pdf`);
    return true;
  } catch (error) {
    console.error('Erreur facture client PDF:', error);
    return false;
  }
}

/**
 * Generates an official Driver Payout Statement (Bordereau de course et rémunération Chauffeur)
 */
export function generateDriverBordereauPDF(ride: Ride, driver?: DriverProfile): boolean {
  try {
    const doc = new jsPDF();
    const bordereauNum = `BOR-${new Date(ride.createdAt || Date.now()).getFullYear()}-${(ride.id || 'SOMED').slice(-6).toUpperCase()}`;
    const dateStr = new Date(ride.createdAt || Date.now()).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const fare = Number(ride.fare) || 0;
    const netChauffeur = Math.round(fare * 0.80 * 100) / 100;
    const commission = Math.round(fare * 0.20 * 100) / 100;
    const tip = Number(ride.tip) || 0;
    const totalNetPayout = netChauffeur + tip;

    const pickupText = ride.pickup?.name || ride.pickup?.address || 'Prise en charge';
    const destText = ride.destination?.name || ride.destination?.address || 'Destination';
    const driverName = driver?.name || ride.driverName || 'Alexandre Dupont';
    const driverPhone = driver?.phone || ride.driverPhone || '+33 6 78 45 12 33';
    const vehicle = driver?.vehicle?.model || ride.vehicleModel || 'Mercedes Classe E';
    const plate = driver?.vehicle?.plate || ride.vehiclePlate || 'GD-411-AZ';

    // Header Dark Emerald Banner for Driver Payout
    doc.setFillColor(6, 78, 59); // emerald-900
    doc.rect(0, 0, 210, 40, 'F');

    // Title
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('SOMED PARTENAIRES VTC', 20, 24);

    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(167, 243, 208); // emerald-200
    doc.text('BORDEREAU OFFICIEL DE RÉMUNÉRATION CHAUFFEUR', 20, 32);

    // Meta right
    doc.setFontSize(8.5);
    doc.text(`Bordereau N°: ${bordereauNum}`, 135, 20);
    doc.text(`Date : ${dateStr}`, 135, 26);
    doc.text('Statut : Rémunéré & Crédité', 135, 32);

    // Platform & Driver box
    doc.setTextColor(30, 41, 59);
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'bold');
    doc.text('Opérateur Plateforme :', 20, 52);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text('SOMED MOBILITY SAS · SIRET : 892 411 930 00024', 20, 58);
    doc.text('Régulation & Dispatch VTC · Contact : contact@somed.biz', 20, 63);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text('Chauffeur Partenaire Bénéficiaire :', 120, 52);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`Nom : ${driverName}`, 120, 58);
    doc.text(`Tél : ${driverPhone}`, 120, 63);
    doc.text(`Véhicule : ${vehicle} (${plate})`, 120, 68);

    // Details box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(20, 78, 170, 46, 3, 3, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text('Détails de la course effectuée', 25, 86);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Course N° : #${ride.id.toUpperCase()}`, 25, 93);
    doc.text(`Passager : ${ride.passengerName || 'Client SOMED'} (${ride.passengerPhone || 'N/A'})`, 25, 99);
    doc.text(`Prise en charge : ${pickupText}`, 25, 105);
    doc.text(`Destination : ${destText}`, 25, 111);
    doc.text(`Distance : ${ride.distanceKm || 5.2} km · Durée : ${ride.durationMin || 18} min`, 25, 117);

    // Financial breakdown table
    doc.setFillColor(241, 245, 249);
    doc.rect(20, 134, 170, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text('Élément de décompte', 25, 139);
    doc.text('Taux', 120, 139);
    doc.text('Montant', 165, 139);

    let y = 149;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);
    doc.text('Prix de course brut payé par le client', 25, y);
    doc.text('100 %', 120, y);
    doc.text(formatEuro(fare), 165, y);

    y += 8;
    doc.setTextColor(225, 29, 72); // rose-600
    doc.text('Frais de service & commission plateforme SOMED', 25, y);
    doc.text('-20 %', 120, y);
    doc.text(`-${formatEuro(commission)}`, 165, y);

    if (tip > 0) {
      y += 8;
      doc.setTextColor(16, 185, 129); // emerald-500
      doc.text('Pourboire passager (reversé à 100% au chauffeur)', 25, y);
      doc.text('+100 %', 120, y);
      doc.text(`+${formatEuro(tip)}`, 165, y);
    }

    y += 10;
    doc.line(20, y, 190, y);
    y += 10;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(5, 150, 105); // emerald-600
    doc.text('NET PERÇU PAR LE CHAUFFEUR :', 25, y);
    doc.text(formatEuro(totalNetPayout), 160, y);

    // Legal & Signature
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('Ce bordereau fait foi pour la déclaration de chiffre d\'affaires du chauffeur indépendant partenaire.', 20, 265);
    doc.text('Montant immédiatement versé et disponible sur le portefeuille chauffeur de l\'application SOMED.', 20, 271);

    savePdfWithFallback(doc, `Bordereau-${bordereauNum}.pdf`);
    return true;
  } catch (error) {
    console.error('Erreur bordereau chauffeur PDF:', error);
    return false;
  }
}

/**
 * Generates an official Merchant/Business Delivery Order Invoice (Facture Commande Boutique & Marchand)
 */
export function generateBusinessOrderInvoicePDF(order: CourierRequest, business?: BusinessProfile): boolean {
  try {
    const doc = new jsPDF();
    const orderNum = `CMD-${order.id.slice(-6).toUpperCase()}`;
    const dateStr = new Date(order.createdAt || Date.now()).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const storeName = business?.name || 'Boutique Partenaire SOMED';
    const storeAddress = business?.address || 'Marrakech / Paris';
    const storePhone = business?.phone || '+33 6 05 87 24 10';
    const orderValue = Number(order.orderValue) || 0;
    const vatRate = 0.20; // 20% TVA commerce
    const htValue = orderValue / (1 + vatRate);
    const vatValue = orderValue - htValue;

    // Header Indigo/Amber Banner
    doc.setFillColor(30, 27, 75); // indigo-950
    doc.rect(0, 0, 210, 40, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('SOMED COMMERCE & LIVRAISON', 20, 24);

    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(199, 210, 254); // indigo-200
    doc.text('BON DE COMMANDE ET FACTURE COMMERÇANT', 20, 32);

    doc.setFontSize(8.5);
    doc.text(`Commande N° : ${orderNum}`, 135, 20);
    doc.text(`Date : ${dateStr}`, 135, 26);
    doc.text(`Statut : ${order.status === 'DELIVERED' ? 'Livrée' : order.status}`, 135, 32);

    // Store & Customer info
    doc.setTextColor(30, 41, 59);
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'bold');
    doc.text('Établissement Vendeur :', 20, 52);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`Enseigne : ${storeName}`, 20, 58);
    doc.text(`Adresse : ${storeAddress}`, 20, 63);
    doc.text(`Contact : ${storePhone}`, 20, 68);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text('Client Destinataire :', 120, 52);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`Nom : ${order.customerName}`, 120, 58);
    doc.text(`Téléphone : ${order.customerCountryCode || ''} ${order.customerPhone}`, 120, 63);
    doc.text(`Livraison à : ${order.customerAddress}`, 120, 68);

    // Delivery Box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(20, 78, 170, 38, 3, 3, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text('Détails de la livraison express', 25, 86);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Mode : ${order.serviceType === 'DELIVER_AND_COLLECT' ? 'Livraison avec encaissement espèces' : 'Livraison simple (Déjà réglée)'}`, 25, 93);
    doc.text(`Coursier VTC SOMED : ${order.driverName || 'Coursier Express'} (${order.driverPhone || 'Contact direct'})`, 25, 99);
    doc.text(`Temps de préparation : ${order.prepTimeMin || 15} minutes`, 25, 105);

    // Order Value Table
    doc.setFillColor(241, 245, 249);
    doc.rect(20, 126, 170, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text('Désignation', 25, 131);
    doc.text('Taux TVA', 115, 131);
    doc.text('Total HT', 140, 131);
    doc.text('Total TTC', 165, 131);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);
    doc.text(`Articles boutique (${storeName})`, 25, 142);
    doc.text('20,00 %', 115, 142);
    doc.text(formatEuro(htValue), 140, 142);
    doc.text(formatEuro(orderValue), 165, 142);

    doc.line(20, 154, 190, 154);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('TOTAL COMMANDE TTC :', 100, 164);
    doc.text(formatEuro(orderValue), 165, 164);

    // Footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('Facture établie sous mandat de facturation SOMED Mobility Commerce.', 20, 268);
    doc.text('En cas de question sur cette commande : contact@somed.biz', 20, 274);

    savePdfWithFallback(doc, `Commande-${orderNum}.pdf`);
    return true;
  } catch (error) {
    console.error('Erreur facture commande marchand PDF:', error);
    return false;
  }
}

/**
 * Helper to download PDF with safe fallback
 */
function savePdfWithFallback(doc: jsPDF, filename: string): void {
  try {
    doc.save(filename);
  } catch {
    const blob = doc.output('blob');
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);
    }, 2000);
  }
}
